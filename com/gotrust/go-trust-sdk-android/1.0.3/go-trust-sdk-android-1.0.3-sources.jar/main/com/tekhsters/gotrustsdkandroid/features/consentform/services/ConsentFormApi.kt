package com.tekhsters.gotrustsdkandroid.features.consentform.services

import com.google.gson.annotations.SerializedName
import com.tekhsters.gotrustsdkandroid.features.consentform.models.*
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface ConsentFormApi {

    @POST("universal/public/api/v2/translator/language-codes")
    suspend fun fetchLanguages(
        @Body payload: LanguageRequest
    ): Response<LanguageResponseWrapper>

    @POST("backend/api/public/download")
    suspend fun fetchImageUrl(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<ImageDownloadUrlResponse>

    @POST("universal/public/api/v2/ct/verify")
    suspend fun checkConsentStatus(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<CheckConsentResponse>

    @POST("universal/public/api/v6/gtf/display")
    suspend fun getConsentFormData(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<ConsentFormResponse>

    @GET("public/api/v6/gtf/display")
    suspend fun fetchConsentFormData(
        @Query("source_id") sourceId: Any,
        @Query("language_code") languageCode: String,
        @Query("subject_identity") subjectIdentity: String
    ): Response<ConsentFormResponse>

    @POST("universal/public/api/v3/data-collector/records")
    suspend fun saveConsentFormData(
        @Header("x-consent-evidence-token") evidenceToken: String?,
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<SaveConsentResponse>

    @POST("universal/public/api/v2/security/entrypoint")
    suspend fun getConsentFormId(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<DecrypterApiResponse>

    @GET("universal/public/api/v2/ct/frequency-list")
    suspend fun getFrequencyList(
        @Query("language_code") languageCode: String
    ): Response<ResponseBody> // Using ResponseBody for now if FrequencyListResponse is not yet defined or complex

    @Headers("accept: application/json")
    @POST("universal/public/api/v2/pn/display")
    suspend fun getPrivacyNotice(
        @Body payload: PrivacyNoticeRequest
    ): Response<PrivacyNoticeResponse>

    @GET
    suspend fun getPlainJsonToDisplayConsent(
        @Url url: String
    ): Response<ConsentFormResponse.ConsentFormData>

    @GET("universal/public/api/v3/digilocker/login")
    suspend fun getDigiLockerResponse(
        @Query("redirect_uri") redirectUri: String
    ): Response<DigiLockerResponse>

    @GET("universal/public/api/v3/digilocker/callback")
    suspend fun getCallbackApiResponse(
        @Query("code") code: String,
        @Query("state") state: String
    ): Response<CallBackResponse>
}

// Wrapper for Language response since it's nested in result.data in Flutter
data class LanguageResponseWrapper(
    @SerializedName("result") val result: Result?
) {
    data class Result(
        @SerializedName("data") val data: List<Language>?
    )
}

data class LanguageRequest(
    @SerializedName("mode") val mode: String = "form",
    @SerializedName("customer_id") val customerId: String,
    @SerializedName("form_id") val formId: String
)

data class PrivacyNoticeRequest(
    @SerializedName("customer_id") val customerId: String,
    @SerializedName("source_id") val sourceId: Any?,
    @SerializedName("language_code") val languageCode: String
)
