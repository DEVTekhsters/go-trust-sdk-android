package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentRecord

private const val NODE_WIDTH_DP = 190
private const val NODE_HEIGHT_DP = 74
private const val H_GAP_DP = 56
private const val V_GAP_DP = 18
private const val COLUMN_COUNT = 13

private data class FlowNode(val title: String, val value: String)

/** A node placed in the merged flow graph: same (type, value) pair across records collapses to one node. */
private class GNode(val title: String, val value: String, val column: Int) {
    var row: Int = 0
}

private class FlowGraph(val columns: List<List<GNode>>, val edges: List<Pair<GNode, GNode>>)

/**
 * Builds a merged, column-layered graph the same way the Flutter SDK's ConsentGraphPage does via
 * graphview: nodes are de-duplicated by (type, value) within a column, so records that share a
 * source/template/subject/etc. converge onto the same node instead of drawing a separate chain
 * per record. The shared "tail" (consent status → ... → latest consent) always comes from the
 * first record, mirroring the Dart implementation exactly.
 */
private fun buildGraph(records: List<ConsentRecord>): FlowGraph {
    val registry = LinkedHashMap<String, GNode>()
    val columns = Array(COLUMN_COUNT) { mutableListOf<GNode>() }
    val edges = mutableListOf<Pair<GNode, GNode>>()

    fun nodeOf(type: String, value: String, title: String, column: Int): GNode {
        val key = "$type::$value"
        return registry.getOrPut(key) {
            val node = GNode(title, value, column)
            node.row = columns[column].size
            columns[column].add(node)
            node
        }
    }

    fun edge(a: GNode, b: GNode) {
        if (edges.none { it.first === a && it.second === b }) edges.add(a to b)
    }

    val first = records.first()
    val consentStatusNode = nodeOf("consent_status", first.consentStatus, "CONSENT STATUS", 7)
    val consentedAtNode = nodeOf("consented_at", first.consentedAt, "CONSENTED AT", 8)
    val languageNode = nodeOf("language", first.language, "LANGUAGE", 9)
    val expiredConsentNode = nodeOf("expired_consent", first.expiredConsent, "EXPIRED CONSENT", 10)
    val retentionExpiredNode = nodeOf("data_retention_expired", first.dataRetentionExpired, "DATA RETENTION EXPIRED", 11)
    val latestConsentNode = nodeOf("latest_consent", first.latestConsent, "LATEST CONSENT", 12)

    edge(consentStatusNode, consentedAtNode)
    edge(consentedAtNode, languageNode)
    edge(languageNode, expiredConsentNode)
    edge(expiredConsentNode, retentionExpiredNode)
    edge(retentionExpiredNode, latestConsentNode)

    for (r in records) {
        val sourceNode = nodeOf("source", r.source, "SOURCE", 0)
        val templateNode = nodeOf("collection_template", r.collectionTemplate, "COLLECTION TEMPLATE", 1)
        val subjectNode = nodeOf("subject_identity", r.subjectIdentity, "SUBJECT IDENTITY", 2)
        val unifiedNode = nodeOf("unified_person", r.unifiedPerson, "UNIFIED PERSON", 3)
        val processingNode = nodeOf("processing_activities", r.processingActivities, "PROCESSING ACTIVITIES", 4)
        val preferenceNode = nodeOf("consent_preferences", r.consentPreferences, "CONSENT PREFERENCES", 5)
        val piiNode = nodeOf("pii_name", r.piiName, "PII NAME", 6)

        edge(sourceNode, templateNode)
        edge(templateNode, subjectNode)
        edge(subjectNode, unifiedNode)
        edge(unifiedNode, processingNode)
        edge(processingNode, preferenceNode)
        edge(preferenceNode, piiNode)
        edge(piiNode, consentStatusNode)
    }

    return FlowGraph(columns.toList(), edges)
}

@Composable
fun ConsentFlowTab(viewModel: PreferenceCenterViewModel) {
    var loading by remember { mutableStateOf(true) }
    var records by remember { mutableStateOf<List<ConsentRecord>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        loading = true
        try {
            records = viewModel.getConsentFlow()
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    when {
        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Error: $error") }
        records.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No data") }
        else -> ConsentFlowCanvas(records)
    }
}

@Composable
private fun ConsentFlowCanvas(records: List<ConsentRecord>) {
    var scale by remember { mutableFloatStateOf(0.55f) }
    var offset by remember { mutableStateOf(Offset(24f, 24f)) }

    val graph = remember(records) { buildGraph(records) }

    val nodeWidth = NODE_WIDTH_DP.dp
    val nodeHeight = NODE_HEIGHT_DP.dp
    val colStride = (NODE_WIDTH_DP + H_GAP_DP).dp
    val rowStride = (NODE_HEIGHT_DP + V_GAP_DP).dp
    val maxRows = graph.columns.maxOf { it.size }.coerceAtLeast(1)
    val totalWidth = colStride * graph.columns.size
    val totalHeight = rowStride * maxRows

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F8FA))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.2f, 3f)
                    offset += pan
                }
            },
    ) {
        Box(
            modifier = Modifier
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y,
                    transformOrigin = TransformOrigin(0f, 0f),
                )
                .size(totalWidth + 32.dp, totalHeight + 32.dp)
                .padding(16.dp),
        ) {
            Canvas(Modifier.fillMaxSize()) {
                graph.edges.forEach { (from, to) ->
                    val fromX = from.column * colStride.toPx() + nodeWidth.toPx()
                    val fromY = from.row * rowStride.toPx() + nodeHeight.toPx() / 2
                    val toX = to.column * colStride.toPx()
                    val toY = to.row * rowStride.toPx() + nodeHeight.toPx() / 2
                    val midX = (fromX + toX) / 2
                    val path = Path().apply {
                        moveTo(fromX, fromY)
                        cubicTo(midX, fromY, midX, toY, toX, toY)
                    }
                    drawPath(path, color = Color(0xFF90A4AE), style = Stroke(width = 1.6f))
                }
            }

            graph.columns.forEach { colNodes ->
                colNodes.forEach { node ->
                    FlowNodeCard(
                        node = FlowNode(node.title, node.value),
                        modifier = Modifier.offset(x = colStride * node.column, y = rowStride * node.row),
                        width = nodeWidth,
                        height = nodeHeight,
                    )
                }
            }
        }

        Card(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(14.dp),
        ) {
            Column {
                IconButton(onClick = { scale = (scale * 1.2f).coerceIn(0.2f, 3f) }) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom in")
                }
                IconButton(onClick = { scale = (scale / 1.2f).coerceIn(0.2f, 3f) }) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom out")
                }
                IconButton(onClick = { scale = 0.55f; offset = Offset(24f, 24f) }) {
                    Icon(Icons.Default.CenterFocusStrong, contentDescription = "Reset view")
                }
            }
        }
    }
}

@Composable
private fun FlowNodeCard(node: FlowNode, modifier: Modifier, width: Dp, height: Dp) {
    Column(
        modifier = modifier
            .width(width)
            .height(height)
            .border(1.dp, Color(0xFFCFD8DC), RoundedCornerShape(12.dp))
            .background(Color.White, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(16.dp)
                    .background(Color(0xFFEAF2FF), CircleShape)
                    .border(1.dp, Color(0xFF3B82F6), CircleShape),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                node.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF3B82F6),
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            node.value.ifEmpty { "-" },
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF212121),
        )
    }
}
