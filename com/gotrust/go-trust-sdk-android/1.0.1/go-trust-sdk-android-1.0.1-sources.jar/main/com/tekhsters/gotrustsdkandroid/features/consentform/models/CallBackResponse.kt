package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class CallBackResponse(
    @SerializedName("success") val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("result") val result: CallBackData?,
    @SerializedName("time") val time: Long?
) {
    data class CallBackData(
        @SerializedName("data") val data: Data?
    )

    data class Data(
        @SerializedName("user_details") val userDetails: UserDetails?,
        @SerializedName("age_info") val ageInfo: AgeInfo?,
        @SerializedName("token") val token: String?
    )

    data class UserDetails(
        @SerializedName("digilockerid") val digilockerid: String?,
        @SerializedName("name") val name: String?,
        @SerializedName("dob") val dob: String?,
        @SerializedName("gender") val gender: String?,
        @SerializedName("eaadhaar") val eaadhaar: String?,
        @SerializedName("reference_key") val referenceKey: String?,
        @SerializedName("mobile") val mobile: String?,
        @SerializedName("sub") val sub: String?
    )

    data class AgeInfo(
        @SerializedName("age") val age: Int?,
        @SerializedName("is_minor") val isMinor: Boolean?
    )
}
