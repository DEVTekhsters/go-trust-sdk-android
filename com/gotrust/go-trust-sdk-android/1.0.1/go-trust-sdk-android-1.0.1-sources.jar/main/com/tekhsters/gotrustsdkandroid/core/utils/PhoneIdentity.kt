package com.tekhsters.gotrustsdkandroid.core.utils

/**
 * Single source of truth for the static India dialling code applied to phone-number subject
 * identities across the consent form and the preference center.
 *
 * The convention the rest of the SDK relies on: **state holds the bare national number, the
 * `+91` is added at the two edges only** — rendered as a fixed, non-editable prefix in the UI
 * and prepended when a `pii_value` is serialized into an API payload. Keeping the prefix out of
 * the in-memory value is what stops it from compounding when a value makes a round trip
 * (host app prefill -> form -> save -> preference center prefill), and it means the existing
 * validation and edit logic keeps working on the digits the user actually typed.
 */
object PhoneIdentity {

    const val COUNTRY_CODE = "+91"

    /** Number of digits in a national (India) phone number, i.e. what remains after [COUNTRY_CODE]. */
    private const val NATIONAL_NUMBER_LENGTH = 10

    /**
     * Whether a subject identity / PII label refers to a phone number. [regexPatterns] (the
     * PII's `regex_pattern` list) is checked first when available - it's validation metadata that
     * stays fixed regardless of display language, unlike [name], which comes back translated once
     * the form isn't in English and then no longer contains the English words this falls back to
     * matching. A ten-digit pattern (`{10}`) only ever appears on the phone PII's regex list -
     * every other field (name, email, DOB, pin code) uses a different digit count or none at all.
     */
    fun isPhoneLabel(name: String?, regexPatterns: List<String>? = null): Boolean {
        // Ten digits are commonly split across the pattern (e.g. "[6-9]\d{9}" = 1 + 9), so a
        // literal "{10}" isn't guaranteed even on a phone regex - treat the regex list as a
        // positive-only signal and fall back to the name when it doesn't match.
        if (!regexPatterns.isNullOrEmpty() && regexPatterns.any { it.contains("{10}") || it.contains("{9}") }) {
            return true
        }
        val normalized = name?.lowercase() ?: return false
        return normalized.contains("phone") ||
            normalized.contains("mobile") ||
            normalized.contains("contact")
    }

    /**
     * Fallback used only where label names are not known yet — the consent form's initial
     * `getConsentFormData` fetch and the public `checkConsentStatus` helper both build their
     * `subject_identity_values` before (or entirely without) any form metadata, from a raw
     * `id -> value` map supplied by the host app.
     *
     * Deliberately narrow: exactly ten digits, or ten digits already carrying the country code.
     * An email or a customer reference can never match, so a non-phone identity is never
     * rewritten by accident.
     */
    fun looksLikePhoneNumber(value: String?): Boolean {
        val digits = digitsOf(value) ?: return false
        return digits.length == NATIONAL_NUMBER_LENGTH
    }

    /**
     * Removes a leading `+91`/`91` so the value can be held in state, shown next to the static
     * UI prefix, and edited as a plain national number. Anything that is not a recognizable
     * prefixed phone number is returned untouched (trimmed), so calling this on an email or a
     * partially typed number is safe.
     */
    fun strip(value: String?): String {
        val trimmed = value?.trim().orEmpty()
        val digits = digitsOf(trimmed) ?: return trimmed
        return if (digits.length == NATIONAL_NUMBER_LENGTH) digits else trimmed
    }

    /**
     * Prepends [COUNTRY_CODE] for an API payload. Idempotent — a value that already carries the
     * code is normalized rather than prefixed twice — and a blank value stays blank so that
     * "field not filled in" is not turned into a bare `+91`.
     */
    fun withCountryCode(value: String?): String {
        val stripped = strip(value)
        if (stripped.isEmpty()) return ""
        return COUNTRY_CODE + stripped
    }

    /**
     * Applies [withCountryCode] only when [name]/[regexPatterns] identifies a phone label,
     * otherwise returns the value trimmed and unchanged. The one call every payload-building site
     * needs.
     */
    fun forLabel(name: String?, value: String?, regexPatterns: List<String>? = null): String =
        if (isPhoneLabel(name, regexPatterns)) withCountryCode(value) else value?.trim().orEmpty()

    /**
     * Name-less counterpart of [forLabel] for the two call sites that have no label metadata.
     */
    fun forUnknownLabel(value: String?): String =
        if (looksLikePhoneNumber(value)) withCountryCode(value) else value?.trim().orEmpty()

    /**
     * The national digits of a phone number written with or without the country code, or `null`
     * when the value is not purely a phone number. Separators commonly pasted from contact lists
     * (spaces, dashes, brackets) are tolerated.
     */
    private fun digitsOf(value: String?): String? {
        val cleaned = value?.filterNot { it.isWhitespace() || it == '-' || it == '(' || it == ')' }
            ?: return null
        if (cleaned.isEmpty()) return null
        val withoutCode = when {
            cleaned.startsWith(COUNTRY_CODE) -> cleaned.removePrefix(COUNTRY_CODE)
            // A bare "91" prefix is only stripped when what follows is a full national number,
            // so a ten-digit number that happens to start with 91 is left alone.
            cleaned.length == NATIONAL_NUMBER_LENGTH + 2 && cleaned.startsWith("91") ->
                cleaned.removePrefix("91")
            else -> cleaned
        }
        return if (withoutCode.isNotEmpty() && withoutCode.all { it.isDigit() }) withoutCode else null
    }
}
