package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class CheckConsentResponse(
    @SerializedName("success") val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("result") val result: Result?,
    @SerializedName("time") val time: Long?
) {
    data class Result(
        @SerializedName("data") val data: Data?
    )

    data class Data(
        @SerializedName("user_found") val userFound: Boolean?
    )
}
