package com.tekhsters.gotrustsdkandroid

import android.app.Activity
import android.content.Intent
import com.tekhsters.gotrustsdkandroid.core.callbacks.ConsentFormCallbacks
import com.tekhsters.gotrustsdkandroid.core.callbacks.GoTrustSdkCallbacks
import com.tekhsters.gotrustsdkandroid.core.callbacks.PreferenceCenterCallbacks
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ADDITIONAL_PARAMS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_BASE_URL
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_CONSENT_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_CUSTOMER_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ENABLE_CAPTCHA
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_LANGUAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_SUBJECT_VALUES
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_PF_TOKEN
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_PREFERENCE_FORM_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SHOW_CROSS_BUTTON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SOURCE_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_TOKEN
import com.tekhsters.gotrustsdkandroid.features.consentform.services.ApiService
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.GoTrustSdkActivity
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Outcome of asking the backend whether a subject has already consented, via
 * [GoTrustSdk.checkConsent].
 *
 * [Failed] is deliberately distinct from [AlreadyGiven]: a check that could not complete tells you
 * nothing about whether consent exists, and collapsing the two into "don't show the form" is how a
 * network blip turns into consent never being collected.
 */
sealed interface ConsentCheckResult {

    /** No consent on record for this subject — show the form. */
    data object Required : ConsentCheckResult

    /** The backend already holds consent for this subject; showing the form would re-ask. */
    data object AlreadyGiven : ConsentCheckResult

    /** The check itself did not complete (network, backend error, unusable source id). */
    data class Failed(val message: String?) : ConsentCheckResult
}

/**
 * Public entry point of the SDK. The activities behind these calls are `internal`, so this object
 * and the two config classes are the whole surface a host app needs — and the only way to get the
 * extras right without copying string literals out of the docs.
 */
object GoTrustSdk {

    /**
     * Opens the consent form. [callbacks] is consumed by this one session; the SDK clears it after
     * `onClose`. Hosts that only need the final outcome can pass `null` and read the activity
     * result instead.
     */
    fun showConsentForm(
        activity: Activity,
        config: ConsentFormConfig,
        callbacks: ConsentFormCallbacks? = null,
    ) {
        GoTrustSdkCallbacks.consentForm = callbacks
        GoTrustSdkCallbacks.fallback = config.fallback
        activity.startActivity(consentFormIntent(activity, config))
    }

    /**
     * Asks the backend whether the subject in [config] has already consented for this source,
     * without showing any UI. Suspends over two network calls (source-id resolution, then the
     * consent check); safe to call from any dispatcher, Retrofit moves the I/O off the caller.
     *
     * Only [config]'s `baseUrl`, `sourceId`, `subjectIdentityValues` and `token` take part — the
     * rest describes the form, which this never opens. Pass the same config you would hand to
     * [showConsentForm] so the check and the form agree on who is being asked.
     */
    suspend fun checkConsent(config: ConsentFormConfig): ConsentCheckResult {
        ApiService.instance.setBaseUrl(config.baseUrl)
        ApiService.instance.setFallback(config.fallback)
        val response = ApiService.instance.checkConsentStatus(
            sourceId = config.sourceId ?: "",
            subjectIdentityValues = config.subjectIdentityValues,
            token = config.token,
        ) ?: return ConsentCheckResult.Failed("Consent check could not be completed")

        // `user_found` is the backend's way of saying a consent record already exists for this
        // subject. Anything else — including a well-formed response that omits the flag — means
        // there is nothing on record to rely on.
        return if (response.result?.data?.userFound == true) {
            ConsentCheckResult.AlreadyGiven
        } else {
            ConsentCheckResult.Required
        }
    }

    /**
     * Runs [checkConsent] and opens the consent form only if it is actually needed — the normal
     * "don't re-ask someone who already consented" flow.
     *
     * [onResult] receives the decision on the main thread before any form is launched, so a host
     * can drop its own progress indicator. When the check fails, [showOnCheckFailure] decides what
     * happens: the default `true` shows the form anyway, since asking twice is recoverable and
     * skipping consent collection is not.
     *
     * Nothing is delivered or launched if [activity] is gone by the time the check returns.
     */
    fun showConsentFormIfNeeded(
        activity: Activity,
        config: ConsentFormConfig,
        callbacks: ConsentFormCallbacks? = null,
        showOnCheckFailure: Boolean = true,
        onResult: ((ConsentCheckResult) -> Unit)? = null,
    ) {
        // A plain main-thread scope rather than the activity's lifecycleScope: this module exposes
        // androidx as `implementation`, so a lifecycle-typed parameter would not resolve for
        // consumers. The job ends with the check, and the guard below covers a dead Activity.
        CoroutineScope(Dispatchers.Main.immediate).launch {
            val result = checkConsent(config)
            if (activity.isFinishing || activity.isDestroyed) return@launch

            onResult?.invoke(result)

            val show = when (result) {
                is ConsentCheckResult.Required -> true
                is ConsentCheckResult.AlreadyGiven -> false
                is ConsentCheckResult.Failed -> showOnCheckFailure
            }
            if (show) showConsentForm(activity, config, callbacks)
        }
    }

    /** Opens the preference center. See [showConsentForm] for how [callbacks] is scoped. */
    fun showPreferenceCenter(
        activity: Activity,
        config: PreferenceCenterConfig,
        callbacks: PreferenceCenterCallbacks? = null,
    ) {
        GoTrustSdkCallbacks.preferenceCenter = callbacks
        activity.startActivity(preferenceCenterIntent(activity, config))
    }

    private fun consentFormIntent(activity: Activity, config: ConsentFormConfig) =
        Intent(activity, GoTrustSdkActivity::class.java).apply {
            putExtra(EXTRA_BASE_URL, config.baseUrl)
            putExtra(EXTRA_SOURCE_ID, config.sourceId)
            putExtra(EXTRA_INITIAL_SUBJECT_VALUES, HashMap(config.subjectIdentityValues))
            putExtra(EXTRA_ADDITIONAL_PARAMS, HashMap(config.additionalParams))
            putExtra(EXTRA_SHOW_CROSS_BUTTON, config.showCrossButton)
            putExtra(EXTRA_INITIAL_LANGUAGE, config.initialLanguage)
            putExtra(EXTRA_ENABLE_CAPTCHA, config.enableCaptcha)
            config.token?.let { putExtra(EXTRA_TOKEN, it) }
        }

    private fun preferenceCenterIntent(activity: Activity, config: PreferenceCenterConfig) =
        Intent(activity, PreferenceCenterActivity::class.java).apply {
            putExtra(EXTRA_BASE_URL, config.baseUrl)
            config.pfToken?.let { putExtra(EXTRA_PF_TOKEN, it) }
            config.token?.let { putExtra(EXTRA_TOKEN, it) }
            putExtra(EXTRA_CONSENT_ID, config.consentId)
            config.customerId?.let { putExtra(EXTRA_CUSTOMER_ID, it) }
            config.preferenceFormId?.let { putExtra(EXTRA_PREFERENCE_FORM_ID, it) }
            putExtra(EXTRA_INITIAL_SUBJECT_VALUES, HashMap(config.initialSubjectValues))
            putExtra(EXTRA_ADDITIONAL_PARAMS, HashMap(config.additionalParams))
            putExtra(EXTRA_INITIAL_LANGUAGE, config.initialLanguage)
            putExtra(EXTRA_ENABLE_CAPTCHA, config.enableCaptcha)
        }
}
