package com.tekhsters.gotrustsdkandroid.features.preferencecenter.models

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive

/**
 * The preference-center config API mixes numeric and "10px"-style string values for the
 * same logical field depending on endpoint/version. These helpers mirror the Dart source's
 * `num.tryParse(json['x']?.toString().replaceAll('px', ''))` pattern so parsing tolerates both.
 */
internal object J {
    fun obj(o: JsonObject?, key: String): JsonObject? =
        o?.get(key)?.takeIf { it.isJsonObject }?.asJsonObject

    fun arr(o: JsonObject?, key: String): JsonArray? =
        o?.get(key)?.takeIf { it.isJsonArray }?.asJsonArray

    fun str(o: JsonObject?, key: String): String? {
        val el = o?.get(key) ?: return null
        if (el.isJsonNull) return null
        return if (el.isJsonPrimitive) el.asString else null
    }

    fun bool(o: JsonObject?, key: String): Boolean? {
        val el = o?.get(key) ?: return null
        if (el.isJsonNull || !el.isJsonPrimitive) return null
        val prim = el.asJsonPrimitive
        return if (prim.isBoolean) prim.asBoolean else null
    }

    fun int(o: JsonObject?, key: String): Int? {
        val el = o?.get(key) ?: return null
        if (el.isJsonNull || !el.isJsonPrimitive) return null
        val prim = el.asJsonPrimitive
        return if (prim.isNumber) prim.asInt else prim.asString.toIntOrNull()
    }

    fun double(o: JsonObject?, key: String): Double? {
        val el = o?.get(key) ?: return null
        if (el.isJsonNull || !el.isJsonPrimitive) return null
        val prim = el.asJsonPrimitive
        return if (prim.isNumber) prim.asDouble else prim.asString.toDoubleOrNull()
    }

    /** Parses a value that may be a raw number or a "12px" string. */
    fun doublePx(o: JsonObject?, key: String): Double? {
        val el = o?.get(key) ?: return null
        if (el.isJsonNull || !el.isJsonPrimitive) return null
        val prim = el.asJsonPrimitive
        if (prim.isNumber) return prim.asDouble
        return prim.asString.replace("px", "").trim().toDoubleOrNull()
    }

    fun intList(o: JsonObject?, key: String): List<Int>? {
        val a = arr(o, key) ?: return null
        return a.mapNotNull {
            if (it.isJsonPrimitive) {
                val p = it.asJsonPrimitive
                if (p.isNumber) p.asInt else p.asString.toIntOrNull()
            } else null
        }
    }

    fun stringList(o: JsonObject?, key: String): List<String>? {
        val a = arr(o, key) ?: return null
        return a.mapNotNull { if (it.isJsonPrimitive) it.asString else null }
    }

    /** Preserves raw string keys mapped to their raw JsonElement (used for order maps keyed by id). */
    fun rawMap(o: JsonObject?, key: String): Map<String, com.google.gson.JsonElement>? {
        val sub = obj(o, key) ?: return null
        return sub.entrySet().associate { it.key to it.value }
    }
}

internal fun JsonPrimitive.asIntOrNull(): Int? =
    if (isNumber) asInt else asString.toIntOrNull()
