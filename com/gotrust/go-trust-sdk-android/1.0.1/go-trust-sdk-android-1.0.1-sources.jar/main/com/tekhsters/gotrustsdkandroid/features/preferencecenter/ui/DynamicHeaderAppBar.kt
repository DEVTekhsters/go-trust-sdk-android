package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tekhsters.gotrustsdkandroid.core.utils.Utils

/**
 * Widest a header logo may be. Generous enough for a normal wordmark, small enough that the
 * dropdown and close icon always keep their 48dp touch targets on a phone-width bar.
 */
private val LOGO_MAX_WIDTH = 140.dp

/** Mirrors go-trust-mobile-sdk lib/core/utils/appbar_helper.dart's DynamicHeaderAppBar. */
@Composable
fun DynamicHeaderAppBar(
    closeIconPosition: String?,
    logoPosition: String?,
    dropdownPosition: String?,
    backgroundColor: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(horizontal = 4.dp),
    logo: (@Composable () -> Unit)? = null,
    dropdown: (@Composable () -> Unit)? = null,
) {
    // Positions arrive straight from the remote config, so they can be blank, differently cased,
    // or a value this layout doesn't know. Fall back to the documented default instead of dropping
    // the widget — an unrecognised close position used to leave the screen with no way out.
    // The bar has no centre slot for the close icon, so "center" lands on the right.
    val closePos = normalizePosition(closeIconPosition, default = "right", allowHidden = true)
        .let { if (it == "center") "right" else it }
    val logoPos = normalizePosition(logoPosition, default = "left")
    val dropdownPos = normalizePosition(dropdownPosition, default = "right")

    /**
     * The logo comes from remote config and is rendered by the caller as an image constrained only
     * in height. Such an image has no intrinsic width to fall back on when its URL fails to load,
     * so it expands to fill whatever width it is offered — and because [Row] measures unweighted
     * children in source order, the logo was consuming the whole bar and leaving the language
     * dropdown and the close icon measured at zero width. They were composed and present in the
     * semantics tree, just squeezed out of existence. Capping the logo keeps the controls
     * reachable no matter what the config points at.
     */
    val boundedLogo: (@Composable () -> Unit)? = logo?.let { content ->
        { Box(modifier = Modifier.widthIn(max = LOGO_MAX_WIDTH)) { content() } }
    }

    val closeButton: @Composable () -> Unit = {
        IconButton(onClick = onClose) {
            Icon(Icons.Default.Close, contentDescription = "Close")
        }
    }

    Row(
        modifier = modifier
            .background(Utils.hexToColor(backgroundColor))
            // Mirrors the Flutter bar's SafeArea: the host Scaffold consumes no insets, so without
            // this the row draws under the status bar and its icons are partly unreachable.
            .statusBarsPadding()
            .height(56.dp)
            .padding(contentPadding),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (closePos == "left") closeButton()
        if (logoPos == "left") boundedLogo?.invoke()
        if (dropdownPos == "left") dropdown?.invoke()

        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (logoPos == "center") boundedLogo?.invoke()
            if (dropdownPos == "center") dropdown?.invoke()
        }

        if (logoPos == "right") boundedLogo?.invoke()
        if (dropdownPos == "right") dropdown?.invoke()
        if (closePos == "right") closeButton()
    }
}

/**
 * Maps a remote-config position onto one this bar can render. Only an explicit "none"/"hidden"
 * suppresses an element; anything unknown falls back to [default] so it stays reachable.
 */
private fun normalizePosition(value: String?, default: String, allowHidden: Boolean = false): String =
    when (val v = value?.trim()?.lowercase()) {
        "left", "center", "right" -> v
        "none", "hidden", "false" -> if (allowHidden) "none" else default
        else -> default
    }
