package com.tekhsters.gotrustsdkandroid.core.utils

import android.content.Intent

/** Canonical, snake_case name for the captcha toggle — matches the other SDK extras. */
const val EXTRA_ENABLE_CAPTCHA = "enable_captcha"

/**
 * camelCase alias accepted for the captcha toggle. The Flutter SDK exposes this flag as
 * `enableCaptcha`, so integrators porting a Flutter integration naturally reach for that
 * spelling; silently defaulting to `true` there is what made a disabled captcha still run.
 */
private const val EXTRA_ENABLE_CAPTCHA_CAMEL = "enableCaptcha"

/**
 * Reads the captcha toggle, accepting either the snake_case extra or the Flutter-style
 * camelCase alias. Defaults to `true` (captcha on) only when the caller sets neither.
 */
fun Intent.readCaptchaFlag(default: Boolean = true): Boolean = when {
    hasExtra(EXTRA_ENABLE_CAPTCHA) -> getBooleanExtra(EXTRA_ENABLE_CAPTCHA, default)
    hasExtra(EXTRA_ENABLE_CAPTCHA_CAMEL) -> getBooleanExtra(EXTRA_ENABLE_CAPTCHA_CAMEL, default)
    else -> default
}

/**
 * Canonical name for the pre-filled subject identity map. Matches the Flutter SDK's
 * `initialSubjectValues` parameter, which is spelled the same on both `ConsentFormPage` and
 * `LoginPage`.
 */
const val EXTRA_INITIAL_SUBJECT_VALUES = "initial_subject_values"

/**
 * Alias kept for the consent form, which originally shipped with the API-payload spelling. The two
 * activities disagreeing on the name for the same concept is exactly the kind of thing integrators
 * get wrong once and then debug for an hour, so both spellings are accepted on both screens.
 */
private const val EXTRA_SUBJECT_IDENTITY_VALUES = "subject_identity_values"

/**
 * Reads the pre-filled subject identity map under either accepted name, preferring the canonical
 * one when a caller (or a nested SDK launch) happens to set both.
 */
@Suppress("UNCHECKED_CAST")
fun Intent.readInitialSubjectValues(): Map<String, Any> {
    val canonical = getSerializableExtra(EXTRA_INITIAL_SUBJECT_VALUES) as? Map<String, Any>
    if (canonical != null) return canonical
    return getSerializableExtra(EXTRA_SUBJECT_IDENTITY_VALUES) as? Map<String, Any> ?: emptyMap()
}

// Remaining launch-intent keys. Named here so `GoTrustSdk` and the activities it starts cannot
// drift apart the way two hand-written string literals silently can.

const val EXTRA_BASE_URL = "base_url"
const val EXTRA_SOURCE_ID = "source_id"
const val EXTRA_SHOW_CROSS_BUTTON = "show_cross_button"
const val EXTRA_INITIAL_LANGUAGE = "initial_language"
const val EXTRA_ADDITIONAL_PARAMS = "additional_params"

/** Marks a consent form opened by the preference center rather than by the host app. */
const val EXTRA_VIA_LOGIN = "via_login"

const val EXTRA_PF_TOKEN = "pf_token"

/**
 * Opaque decryptor token a host can hand the SDK in place of raw PII (`source_id`, or
 * `customer_id`+`pf_id`/[EXTRA_PF_TOKEN]). When present it wins over every other identifier, and
 * the identity/PII the decryptor resolves it to — not [EXTRA_INITIAL_SUBJECT_VALUES] /
 * [EXTRA_ADDITIONAL_PARAMS] — becomes the effective identity for the rest of the session.
 */
const val EXTRA_TOKEN = "token"
const val EXTRA_CONSENT_ID = "consent_id"
const val EXTRA_CUSTOMER_ID = "customer_id"
const val EXTRA_PREFERENCE_FORM_ID = "preference_form_id"

// Result-intent keys, read by hosts using the activity-result path.

const val EXTRA_STATUS = "status"
const val EXTRA_STATUS_CODE = "statusCode"
const val EXTRA_MESSAGE = "message"
const val EXTRA_DATA_JSON = "data_json"
const val EXTRA_SAVED = "saved"
const val EXTRA_ERROR_STATUS_CODE = "error_status_code"
const val EXTRA_ERROR_MESSAGE = "error_message"
