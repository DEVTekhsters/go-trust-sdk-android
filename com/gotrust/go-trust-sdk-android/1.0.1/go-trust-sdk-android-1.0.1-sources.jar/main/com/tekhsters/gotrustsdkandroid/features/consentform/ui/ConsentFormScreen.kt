package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.core.utils.*
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language

/** Mirrors Flutter's `_getAlignment`: left/right/center -> Box alignment, defaulting to start. */
fun boxAlignment(key: String?, fallback: Alignment = Alignment.CenterStart): Alignment =
    when (key?.lowercase()) {
        "left" -> Alignment.CenterStart
        "right" -> Alignment.CenterEnd
        "center" -> Alignment.Center
        else -> fallback
    }

fun textAlignFor(key: String?, fallback: TextAlign = TextAlign.Left): TextAlign =
    when (key?.lowercase()) {
        "left" -> TextAlign.Left
        "right" -> TextAlign.Right
        "center" -> TextAlign.Center
        else -> fallback
    }

/**
 * Mirrors Flutter's `_buildConsentInputControl`: renders a Switch when
 * consent_input_type == "toggle", else a checkbox whose shape follows
 * checkbox_border_radius (so a large/percent radius yields a circular control).
 * When [interactive] is false the control is purely visual (Flutter wraps the
 * bucket-level control in IgnorePointer since the whole row already handles taps).
 */
@Composable
fun ConsentInputControl(
    fc: ConsentFormResponse.FormConfiguration?,
    value: Boolean,
    disabled: Boolean,
    interactive: Boolean = true,
    onChanged: (Boolean) -> Unit
) {
    val inputType = (fc?.consentCollectionSection?.consentInputType ?: "checkbox").lowercase()
    val activeColor = Utils.hexToColor(fc?.form?.colorScheme ?: "#000000")

    if (inputType == "toggle") {
        Switch(
            checked = value,
            onCheckedChange = if (disabled || !interactive) null else onChanged,
            colors = SwitchDefaults.colors(
                checkedTrackColor = activeColor,
                checkedThumbColor = Color.White
            ),
            modifier = Modifier.scale(0.8f)
        )
    } else {
        val radiusDp = parseBorderRadius(fc?.consentCollectionSection?.checkboxBorderRadius, size = 20f).dp
        val shape = RoundedCornerShape(radiusDp)
        val bgColor = if (value) activeColor.copy(alpha = if (disabled) 0.7f else 1f) else Color.Transparent
        val borderColor = if (value) activeColor else Color(0xFFBDBDBD)
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(shape)
                .background(bgColor, shape)
                .border(1.5.dp, borderColor, shape)
                .let {
                    if (interactive && !disabled) it.clickable { onChanged(!value) } else it
                },
            contentAlignment = Alignment.Center
        ) {
            if (value) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsentFormScreen(
    viewModel: ConsentFormViewModel,
    onClose: () -> Unit,
    showCrossButton: Boolean = true
) {
    val form by viewModel.consentForm.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val checkAllStatus by viewModel.checkAllStatus.collectAsState()
    val consentRevision by viewModel.consentRevision.collectAsState()
    val invalidPiiKeys by viewModel.invalidPiiKeys.collectAsState()
    val piiValues = viewModel.piiValues
    val compulsoryPiiIds = remember(form) { viewModel.getCompulsoryPiiIds() }

    val isMinorForm = !form?.piiList?.consentActorPiiList.isNullOrEmpty()

    val fc = form?.formConfiguration
    val bi = form?.basicInfo

    Scaffold(

        topBar = {
            TopAppBar(
                title = {
                    DynamicTextWidget(
                        text = fc?.form?.heading?.text ?: "",
                        colorHex = fc?.form?.heading?.color ?: "#000000"
                    )
                },
                navigationIcon = {
                    fc?.form?.logo?.let { logo ->
                        if (logo.showLogo == true) {
                            AsyncImage(
                                model = logo.logoUrl,
                                contentDescription = "Logo",
                                modifier = Modifier
                                    .width(parsePxToDp(logo.width, fallback = 40f))
                                    .height(parsePxToDp(logo.height, fallback = 40f))
                                    .padding(4.dp)
                            )
                        }
                    }
                },
                actions = {
                    if (fc?.form?.showLanguage == true) {
                        LanguageSelector(
                            languages = languages,
                            selectedCode = selectedLanguage,
                            onChanged = { viewModel.onLanguageChanged(it) },
                            colorHex = fc.form.languageDropDown?.backgroundColor,
                            textColor = fc.form.languageDropDown?.textColor
                        )
                    }
                    if (showCrossButton) {
                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                },

                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    scrolledContainerColor = Color.White
                )
            )
        },
        containerColor = /*Utils.hexToColor(fc?.form?.formBackgroundColor),*/ Color.White,
        bottomBar = {
            SubmitActionSection(
                viewModel = viewModel,
                fc = fc,
                onPrivacyPolicyClick = { viewModel.showPrivacyNotice() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            fc?.form?.illustrationImage?.let { img ->
                if (img.showIllustrationImage == true && img.illustrationImageUrl != null) {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = boxAlignment(
                            fc.sectionAlignments?.illustration,
                            fallback = Alignment.Center
                        )
                    ) {
                        val configuredWidth = parsePxToDpOrNull(img.width)
                        AsyncImage(
                            model = img.illustrationImageUrl,
                            contentDescription = "Illustration",
                            modifier = Modifier
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .let { if (configuredWidth != null) it.width(configuredWidth) else it.fillMaxWidth() }
                                .height(parsePxToDp(img.height, fallback = 200f)),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = boxAlignment(fc?.sectionAlignments?.banner)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    DynamicTextWidget(
                        text = fc?.form?.description?.text ?: "",
                        colorHex = fc?.form?.description?.color,
                        fontWeight = getFontWeight(fc?.form?.description?.fontWeight),
                        fontSize = fc?.form?.description?.size?.replace("px", "")?.toDoubleOrNull()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    DynamicTextWidget(
                        text = fc?.piiSection?.description?.text ?: "",
                        colorHex = fc?.piiSection?.description?.color,
                        fontWeight = getFontWeight(fc?.piiSection?.description?.fontWeight)
                    )
                }
            }

            // PII Section
            if (fc?.piiSection?.showPiiSection == true) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = boxAlignment(fc.sectionAlignments?.piiSection)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        PiiGroup(
                            piiList = form?.piiList?.dataPrincipalPiiList,
                            heading = if (isMinorForm) fc.piiSection.dataPrincipalHeading else null,
                            values = piiValues,
                            invalidKeys = invalidPiiKeys,
                            compulsoryIds = compulsoryPiiIds,
                            colorScheme = fc.form?.colorScheme,
                            onValueChange = { key, value -> viewModel.onPiiValueChanged(key, value) }
                        )
                        PiiGroup(
                            piiList = form?.piiList?.consentActorPiiList,
                            heading = if (isMinorForm) fc.piiSection.consentActorHeading else null,
                            values = piiValues,
                            invalidKeys = invalidPiiKeys,
                            compulsoryIds = compulsoryPiiIds,
                            colorScheme = fc.form?.colorScheme,
                            onValueChange = { key, value -> viewModel.onPiiValueChanged(key, value) }
                        )
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            }

            // Consent Section
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = boxAlignment(fc?.sectionAlignments?.consentSection)
            ) {
                ConsentSection(
                    viewModel = viewModel,
                    form = form,
                    fc = fc,
                    checkAllStatus = checkAllStatus,
                    consentRevision = consentRevision,
                    isMinorForm = isMinorForm,
                    onCheckAllChange = { viewModel.toggleCheckAll(it) },
                    onSync = { viewModel.syncCheckAllStatus() }
                )
            }

            // Footer
            fc?.formFooter?.description?.text?.let { footerText ->
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = boxAlignment(fc.sectionAlignments?.footer)
                ) {
                    HtmlText(
                        html = footerText,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            // Privacy Notice link, shown here only in the dynamic-action-buttons layout — the
            // single-Submit layout keeps it as a button beside Submit instead.
            if (shouldShowDynamicButtons(fc) && fc?.form?.showPrivacyPolicyUrl != false) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = fc?.form?.privacyPolicyUrlText ?: "Privacy Notice",
                    color = Color.Blue,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .padding(horizontal = 18.dp)
                        .clickable { viewModel.showPrivacyNotice() }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun PiiGroup(
    piiList: List<ConsentFormResponse.PiiLabel>?,
    heading: ConsentFormResponse.Heading?,
    values: MutableMap<String, String>,
    invalidKeys: Set<String>,
    compulsoryIds: Set<Any>,
    colorScheme: String?,
    onValueChange: (key: String, value: String) -> Unit
) {
    if (piiList.isNullOrEmpty()) return

    Column(modifier = Modifier.padding(16.dp)) {
        heading?.text?.let {
            if (looksLikeHtml(it)) {
                HtmlText(html = it, colorHex = heading.color, fontWeight = FontWeight.SemiBold)
            } else {
                Text(it, style = TextStyleHelper.title, color = Utils.hexToColor(heading.color))
            }
        }

        piiList.forEach { pii ->
            val key = "${pii.principalContext ?: ""}_${pii.id}"
            val isInvalid = key in invalidKeys
            val isPhone = PhoneIdentity.isPhoneLabel(pii.name, pii.regEx)
            val isMandatory = pii.isMandatory || (pii.id != null && compulsoryIds.contains(pii.id))
            OutlinedTextField(
                value = values[key] ?: "",
                onValueChange = { onValueChange(key, if (isPhone) PhoneIdentity.strip(it) else it) },
                label = {
                    Row {
                        Text(pii.name ?: "")
                        if (isMandatory) {
                            Text(" *", color = Color.Red)
                        }
                    }
                },
                prefix = if (isPhone) {
                    { Text(PhoneIdentity.COUNTRY_CODE) }
                } else null,
                keyboardOptions = if (isPhone) {
                    KeyboardOptions(keyboardType = KeyboardType.Phone)
                } else {
                    KeyboardOptions.Default
                },
                singleLine = true,
                isError = isInvalid,
                supportingText = if (isInvalid) {
                    { Text("This field is required") }
                } else null,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Utils.hexToColor(colorScheme),
                    focusedLabelColor = Utils.hexToColor(colorScheme)
                )
            )
        }
    }
}

/** Not private: reused by the TV SDK to keep category/purpose ordering identical across both. */
fun parseOrderInt(value: Any?): Int? = when (value) {
    is Int -> value
    is Double -> value.toInt()
    is String -> value.toIntOrNull()
    else -> null
}

fun extractOrderIds(value: Any?): List<Int> {
    if (value !is List<*>) return emptyList()
    return value.mapNotNull { parseOrderInt(it) }
}

/** Not private: reused by the TV SDK to keep category/purpose ordering identical across both. */
fun getOrderedCategories(
    categories: List<ConsentFormResponse.Category>,
    fc: ConsentFormResponse.FormConfiguration?
): List<ConsentFormResponse.Category> {
    val section = fc?.consentCollectionSection
    if (section?.enableCategoryLevelConsent != true) return categories
    val order = section.categoryOrder
    if (order.isNullOrEmpty()) return categories
    val orderIndex = order.withIndex().associate { (i, id) -> id to i }
    return categories.sortedWith(compareBy(nullsLast()) { parseOrderInt(it.processingPurposeCategoryId)?.let(orderIndex::get) })
}

/** Not private: reused by the TV SDK to keep category/purpose ordering identical across both. */
fun getOrderedPurposes(
    category: ConsentFormResponse.Category,
    fc: ConsentFormResponse.FormConfiguration?
): List<ConsentFormResponse.ProcessingPurpose> {
    val purposes = category.purposeList ?: return emptyList()
    if (purposes.isEmpty()) return purposes
    val section = fc?.consentCollectionSection

    var orderIds: List<Int> = emptyList()
    if (section?.enableCategoryLevelConsent == true) {
        val categoryId = parseOrderInt(category.processingPurposeCategoryId)
        val map = section.categoryPurposeOrder
        if (categoryId != null && map != null) {
            for ((key, value) in map) {
                if (parseOrderInt(key) == categoryId) {
                    orderIds = extractOrderIds(value)
                    break
                }
            }
        }
    }
    if (orderIds.isEmpty()) {
        orderIds = section?.processingPurposeOrder ?: emptyList()
        if (orderIds.isEmpty()) return purposes
    }
    val orderIndex = orderIds.withIndex().associate { (i, id) -> id to i }

    fun sortId(purpose: ConsentFormResponse.ProcessingPurpose): Int? {
        val consentPurposeId = purpose.buckets?.firstOrNull()?.let { parseOrderInt(it.consentPurposeId) }
        return if (section?.enableCategoryLevelConsent == true && consentPurposeId != null) {
            consentPurposeId
        } else {
            parseOrderInt(purpose.id)
        }
    }

    return purposes.sortedWith(compareBy(nullsLast()) { sortId(it)?.let(orderIndex::get) })
}

@Composable
fun ConsentSection(
    viewModel: ConsentFormViewModel,
    form: ConsentFormResponse.ConsentFormData?,
    fc: ConsentFormResponse.FormConfiguration?,
    checkAllStatus: Boolean,
    consentRevision: Int,
    isMinorForm: Boolean,
    onCheckAllChange: (Boolean) -> Unit,
    onSync: () -> Unit
) {
    val dataPrincipalCategories = getOrderedCategories(form?.categoryList?.dataPrincipalCategoryList ?: emptyList(), fc)
    val consentActorCategories = getOrderedCategories(form?.categoryList?.consentActorCategoryList ?: emptyList(), fc)
    val categories = dataPrincipalCategories + consentActorCategories

    val enableCategoryLevel = fc?.consentCollectionSection?.enableCategoryLevelConsent == true

    Column(modifier = Modifier.padding(16.dp)) {
        // Preference Input Heading Parity
        form?.basicInfo?.preferenceInputHeading?.let { heading ->
            if (heading.isNotEmpty()) {
                Text(
                    text = heading,
                    style = TextStyleHelper.title,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }
        }

        if (fc?.consentCollectionSection?.showCheckAllCheckbox == true) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ConsentInputControl(
                    fc = fc,
                    value = checkAllStatus,
                    disabled = false,
                    onChanged = onCheckAllChange
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    fc.consentCollectionSection.allCheckboxText ?: "Check All",
                    style = TextStyleHelper.smallHeading
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        if (categories.isEmpty()) {
            // Debug indicator
            Text(
                "No categories available",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        val consentTextAlign = textAlignFor(fc?.sectionAlignments?.consentSection)

        @Composable
        fun renderCategoryGroup(groupCategories: List<ConsentFormResponse.Category>, heading: ConsentFormResponse.Heading?) {
            val visibleCategories = groupCategories.filter { it.visible != false }
            if (visibleCategories.isEmpty()) return

            if (isMinorForm && !heading?.text.isNullOrEmpty()) {
                val headingText = heading?.text ?: ""
                if (looksLikeHtml(headingText)) {
                    HtmlText(
                        html = headingText,
                        colorHex = heading?.color,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Text(
                        text = headingText,
                        style = TextStyleHelper.title,
                        color = Utils.hexToColor(heading?.color),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }

            visibleCategories.forEach { category ->
                if (enableCategoryLevel) {
                    CategoryItem(category, fc, viewModel, consentRevision, onSync)
                } else {
                    // Flattened view
                    getOrderedPurposes(category, fc).forEach { purpose ->
                        if (purpose.visible != false) {
                            purpose.buckets?.forEach { bucket ->
                                if (bucket.visible != false) {
                                    BucketItem(bucket, fc, consentRevision, onSync, consentTextAlign)
                                }
                            }
                        }
                    }
                }
            }
        }

        renderCategoryGroup(dataPrincipalCategories, fc?.piiSection?.dataPrincipalHeading)
        renderCategoryGroup(consentActorCategories, fc?.piiSection?.consentActorHeading)
    }
}

@Composable
fun CategoryItem(
    category: ConsentFormResponse.Category,
    fc: ConsentFormResponse.FormConfiguration?,
    viewModel: ConsentFormViewModel,
    consentRevision: Int,
    onSync: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    // Keyed on the revision counter: consentStatus is not Compose-observable, so without this
    // the category control keeps showing a stale value after a child bucket is toggled.
    val isSelected = remember(consentRevision, category) { viewModel.isCategorySelected(category) }

    val section = fc?.consentCollectionSection
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"
    val showCategoryControl = section?.showConsentInput != false &&
            section?.showCategoryConsentInput != false &&
            section?.showCheckAllCheckbox != true
    val textAlign = textAlignFor(fc?.sectionAlignments?.consentSection)

    OutlinedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showCategoryControl && !inputOnRight) {
                    ConsentInputControl(
                        fc = fc,
                        value = isSelected,
                        disabled = false,
                        onChanged = { viewModel.toggleCategoryConsent(category, it) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = category.processingPurposeCategoryName ?: "",
                    style = TextStyleHelper.title,
                    textAlign = textAlign,
                    modifier = Modifier.weight(1f)
                )
                if (showCategoryControl && inputOnRight) {
                    Spacer(modifier = Modifier.width(8.dp))
                    ConsentInputControl(
                        fc = fc,
                        value = isSelected,
                        disabled = false,
                        onChanged = { viewModel.toggleCategoryConsent(category, it) }
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = if (expanded) "Collapse" else "Expand"
                )
            }
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                getOrderedPurposes(category, fc).forEach { purpose ->
                    if (purpose.visible != false) {
                        purpose.buckets?.forEach { bucket ->
                            if (bucket.visible != false) {
                                BucketItem(bucket, fc, consentRevision, onSync, textAlign)
                            }
                        }
                    }
                }
            }
        }
    }
}

// FlowRow is still an experimental layout in Compose Foundation 1.7.x.
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BucketItem(
    bucket: ConsentFormResponse.ConsentBucket,
    fc: ConsentFormResponse.FormConfiguration?,
    consentRevision: Int,
    onSync: () -> Unit,
    textAlign: TextAlign = TextAlign.Left
) {
    val ct = bucket.ctcpList?.firstOrNull() ?: return

    val status = remember(consentRevision, ct) { ct.consentStatus ?: false }

    val section = fc?.consentCollectionSection
    val showIndividualInput = section?.showConsentInput != false && section?.showIndividualChecks != false
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"

    val toggle: () -> Unit = {
        // A bucket's checkbox represents every ct_cp_map entry it holds (one per pii
        // label/process/vendor) — validateCompulsoryConsents() requires all of them set, so
        // toggling only the first left the others unset and blocked submission.
        val newStatus = !status
        bucket.ctcpList?.forEach { it.consentStatus = newStatus }
        onSync()
    }

    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { toggle() }
    ) {
        if (showIndividualInput && !inputOnRight) {
            // Matches the Column's own top padding below so the checkbox lines up with the
            // heading's first line instead of floating above it.
            Box(modifier = Modifier.padding(top = 12.dp)) {
                ConsentInputControl(fc = fc, value = status, disabled = false, interactive = false, onChanged = {})
            }
            Spacer(modifier = Modifier.width(8.dp))
        }
        Column(
            modifier = Modifier.padding(top = 12.dp).weight(1f),
            horizontalAlignment = when (textAlign) {
                TextAlign.Center -> Alignment.CenterHorizontally
                TextAlign.Right -> Alignment.End
                else -> Alignment.Start
            }
        ) {
            // compulsory_consent can be true on any entry of ct_cp_map_bucket (one per
            // pii label/process/vendor), not just the first
            val isCompulsory = bucket.ctcpList?.any { it.compulsoryConsent == true } == true
            Text(
                text = if (isCompulsory) {
                    buildAnnotatedString {
                        append(bucket.consentPurposeName ?: "")
                        withStyle(SpanStyle(color = Color.Red)) { append(" *") }
                    }
                } else {
                    buildAnnotatedString { append(bucket.consentPurposeName ?: "") }
                },
                style = TextStyleHelper.smallHeading,
                textAlign = textAlign
            )
            bucket.consentPurposeDescription?.let {
                HtmlText(html = it)
            }
            
            // Badges Parity
            if (fc?.piiSection?.showBadges == true && !bucket.piiLabels.isNullOrEmpty()) {
                Row(modifier = Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("PII: ", style = TextStyleHelper.smallHeading.copy(fontSize = 12.sp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        bucket.piiLabels.forEach { label ->
                            Badge(containerColor = Utils.hexToColor(fc.form?.colorScheme)) {
                                Text(label, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp))
                            }
                        }
                    }
                }
            }
            
            if (!bucket.processes.isNullOrEmpty()) {
                Row(modifier = Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Process: ", style = TextStyleHelper.smallHeading.copy(fontSize = 12.sp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        bucket.processes.forEach { p ->
                            Badge(containerColor = Utils.hexToColor(fc?.form?.colorScheme)) {
                                Text(p, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp))
                            }
                        }
                    }
                }
            }
        }
        if (showIndividualInput && inputOnRight) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(modifier = Modifier.padding(top = 12.dp)) {
                ConsentInputControl(fc = fc, value = status, disabled = false, interactive = false, onChanged = {})
            }
        }
    }
}

/** Parses a px-string dimension (e.g. "200", "200px") into Dp, falling back when absent/invalid. */
fun parsePxToDp(value: String?, fallback: Float): androidx.compose.ui.unit.Dp {
    val parsed = value?.trim()?.replace("px", "")?.toFloatOrNull()
    return (parsed ?: fallback).dp
}


fun parsePxToDpOrNull(value: String?): androidx.compose.ui.unit.Dp? =
    value?.trim()?.replace("px", "")?.toFloatOrNull()?.dp


/** Not private: reused by the TV SDK to keep the dynamic-vs-single-submit-button decision identical across both. */
fun shouldShowDynamicButtons(fc: ConsentFormResponse.FormConfiguration?): Boolean {
    val actionButtons = fc?.actionButtons
    if (actionButtons.isNullOrEmpty()) return false
    val secondaryEnabled = actionButtons.firstOrNull { it.id?.lowercase() == "secondary" }?.enabled ?: false
    val tertiaryEnabled = actionButtons.firstOrNull { it.id?.lowercase() == "tertiary" }?.enabled ?: false
    return secondaryEnabled || tertiaryEnabled
}

@Composable
fun SubmitActionSection(
    viewModel: ConsentFormViewModel,
    fc: ConsentFormResponse.FormConfiguration?,
    onPrivacyPolicyClick: () -> Unit
) {
    val context = LocalContext.current
    val useDynamicButtons = shouldShowDynamicButtons(fc)
    val actionButtons = if (useDynamicButtons) fc?.actionButtons?.filter { it.enabled != false } else null
    val isSubmitting by viewModel.isSubmitting.collectAsState()


    Surface(color = Color.White, shadowElevation = 8.dp) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = boxAlignment(fc?.sectionAlignments?.banner)
        ) {
            Column(modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
                if (actionButtons.isNullOrEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (fc?.form?.showPrivacyPolicyUrl != false) {
                            OutlinedButton(
                                onClick = onPrivacyPolicyClick,
                                modifier = Modifier.weight(1f),
                                shape = getButtonShape(fc?.submitButton?.shape, fc?.submitButton?.borderRadius?.toString()),
                                border = BorderStroke(1.dp, Utils.hexToColor(fc?.form?.colorScheme))
                            ) {
                                Text(
                                    fc?.form?.privacyPolicyUrlText ?: "Privacy Policy",
                                    color = Utils.hexToColor(fc?.form?.colorScheme)
                                )
                            }
                        }
                        Button(
                            onClick = { viewModel.submit(context) },
                            enabled = !isSubmitting,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Utils.hexToColor(fc?.form?.colorScheme)),
                            shape = getButtonShape(fc?.submitButton?.shape, fc?.submitButton?.borderRadius?.toString())
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = LocalContentColor.current
                                )
                            } else {
                                Text(fc?.submitButton?.text ?: "Submit")
                            }
                        }
                    }
                } else {
                    val hasPartialSelection by viewModel.hasPartialSelection.collectAsState()
                    val visibleButtons = actionButtons.filter { action ->
                        action.id?.lowercase() != "secondary" || hasPartialSelection
                    }

                    @Composable
                    fun dynamicButton(action: ConsentFormResponse.ActionButton, modifier: Modifier) {
                        val id = action.id?.lowercase()
                        val onClick: () -> Unit = when (id) {
                            "primary" -> { { viewModel.acceptAllAndSubmit(context) } }
                            "tertiary" -> { { viewModel.acceptRequiredAndSubmit(context) } }
                            else -> { { viewModel.submit(context) } }
                        }
                        val containerColor = Utils.hexToColor(action.color ?: fc?.form?.colorScheme)
                        val textColor = Utils.hexToColor(action.textColor ?: "#FFFFFF")
                        Button(
                            onClick = onClick,
                            enabled = !isSubmitting,
                            modifier = modifier,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = containerColor,
                                contentColor = textColor
                            ),
                            shape = getButtonShape(action.shape, action.borderRadius),
                            border = action.borderColor?.let {
                                BorderStroke(
                                    parsePxToDp(action.borderWidth, fallback = 1f),
                                    Utils.hexToColor(it)
                                )
                            }
                        ) {
                            Text(action.text ?: action.id ?: "Submit")
//                            if (isSubmitting) {
//                                CircularProgressIndicator(
//                                    modifier = Modifier.size(18.dp),
//                                    strokeWidth = 2.dp,
//                                    color = textColor
//                                )
//                            } else {
//                                Text(action.text ?: action.id ?: "Submit")
//                            }
                        }
                    }

                    if ((fc?.buttonOrientation ?: "horizontal").lowercase() == "vertical") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            visibleButtons.forEach { action ->
                                dynamicButton(action, Modifier.fillMaxWidth())
                            }
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            visibleButtons.forEach { action ->
                                dynamicButton(action, Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}
