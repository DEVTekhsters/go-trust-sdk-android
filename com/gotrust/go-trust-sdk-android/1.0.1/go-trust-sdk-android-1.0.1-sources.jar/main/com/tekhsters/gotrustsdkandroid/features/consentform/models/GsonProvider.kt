package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import java.lang.reflect.Type


class ConsentFormDataDeserializer : JsonDeserializer<ConsentFormResponse.ConsentFormData> {
    override fun deserialize(
        json: JsonElement,
        typeOfT: Type,
        context: JsonDeserializationContext,
    ): ConsentFormResponse.ConsentFormData {
        val obj = json.asJsonObject
        val fcRaw = obj.getAsJsonObject("form_configuration")
        val fcToUse = fcRaw?.getAsJsonObject("mobile") ?: fcRaw

        return ConsentFormResponse.ConsentFormData(
            additionalInfo = obj["additional_info"]
                ?.let { context.deserialize(it, ConsentFormResponse.AdditionalInfo::class.java) },
            basicInfo = obj["basic_info"]
                ?.let { context.deserialize(it, ConsentFormResponse.BasicInfo::class.java) },
            formConfiguration = fcToUse
                ?.let { context.deserialize(it, ConsentFormResponse.FormConfiguration::class.java) },
            piiList = obj["pii_list"]
                ?.let { context.deserialize(it, ConsentFormResponse.PiiList::class.java) },
            categoryList = obj["category_list"]
                ?.let { context.deserialize(it, ConsentFormResponse.CategoryList::class.java) }
        )
    }
}

object GsonProvider {
    val gson: Gson = GsonBuilder()
        .registerTypeAdapter(ConsentFormResponse.ConsentFormData::class.java, ConsentFormDataDeserializer())
        .create()
}
