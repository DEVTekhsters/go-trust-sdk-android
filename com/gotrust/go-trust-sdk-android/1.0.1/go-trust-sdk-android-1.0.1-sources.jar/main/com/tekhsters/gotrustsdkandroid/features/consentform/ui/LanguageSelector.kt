package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language

@Composable
fun LanguageSelector(
    languages: List<Language>,
    selectedCode: String,
    onChanged: (String) -> Unit,
    colorHex: String?,
    textColor: String?,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        IconButton(onClick = { expanded = true }) {
            Icon(Icons.Default.Language, contentDescription = "Select Language")
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Utils.hexToColor(colorHex))
        ) {
            languages.forEach { lang ->
                val isSelected = lang.code == selectedCode
                DropdownMenuItem(
                    text = {
                        Text(
                            text = lang.name ?: "Unknown",
                            color = Utils.hexToColor(textColor),
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    trailingIcon = {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = Utils.hexToColor(textColor)
                            )
                        }
                    },
                    onClick = {
                        onChanged(lang.code ?: "en")
                        expanded = false
                    }
                )
            }
        }
    }
}
