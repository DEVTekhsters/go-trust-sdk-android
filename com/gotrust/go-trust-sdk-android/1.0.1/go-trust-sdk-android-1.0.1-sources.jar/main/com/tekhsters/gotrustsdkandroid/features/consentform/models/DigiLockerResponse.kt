package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class DigiLockerResponse(
    @SerializedName("authorization_url") val authorizationUrl: String?
)
