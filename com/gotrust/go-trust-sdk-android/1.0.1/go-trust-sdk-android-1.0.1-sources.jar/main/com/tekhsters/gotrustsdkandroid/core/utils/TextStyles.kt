package com.tekhsters.gotrustsdkandroid.core.utils

import android.graphics.Typeface
import android.text.method.LinkMovementMethod
import android.view.ViewGroup
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.text.HtmlCompat
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse

object TextStyleHelper {
    val title = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    val smallHeading = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    val body = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Normal)
}

fun looksLikeHtml(s: String?): Boolean {
    if (s == null) return false
    val lower = s.lowercase()
    return listOf("<p>", "</p>", "<br>", "</br>", "<h1>", "</h1>", "<h2>", "</h2>", "<a ", "</a>")
        .any { lower.contains(it) }
}

fun getFontWeight(weight: String?): FontWeight = when (weight?.trim()) {
    "100" -> FontWeight.Thin
    "200" -> FontWeight.ExtraLight
    "300" -> FontWeight.Light
    "400" -> FontWeight.Normal
    "500" -> FontWeight.Medium
    "600" -> FontWeight.SemiBold
    "700" -> FontWeight.Bold
    "800" -> FontWeight.ExtraBold
    "900" -> FontWeight.Black
    else -> FontWeight.Normal
}

@Composable
fun DynamicTextWidget(
    text: String,
    colorHex: String?,
    fontWeight: FontWeight = FontWeight.Normal,
    fontSize: Double? = null,
    modifier: Modifier = Modifier
) {
    Text(
        text = text,
        color = Utils.hexToColor(colorHex),
        fontWeight = fontWeight,
        fontSize = (fontSize?.toFloat() ?: 16f).sp,
        modifier = modifier
    )
}

@Composable
fun HtmlText(
    html: String,
    modifier: Modifier = Modifier,
    colorHex: String? = null,
    fontSize: Double? = null,
    fontWeight: FontWeight = FontWeight.Normal,
    /** "left" | "center" | "right" — mirrors the CMS's text-align config. */
    align: String? = null,
) {
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { context ->
            TextView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                // HtmlCompat.fromHtml turns <a href> tags into URLSpans, but a plain TextView
                // ignores taps on them without a movement method wired up to follow the link.
                movementMethod = LinkMovementMethod.getInstance()
                setLinksClickable(true)
            }
        },
        update = { view ->
            view.text = HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_COMPACT)
            view.textSize = fontSize?.toFloat() ?: 14f
            view.setTextColor(Utils.hexToColor(colorHex ?: "#000000").toArgb())
            view.setTypeface(
                view.typeface,
                if (fontWeight == FontWeight.Bold || fontWeight.weight >= FontWeight.SemiBold.weight) Typeface.BOLD else Typeface.NORMAL
            )
            view.gravity = when (align?.lowercase()) {
                "center" -> android.view.Gravity.CENTER_HORIZONTAL
                "right" -> android.view.Gravity.END
                else -> android.view.Gravity.START
            }
            view.textAlignment = when (align?.lowercase()) {
                "center" -> TextView.TEXT_ALIGNMENT_CENTER
                "right" -> TextView.TEXT_ALIGNMENT_VIEW_END
                else -> TextView.TEXT_ALIGNMENT_VIEW_START
            }
        }
    )
}

fun parseBorderRadius(value: String?, size: Float = 40f): Float {
    if (value == null) return 0f
    val trimmed = value.trim()
    return if (trimmed.endsWith("%")) {
        val pct = trimmed.removeSuffix("%").toFloatOrNull() ?: 0f
        (size * pct / 100f)
    } else {
        trimmed.replace("px", "").toFloatOrNull() ?: 0f
    }
}

fun getButtonShape(shape: String?, borderRadius: String?): androidx.compose.ui.graphics.Shape {
    val radius = parseBorderRadius(borderRadius).dp
    return if (shape?.lowercase() == "circle") {
        RoundedCornerShape(50)
    } else {
        RoundedCornerShape(radius)
    }
}
