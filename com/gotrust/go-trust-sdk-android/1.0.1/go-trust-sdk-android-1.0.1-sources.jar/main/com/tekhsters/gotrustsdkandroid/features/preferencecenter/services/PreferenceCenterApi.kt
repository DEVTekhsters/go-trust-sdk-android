package com.tekhsters.gotrustsdkandroid.features.preferencecenter.services

import com.google.gson.JsonObject
import com.tekhsters.gotrustsdkandroid.features.consentform.models.CallBackResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.DecrypterApiResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.DigiLockerResponse
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.SendOtpResponse
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.VerifyOtpResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Query

interface PreferenceCenterApi {

    @GET("universal/public/api/v2/translator/language-codes")
    suspend fun fetchLanguages(
        @Query("mode") mode: String = "preference_center",
        @Query("customer_id") customerId: Any,
        @Query("preference_center_id") preferenceCenterId: Any,
    ): Response<JsonObject>

    @GET("universal/public/api/v1/pc/identity/ask")
    suspend fun fetchLoginConfig(
        @Query("customer_id") customerId: Any,
        @Query("preference_form_id") preferenceFormId: Any,
        @Query("language_code") languageCode: String,
    ): Response<JsonObject>

    @Headers("Content-Type: application/json")
    @POST("universal/public/api/v4/pc/otp/send")
    suspend fun sendOtp(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<SendOtpResponse>

    @Headers("Content-Type: application/json")
    @POST("universal/public/api/v4/pc/otp/verify")
    suspend fun verifyOtp(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<VerifyOtpResponse>

    @Headers("Content-Type: application/json")
    @POST("universal/public/api/v6/pc/display")
    suspend fun fetchDashboardData(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<JsonObject>

    @Headers("Content-Type: application/json")
    @POST("universal/public/api/v3/data-collector/pc-records")
    suspend fun saveDashboardPreferences(
        @Header("x-consent-evidence-token") evidenceToken: String?,
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<JsonObject>

    @Headers("Content-Type: application/json", "Accept: application/json")
    @POST("universal/public/api/v1/security/decryptor")
    suspend fun getCustomerAndPreferenceId(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<DecrypterApiResponse>

    @GET("universal/public/api/v3/digilocker/login")
    suspend fun getDigiLockerResponse(
        @Query("redirect_uri") redirectUri: String,
    ): Response<DigiLockerResponse>

    @GET("universal/public/api/v3/digilocker/callback")
    suspend fun getCallbackApiResponse(
        @Query("code") code: String,
        @Query("state") state: String,
    ): Response<CallBackResponse>

    @Headers("Content-Type: application/json")
    @POST("universal/public/api/v4/subject-consent-manager/consent-info/graph")
    suspend fun getConsentFlow(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<JsonObject>

    @GET("universal/public/api/v4/subject-consent-manager/consent-info/per-principals")
    suspend fun fetchConsentAuditLogs(
        @Query("customer_id") customerId: Any,
        @Query("data_principal_ids") dataPrincipalId: Int,
        @Query("detailed") detailed: Boolean = true,
        @Query("unified_person_enabled") unifiedPersonEnabled: Boolean = true,
        @Query("page_number") pageNumber: Int,
        @Query("page_size") pageSize: Int = 10,
    ): Response<JsonObject>
}
