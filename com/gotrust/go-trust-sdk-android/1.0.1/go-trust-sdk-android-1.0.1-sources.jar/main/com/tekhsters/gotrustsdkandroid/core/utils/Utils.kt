package com.tekhsters.gotrustsdkandroid.core.utils


import androidx.compose.ui.graphics.Color

/**
 * Mirrors Flutter's Utils.hexToColor. Supports:
 *  #RGB, #RRGGBB, #AARRGGBB, and bare (no '#') variants.
 * Falls back to black on null/blank/unparsable input.
 */
object Utils {
    /**
     * Normalizes an id field that the backend may send as a JSON number or a JSON string
     * (Gson decodes a dynamically-typed field as Double/String/etc.), collapsing whole-number
     * Doubles to Long and numeric Strings to Int so downstream comparisons don't need to care
     * about the wire type.
     */
    fun safeId(value: Any?): Any? {
        if (value is Double) {
            if (value == value.toLong().toDouble()) return value.toLong()
        }
        if (value is String) {
            return value.toIntOrNull() ?: value
        }
        return value
    }

    fun safeIdString(value: Any?): String? = safeId(value)?.toString()

    fun safeIdInt(value: Any?): Int? = when (val id = safeId(value)) {
        is Number -> id.toInt()
        is String -> id.toIntOrNull()
        else -> null
    }

    fun hexToColor(hex: String?): Color {
        if (hex.isNullOrBlank()) return Color.Black
        return try {
            var value = hex.trim().removePrefix("#")
            if (value.length == 3) {
                // expand shorthand #RGB -> #RRGGBB
                value = value.map { "$it$it" }.joinToString("")
            }
            val colorLong = when (value.length) {
                6 -> 0xFF000000 or value.toLong(16)
                8 -> value.toLong(16)
                else -> return Color.Black
            }
            Color(colorLong)
        } catch (e: Exception) {
            Color.Black
        }
    }
}