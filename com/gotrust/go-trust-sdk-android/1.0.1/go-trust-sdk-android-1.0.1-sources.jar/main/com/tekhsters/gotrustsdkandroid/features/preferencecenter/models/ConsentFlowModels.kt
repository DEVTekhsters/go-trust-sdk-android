package com.tekhsters.gotrustsdkandroid.features.preferencecenter.models

import com.google.gson.JsonObject

/** Mirrors go-trust-mobile-sdk lib/features/consent_preferences/model/consent_record_response_model.dart */
data class ConsentRecord(
    val source: String,
    val collectionTemplate: String,
    val subjectIdentity: String,
    val unifiedPerson: String,
    val processingActivities: String,
    val consentPreferences: String,
    val piiName: String,
    val consentStatus: String,
    val consentedAt: String,
    val language: String,
    val expiredConsent: String,
    val dataRetentionExpired: String,
    val latestConsent: String,
) {
    companion object {
        private fun s(json: JsonObject, key: String): String = J.str(json, key) ?: ""

        fun fromJson(json: JsonObject) = ConsentRecord(
            source = s(json, "source"),
            collectionTemplate = s(json, "collection_template"),
            subjectIdentity = s(json, "subject_identity"),
            unifiedPerson = s(json, "unified_person"),
            processingActivities = s(json, "processing_activities"),
            consentPreferences = s(json, "consent_preferences"),
            piiName = s(json, "pii_name"),
            consentStatus = s(json, "consent_status"),
            consentedAt = s(json, "consented_at"),
            language = s(json, "language"),
            expiredConsent = s(json, "expired_consent"),
            dataRetentionExpired = s(json, "data_retention_expired"),
            latestConsent = s(json, "latest_consent"),
        )
    }
}
