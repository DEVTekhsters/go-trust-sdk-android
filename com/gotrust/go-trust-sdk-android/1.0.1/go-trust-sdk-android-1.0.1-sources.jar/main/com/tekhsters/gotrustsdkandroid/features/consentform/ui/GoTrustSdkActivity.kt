package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.tekhsters.gotrustsdkandroid.core.callbacks.GoTrustSdkCallbacks
import com.tekhsters.gotrustsdkandroid.core.ui.SaveSuccessDialog
import com.tekhsters.gotrustsdkandroid.core.ui.SavingOverlay
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ADDITIONAL_PARAMS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_BASE_URL
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_DATA_JSON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ERROR_MESSAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ERROR_STATUS_CODE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_LANGUAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_MESSAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SHOW_CROSS_BUTTON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SOURCE_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_STATUS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_STATUS_CODE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_TOKEN
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_VIA_LOGIN
import com.tekhsters.gotrustsdkandroid.core.utils.LanguagePreferences
import com.tekhsters.gotrustsdkandroid.core.utils.readCaptchaFlag
import com.tekhsters.gotrustsdkandroid.core.utils.readInitialSubjectValues
import com.tekhsters.gotrustsdkandroid.features.consentform.models.GsonProvider
import kotlinx.coroutines.delay

private const val CLOSED_BY_USER_MESSAGE = "Consent form closed by user"

internal class GoTrustSdkActivity : ComponentActivity() {

    private val viewModel: ConsentFormViewModel by viewModels()

    private var lastSubmitError: ConsentSubmitError? = null

    private var viaLogin: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        LanguagePreferences.init(this)

        val baseUrl = intent.getStringExtra(EXTRA_BASE_URL) ?: ""
        val sourceId = intent.getStringExtra(EXTRA_SOURCE_ID) ?: ""
        val subjectIdentityValues = intent.readInitialSubjectValues()
        val showCrossButton = intent.getBooleanExtra(EXTRA_SHOW_CROSS_BUTTON, true)
        val initialLanguage = intent.getStringExtra(EXTRA_INITIAL_LANGUAGE) ?: "en"
        val enableCaptcha = intent.readCaptchaFlag()
        val token = intent.getStringExtra(EXTRA_TOKEN)
        viaLogin = intent.getBooleanExtra(EXTRA_VIA_LOGIN, false)
        @Suppress("UNCHECKED_CAST")
        val additionalParams = intent.getSerializableExtra(EXTRA_ADDITIONAL_PARAMS) as? Map<String, Any> ?: emptyMap()

        viewModel.init(
            baseUrl = baseUrl,
            sourceId = sourceId,
            subjectIdentityValues = subjectIdentityValues,
            additionalParams = additionalParams,
            initialLanguage = initialLanguage,
            enableCaptcha = enableCaptcha,
            fallback = if (viaLogin) null else GoTrustSdkCallbacks.fallback,
            token = token,
        )

        setContent {
            MaterialTheme {
                // Explicit white: M3's default surface colour is a lavender-tinted white, which
                // reads as a discoloured band next to the form's pure-white content.
                Surface(color = Color.White) {
                    val state by viewModel.uiState.collectAsState()
                    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
                    val isSubmitting by viewModel.isSubmitting.collectAsState()
                    val submitSuccess by viewModel.submitSuccess.collectAsState()
                    val submitError by viewModel.submitError.collectAsState()
                    val consentFormData by viewModel.consentForm.collectAsState()
                    val snackbarHostState = remember { SnackbarHostState() }

                    LaunchedEffect(snackbarMessage) {
                        snackbarMessage?.let {
                            snackbarHostState.showSnackbar(it)
                            viewModel.consumeSnackbar()
                        }
                    }

                    // A rejected submission is not terminal — the form stays up for another
                    // attempt — so the error is handed to the host here rather than at finish().
                    LaunchedEffect(submitError) {
                        submitError?.let { error ->
                            lastSubmitError = error
                            hostCallbacks()?.onError?.invoke(error.statusCode, error.message)
                            viewModel.consumeSubmitError()
                        }
                    }

                    BackHandler {
                        // Ignored while a submission is in flight; once it succeeds the success
                        // dialog owns the back press and closing is driven by its dismissal.
                        if (!isSubmitting && submitSuccess == null) {
                            closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                        }
                    }

                    // Every screen below hosts its own Scaffold and handles its own window
                    // insets, so this outer one must not apply them a second time — doing so
                    // padded the app bar down by an extra status-bar height and left a strip of
                    // this Scaffold's background showing above it and below the action buttons.
                    Scaffold(
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        containerColor = Color.White,
                        contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    ) { padding ->
                        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
                            when (val s = state) {
                                is ConsentFormUiState.Loading -> {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator()
                                    }
                                }
                                is ConsentFormUiState.Success -> {
                                    ConsentFormScreen(
                                        viewModel = viewModel,
                                        onClose = {
                                            closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                                        },
                                        showCrossButton = showCrossButton
                                    )
                                }
                                is ConsentFormUiState.PrivacyNoticeGating -> {
                                    val form by viewModel.consentForm.collectAsState()
                                    val languages by viewModel.languages.collectAsState()
                                    val selectedLang by viewModel.selectedLanguage.collectAsState()
                                    val privacyData by viewModel.privacyData.collectAsState()
                                    val privacyLoading by viewModel.isLoadingPrivacyNotice.collectAsState()

                                    PrivacyNoticeScreen(
                                        languages = languages,
                                        selectedLanguage = selectedLang,
                                        onLanguageChanged = { viewModel.onLanguageChanged(it) },
                                        privacyData = privacyData,
                                        formConfig = form?.formConfiguration,
                                        onAgree = { lang, id, version ->
                                            viewModel.onPrivacyNoticeAgreed(lang, id, version)
                                        },
                                        onClose = {
                                            // The mandatory pre-consent gate has no form behind it to
                                            // fall back to, so its cross button must end the whole
                                            // session rather than just dismissing this screen.
                                            if (s.isPreConsentGate) {
                                                closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                                            } else {
                                                viewModel.closePrivacyNotice()
                                            }
                                        },
                                        showCrossButton = showCrossButton,
                                        isLoading = privacyLoading
                                    )
                                }
                                is ConsentFormUiState.DigiLockerVerification -> {
                                    DigiLockerWebView(
                                        url = s.url,
                                        onSuccess = { code, otpState -> viewModel.onDigiLockerSuccess(code, otpState) }
                                    )
                                }
                                is ConsentFormUiState.Error -> {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(s.message)
                                            Button(onClick = { viewModel.loadAll() }) {
                                                Text("Retry")
                                            }
                                            Button(onClick = {
                                                closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                                            }) {
                                                Text("Close")
                                            }
                                        }
                                    }
                                }
                                is ConsentFormUiState.MinorVerificationFailed -> {
                                    AlertDialog(
                                        onDismissRequest = {},
                                        title = { Text("Verification Failed") },
                                        text = { Text(s.message) },
                                        confirmButton = {
                                            TextButton(onClick = {
                                                closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                                            }) {
                                                Text("Close")
                                            }
                                        }
                                    )
                                }
                            }

                            // Overlays below render on top of whichever branch above is active
                            // (normally the form itself) rather than replacing it, so submitting
                            // never navigates away from the consent form.

                            if (isSubmitting) {
                                SavingOverlay(message = "Submitting consent…")
                            }

                            val success = submitSuccess
                            if (success != null) {
                                val finish = {
                                    closeWithResult(
                                        status = "success",
                                        statusCode = success.statusCode,
                                        message = success.message,
                                        dataJson = GsonProvider.gson.toJson(success.data),
                                        successData = success.data
                                    )
                                }
                                // Auto-dismiss matches the Flutter SDK's 3s delay before popping;
                                // tapping Done or outside the dialog closes immediately instead.
                                LaunchedEffect(success) {
                                    delay(3000)
                                    finish()
                                }
                                SaveSuccessDialog(
                                    message = success.message,
                                    onDismiss = finish,
                                    accentColorHex = consentFormData?.formConfiguration?.form?.colorScheme,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun closeWithResult(
        status: String,
        statusCode: Int? = null,
        message: String? = null,
        dataJson: String? = null,
        successData: List<Map<String, Any?>>? = null
    ) {
        val resultIntent = Intent().apply {
            putExtra(EXTRA_STATUS, status)
            statusCode?.let { putExtra(EXTRA_STATUS_CODE, it) }
            message?.let { putExtra(EXTRA_MESSAGE, it) }
            dataJson?.let { putExtra(EXTRA_DATA_JSON, it) }
            // Surfaced for result-only hosts; callback hosts already got this via onError. Omitted
            // on a successful close — a retry that eventually worked is not a failed session.
            if (status != "success") {
                lastSubmitError?.let { error ->
                    error.statusCode?.let { putExtra(EXTRA_ERROR_STATUS_CODE, it) }
                    error.message?.let { putExtra(EXTRA_ERROR_MESSAGE, it) }
                }
            }
        }
        setResult(if (status == "success") Activity.RESULT_OK else Activity.RESULT_CANCELED, resultIntent)

        val callbacks = hostCallbacks()
        if (status == "success") {
            callbacks?.onSuccess?.invoke(statusCode, message, successData.orEmpty())
        } else {
            callbacks?.onClose?.invoke(message)
        }
        // Terminal for this session — drop the registration so a host lambda that captured the
        // launching Activity is not held past this screen.
        if (!viaLogin) GoTrustSdkCallbacks.clearConsentForm()

        finish()
    }

    /** Host callbacks, or `null` for a nested preference-center launch. See [viaLogin]. */
    private fun hostCallbacks() =
        if (viaLogin) null else GoTrustSdkCallbacks.consentForm
}
