package com.tekhsters.gotrustsdkandroid.features.consentform.services

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.*
import kotlin.coroutines.resume

data class RecaptchaTokenResult(
    val token: String,
    val generatedAt: Date
)

sealed class RecaptchaAttemptResult {
    data class Success(val tokenResult: RecaptchaTokenResult) : RecaptchaAttemptResult()
    data class Failure(val exception: Exception) : RecaptchaAttemptResult()

    val isSuccess: Boolean get() = this is Success
}

class RecaptchaException(message: String) : Exception(message)

class RecaptchaService private constructor() {

    companion object {
        private const val TAG = "RecaptchaService"
        private const val SUBMIT_ACTION = "consent_submit"
        private const val TIMEOUT_MS = 20000L
        private const val SITE_KEY = "6LdRvtgsAAAAAGjdNICrOMiI5wXDld5r33otoP9p"

        @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
        suspend fun generateSubmitToken(context: Context): RecaptchaAttemptResult {
            val handler = Handler(Looper.getMainLooper())
            val generatedAt = Date()

            return suspendCancellableCoroutine { continuation ->
                handler.post {
                    val webView = WebView(context)
                    webView.settings.javaScriptEnabled = true

                    val timeoutRunnable = Runnable {
                        if (continuation.isActive) {
                            continuation.resume(RecaptchaAttemptResult.Failure(RecaptchaException("Timeout")))
                        }
                    }
                    handler.postDelayed(timeoutRunnable, TIMEOUT_MS)

                    webView.addJavascriptInterface(object {
                        @JavascriptInterface
                        fun postMessage(token: String) {
                            handler.removeCallbacks(timeoutRunnable)
                            handler.post {
                                if (continuation.isActive) {
                                    if (token.isEmpty()) {
                                        continuation.resume(RecaptchaAttemptResult.Failure(RecaptchaException("Empty token")))
                                    } else if (token.startsWith("ERROR:")) {
                                        continuation.resume(RecaptchaAttemptResult.Failure(RecaptchaException(token.removePrefix("ERROR:"))))
                                    } else {
                                        continuation.resume(RecaptchaAttemptResult.Success(RecaptchaTokenResult(token, generatedAt)))
                                    }
                                }
                                webView.destroy()
                            }
                        }
                    }, "recaptchaToken")

                    webView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            // Page finished, JS should execute grecaptcha
                        }
                    }

                    val html = buildRecaptchaHtml(SITE_KEY, SUBMIT_ACTION)
                    webView.loadDataWithBaseURL("https://gotrust.tech", html, "text/html", "UTF-8", null)
                }
            }
        }

        private fun buildRecaptchaHtml(siteKey: String, action: String): String {
            return """
                <!DOCTYPE html>
                <html>
                <head>
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <script src="https://www.google.com/recaptcha/api.js?render=$siteKey"></script>
                </head>
                <body>
                <script>
                  function sendToken(message) {
                    recaptchaToken.postMessage(message);
                  }
                  grecaptcha.ready(function() {
                    grecaptcha.execute('$siteKey', {action: '$action'}).then(function(token) {
                      sendToken(token || '');
                    }).catch(function(error) {
                      sendToken('ERROR:' + (error && error.message ? error.message : 'execute_failed'));
                    });
                  });
                </script>
                </body>
                </html>
            """.trimIndent()
        }
    }
}
