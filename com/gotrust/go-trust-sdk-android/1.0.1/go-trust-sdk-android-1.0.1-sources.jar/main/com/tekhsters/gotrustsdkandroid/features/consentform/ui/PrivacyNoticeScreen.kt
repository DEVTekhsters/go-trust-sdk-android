package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tekhsters.gotrustsdkandroid.core.utils.DynamicTextWidget
import com.tekhsters.gotrustsdkandroid.core.utils.HtmlText
import com.tekhsters.gotrustsdkandroid.core.utils.TextStyleHelper
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language
import com.tekhsters.gotrustsdkandroid.features.consentform.models.PrivacyNoticeResponse

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyNoticeScreen(
    languages: List<Language>,
    selectedLanguage: String,
    onLanguageChanged: (String) -> Unit,
    privacyData: List<PrivacyNoticeResponse.PrivacyData>,
    formConfig: ConsentFormResponse.FormConfiguration?,
    onAgree: (language: String, id: Int, version: Double) -> Unit,
    onClose: () -> Unit,
    showCrossButton: Boolean = true,
    isLoading: Boolean = false
) {
    val listState = rememberLazyListState()
    var agreeEnabled by remember(privacyData) { mutableStateOf(false) }

    // React to every layout pass (not just canScrollForward flips) so content that already
    // fits the viewport - no scroll ever happens - still unlocks Agree, and re-layouts from
    // language changes or resizes are picked up too.
    LaunchedEffect(listState) {
        snapshotFlow { listState.layoutInfo }
            .collect { info ->
                if (info.totalItemsCount > 0 && !listState.canScrollForward) {
                    agreeEnabled = true
                }
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    DynamicTextWidget(
                        text = formConfig?.form?.privacyPolicyUrlText ?: "Privacy Notice",
                        colorHex = formConfig?.form?.heading?.color ?: "#000000"
                    )
                },
                actions = {
                    if (formConfig?.form?.showLanguage == true) {
                        LanguageSelector(
                            languages = languages,
                            selectedCode = selectedLanguage,
                            onChanged = onLanguageChanged,
                            colorHex = formConfig.form.languageDropDown?.backgroundColor,
                            textColor = formConfig.form.languageDropDown?.textColor
                        )
                    }
                    if (showCrossButton) {
                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    scrolledContainerColor = Color.White
                )
            )
        },
        containerColor = Color.White,
        bottomBar = {
            Surface(color = Color.White, shadowElevation = 8.dp) {
                Column(modifier = Modifier.navigationBarsPadding().padding(16.dp)) {
                    Button(
                        onClick = {
                            if (privacyData.isNotEmpty()) {
                                val first = privacyData.first()
                                onAgree(selectedLanguage, first.id ?: 0, first.version ?: 1.0)
                            }
                        },
                        enabled = agreeEnabled,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Utils.hexToColor(formConfig?.form?.colorScheme)
                        )
                    ) {
                        Text("Agree & Continue")
                    }
                    if (!agreeEnabled) {
                        Text(
                            "Scroll to bottom to enable Agree button",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    ) { padding ->
        if (isLoading && privacyData.isEmpty()) {
            Box(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = Utils.hexToColor(formConfig?.form?.colorScheme))
            }
            return@Scaffold
        }

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp),
            modifier = Modifier.padding(padding)
        ) {
            items(privacyData) { data ->
                data.content?.forEach { content ->
                    Column(modifier = Modifier.padding(bottom = 16.dp)) {
                        Text(
                            text = content.title ?: "",
                            style = TextStyleHelper.smallHeading
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        HtmlText(html = content.content ?: "")
                    }
                }
            }
        }
    }
}
