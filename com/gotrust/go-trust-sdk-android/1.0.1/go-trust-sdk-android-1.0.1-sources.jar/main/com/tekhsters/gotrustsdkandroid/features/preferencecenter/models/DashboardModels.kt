package com.tekhsters.gotrustsdkandroid.features.preferencecenter.models

import com.google.gson.JsonObject

/** Mirrors go-trust-mobile-sdk lib/features/consent_preferences/model/dashboard_model.dart */
data class DashboardResponse(
    val success: Boolean?,
    val statusCode: Int?,
    val message: String?,
    val result: DashboardResult?,
) {
    companion object {
        fun fromJson(json: JsonObject) = DashboardResponse(
            success = J.bool(json, "success"),
            statusCode = J.int(json, "status_code"),
            message = J.str(json, "message"),
            result = J.obj(json, "result")?.let { DashboardResult.fromJson(it) },
        )
    }
}

data class DashboardResult(val data: DashboardData?) {
    companion object {
        fun fromJson(json: JsonObject) = DashboardResult(J.obj(json, "data")?.let { DashboardData.fromJson(it) })
    }
}

data class DashboardData(
    val additionalInfo: AdditionalInfo?,
    val basicInfo: BasicInfo?,
    val preferenceCenterConfiguration: DashboardPreferenceCenterConfiguration?,
    val privacyNote: List<PrivacyNote>?,
    val dsr: Dsr?,
    val ucmPreferenceForm: List<UcmPreferenceForm>?,
) {
    companion object {
        fun fromJson(json: JsonObject): DashboardData {
            val rawConfig = J.obj(json, "preference_center_configuration")
            val config = when {
                rawConfig != null && J.obj(rawConfig, "mobile") != null ->
                    DashboardPreferenceCenterConfiguration.fromJson(J.obj(rawConfig, "mobile")!!)
                rawConfig != null -> DashboardPreferenceCenterConfiguration.fromJson(rawConfig)
                else -> null
            }
            return DashboardData(
                additionalInfo = J.obj(json, "additional_info")?.let { AdditionalInfo.fromJson(it) },
                basicInfo = J.obj(json, "basic_info")?.let { BasicInfo.fromJson(it) },
                preferenceCenterConfiguration = config,
                privacyNote = J.arr(json, "privacy_note")
                    ?.mapNotNull { if (it.isJsonObject) PrivacyNote.fromJson(it.asJsonObject) else null },
                dsr = J.obj(json, "dsr")?.let { Dsr.fromJson(it) },
                ucmPreferenceForm = J.arr(json, "ucm_preference_form")
                    ?.mapNotNull { if (it.isJsonObject) UcmPreferenceForm.fromJson(it.asJsonObject) else null },
            )
        }
    }
}

data class AdditionalInfo(
    val preferenceCenterId: Any?,
    val customerId: Any?,
    val entityId: Int?,
    val status: Boolean?,
    val verificationKey: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = AdditionalInfo(
            preferenceCenterId = J.int(json, "preference_center_id"),
            customerId = J.str(json, "customer_id") ?: J.int(json, "customer_id")?.toString(),
            entityId = J.int(json, "entity_id"),
            status = J.bool(json, "status"),
            verificationKey = J.str(json, "verification_key"),
        )
    }
}

data class BasicInfo(
    val title: String?,
    val description: String?,
    val privacyNoticeHeading: String?,
    val preferenceCenterHeading: String?,
    val dsrCenterHeading: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = BasicInfo(
            title = J.str(json, "title"),
            description = J.str(json, "description"),
            privacyNoticeHeading = J.str(json, "privacy_notice_heading"),
            preferenceCenterHeading = J.str(json, "preference_center_heading"),
            dsrCenterHeading = J.str(json, "dsr_center_heading"),
        )
    }
}

data class DashboardPreferenceCenterConfiguration(
    val fontFamily: String?,
    val logoUrl: String?,
    val showLogo: Boolean?,
    val showCookie: Boolean?,
    val showConsent: Boolean?,
    val showConsentFlow: Boolean?,
    val showDSR: Boolean?,
    val privacyNoticeHeading: String?,
    val preferenceCenterHeading: String?,
    val dsrCenterHeading: String?,
    val consentFlowHeading: String?,
    val auditLogsHeading: String?,
    val dsrUrl: String?,
    val dpoEmail: String?,
    val consentPurposeConfiguration: ConsentPurposeConfiguration?,
) {
    companion object {
        fun fromJson(json: JsonObject) = DashboardPreferenceCenterConfiguration(
            fontFamily = J.str(json, "fontFamily"),
            logoUrl = J.str(json, "logoUrl"),
            showLogo = J.bool(json, "showLogo"),
            showCookie = J.bool(json, "showCookie"),
            showConsent = J.bool(json, "showConsent"),
            showConsentFlow = J.bool(json, "showConsentFlow"),
            showDSR = J.bool(json, "showDSR"),
            privacyNoticeHeading = J.str(json, "privacy_notice_heading"),
            preferenceCenterHeading = J.str(json, "preference_center_heading"),
            dsrCenterHeading = J.str(json, "dsr_center_heading"),
            consentFlowHeading = J.str(json, "consent_flow_heading"),
            auditLogsHeading = J.str(json, "audit_logs_heading"),
            dsrUrl = J.str(json, "dsrURL"),
            dpoEmail = J.str(json, "dpoEmail"),
            consentPurposeConfiguration = J.obj(json, "consent_purpose_configuration")
                ?.let { ConsentPurposeConfiguration.fromJson(it) },
        )
    }
}

data class PrivacyNote(val id: String?, val title: String?, val content: String?) {
    companion object {
        fun fromJson(json: JsonObject) = PrivacyNote(
            id = J.str(json, "id"),
            title = J.str(json, "title"),
            content = J.str(json, "content"),
        )
    }
}

data class Dsr(val needDsrCenter: Boolean?, val dsrContent: String?) {
    companion object {
        fun fromJson(json: JsonObject) = Dsr(
            needDsrCenter = J.bool(json, "need_dsr_center"),
            dsrContent = J.str(json, "dsr_content"),
        )
    }
}

data class UcmPreferenceCategoryList(
    val consentActorCategoryList: List<UcmPreferenceCategory>?,
    val dataPrincipalCategoryList: List<UcmPreferenceCategory>?,
) {
    companion object {
        fun fromJson(json: JsonObject) = UcmPreferenceCategoryList(
            consentActorCategoryList = J.arr(json, "CONSENT_ACTOR")
                ?.mapNotNull { if (it.isJsonObject) UcmPreferenceCategory.fromJson(it.asJsonObject) else null },
            dataPrincipalCategoryList = J.arr(json, "DATA_PRINCIPAL")
                ?.mapNotNull { if (it.isJsonObject) UcmPreferenceCategory.fromJson(it.asJsonObject) else null },
        )
    }
}

data class UcmPreferenceForm(
    val customerId: String?,
    val collectionTemplateId: Any?,
    val dataPrincipalId: Int?,
    val categoryList: UcmPreferenceCategoryList?,
    val purposeList: List<UcmProcessingPurpose>?,
) {
    companion object {
        fun fromJson(json: JsonObject) = UcmPreferenceForm(
            customerId = J.str(json, "customer_id") ?: J.int(json, "customer_id")?.toString(),
            collectionTemplateId = J.int(json, "collection_template_id"),
            dataPrincipalId = J.int(json, "data_principal_id"),
            categoryList = J.obj(json, "category_list")?.let { UcmPreferenceCategoryList.fromJson(it) },
            purposeList = J.arr(json, "purpose_list")
                ?.mapNotNull { if (it.isJsonObject) UcmProcessingPurpose.fromJson(it.asJsonObject) else null },
        )
    }
}

data class UcmPreferenceCategory(
    val processingPurposeCategoryId: Int?,
    val processingPurposeCategoryName: String?,
    val purposeList: List<UcmProcessingPurpose>?,
    val ucmPreferenceVisible: Boolean?,
) {
    companion object {
        fun fromJson(json: JsonObject) = UcmPreferenceCategory(
            processingPurposeCategoryId = J.int(json, "processing_purpose_category_id"),
            processingPurposeCategoryName = J.str(json, "processing_purpose_category_name"),
            purposeList = J.arr(json, "purpose_list")
                ?.mapNotNull { if (it.isJsonObject) UcmProcessingPurpose.fromJson(it.asJsonObject) else null },
            ucmPreferenceVisible = J.bool(json, "visible"),
        )
    }
}

data class UcmProcessingPurpose(
    val processingPurposeId: Int?,
    val processingPurposeName: String?,
    val consentBucket: List<UcmConsentBucket>?,
    val ucmPreferenceVisible: Boolean?,
) {
    companion object {
        fun fromJson(json: JsonObject) = UcmProcessingPurpose(
            processingPurposeId = J.int(json, "processing_purpose_id"),
            processingPurposeName = J.str(json, "processing_purpose_name"),
            consentBucket = J.arr(json, "consent_bucket")
                ?.mapNotNull { if (it.isJsonObject) UcmConsentBucket.fromJson(it.asJsonObject) else null },
            ucmPreferenceVisible = J.bool(json, "visible"),
        )
    }
}

data class UcmConsentBucket(
    val consentPurposeId: Int?,
    val consentPurposeName: String?,
    val consentPurposeDescription: String?,
    val piiLabels: List<String>?,
    val processes: List<String>?,
    val ctCpMapBucket: List<UcmCtCpMap>?,
    val ucmPreferenceVisible: Boolean?,
) {
    companion object {
        fun fromJson(json: JsonObject) = UcmConsentBucket(
            consentPurposeId = J.int(json, "consent_purpose_id"),
            consentPurposeName = J.str(json, "consent_purpose_name"),
            consentPurposeDescription = J.str(json, "consent_purpose_description"),
            piiLabels = J.stringList(json, "pii_labels"),
            processes = J.stringList(json, "processes"),
            ctCpMapBucket = J.arr(json, "ct_cp_map_bucket")
                ?.mapNotNull { if (it.isJsonObject) UcmCtCpMap.fromJson(it.asJsonObject) else null },
            ucmPreferenceVisible = J.bool(json, "visible"),
        )
    }
}

/** [consentStatus] is mutated in place by the dashboard UI as the user toggles consents. */
data class UcmCtCpMap(
    val id: Int?,
    val collectionTemplateId: Int?,
    val dataPrincipalId: Int?,
    val processingPurposeId: Int?,
    val processingPurposeName: String?,
    val consentPurposeId: Int?,
    val consentPurposeName: String?,
    val piiLabelId: Int?,
    val piiLabel: String?,
    val frequency: Any?,
    val consentLifetime: Int?,
    val consentExpiration: String?,
    val defaultOptOutAllowed: Boolean?,
    val compulsoryConsent: Boolean?,
    var consentStatus: Boolean?,
    val backendConsentStatus: String?,
    val manualRevokeBool: Boolean?,
    val manualGrantBool: Boolean?,
    val vendorId: Int?,
    val vendorName: String?,
    val processId: Int?,
    val processName: String?,
    val ucmPreferenceVisible: Boolean?,
    val ucmPrincipleContext: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = UcmCtCpMap(
            id = J.int(json, "id"),
            collectionTemplateId = J.int(json, "collection_template_id"),
            dataPrincipalId = J.int(json, "data_principal_id"),
            processingPurposeId = J.int(json, "processing_purpose_id"),
            processingPurposeName = J.str(json, "processing_purpose_name"),
            consentPurposeId = J.int(json, "consent_purpose_id"),
            consentPurposeName = J.str(json, "consent_purpose_name"),
            piiLabelId = J.int(json, "pii_label_id"),
            piiLabel = J.str(json, "pii_label"),
            frequency = J.str(json, "frequency"),
            consentLifetime = J.int(json, "consent_lifetime"),
            consentExpiration = J.str(json, "consent_expiration"),
            defaultOptOutAllowed = J.bool(json, "default_opt_out_allowed"),
            compulsoryConsent = J.bool(json, "compulsory_consent"),
            consentStatus = J.bool(json, "consent_status"),
            backendConsentStatus = J.str(json, "backend_consent_status"),
            manualRevokeBool = J.bool(json, "manual_revoke_bool"),
            manualGrantBool = J.bool(json, "manual_grant_bool"),
            vendorId = J.int(json, "vendor_id"),
            vendorName = J.str(json, "vendor_name"),
            processId = J.int(json, "process_id"),
            processName = J.str(json, "process_name"),
            ucmPreferenceVisible = J.bool(json, "visible"),
            ucmPrincipleContext = J.str(json, "principal_context"),
        )
    }
}

data class ConsentPurposeConfiguration(
    val form: DashboardForm?,
    val piiSection: PiiSection?,
    val consentCollectionSection: ConsentCollectionSection?,
    val formFooter: FormFooter?,
    val submitButton: DashboardHeading?,
    val preferenceSectionAlignments: PreferenceSectionAlignments?,
    val sectionPadding: SectionPaddingResponse?,
) {
    companion object {
        fun fromJson(json: JsonObject) = ConsentPurposeConfiguration(
            form = J.obj(json, "form")?.let { DashboardForm.fromJson(it) },
            piiSection = J.obj(json, "pii_section")?.let { PiiSection.fromJson(it) },
            consentCollectionSection = J.obj(json, "consent_collection_section")
                ?.let { ConsentCollectionSection.fromJson(it) },
            formFooter = J.obj(json, "form_footer")?.let { FormFooter.fromJson(it) },
            submitButton = J.obj(json, "submit_button")?.let { DashboardHeading.fromJson(it) },
            preferenceSectionAlignments = J.obj(json, "section_alignments")
                ?.let { PreferenceSectionAlignments.fromJson(it) },
            sectionPadding = J.obj(json, "section_padding")?.let { SectionPaddingResponse.fromJson(it) },
        )
    }
}

data class PreferenceSectionAlignments(
    val submitAction: String?,
    val footer: String?,
    val consentSection: String?,
    val purposeList: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = PreferenceSectionAlignments(
            submitAction = J.str(json, "submit_action"),
            footer = J.str(json, "footer"),
            consentSection = J.str(json, "consent_section"),
            purposeList = J.str(json, "purpose_list"),
        )
    }
}

data class SectionPaddingResponse(
    val consentSection: SectionPadding?,
    val purposeList: SectionPadding?,
    val footer: SectionPadding?,
    val submitAction: SectionPadding?,
) {
    companion object {
        fun fromJson(json: JsonObject) = SectionPaddingResponse(
            consentSection = J.obj(json, "consent_section")?.let { SectionPadding.fromJson(it) },
            purposeList = J.obj(json, "purpose_list")?.let { SectionPadding.fromJson(it) },
            footer = J.obj(json, "footer")?.let { SectionPadding.fromJson(it) },
            submitAction = J.obj(json, "submit_action")?.let { SectionPadding.fromJson(it) },
        )
    }
}

data class SectionPadding(val left: String?, val right: String?) {
    companion object {
        fun fromJson(json: JsonObject) = SectionPadding(J.str(json, "left"), J.str(json, "right"))
    }
}

data class ConsentCollectionSection(
    val showCheckAllCheckbox: Boolean?,
    val allCheckboxText: String?,
    val showIndividualChecks: Boolean?,
    val heading: DashboardHeading?,
    val description: DashboardHeading?,
    val processingPurposeOrder: List<Int>?,
    val enableCategoryLevelConsent: Boolean?,
    val consentInputType: String?,
    val consentInputPosition: String?,
    val showConsentInput: Boolean?,
    val showCategoryConsentInput: Boolean?,
    val categoryOrder: List<Int>?,
    val consentOrder: List<Int>?,
    val categoryPurposeOrder: Map<String, com.google.gson.JsonElement>?,
    val categoryConsentOrder: Map<String, com.google.gson.JsonElement>?,
    val showDescription: Boolean?,
    val checkboxBorderRadius: String?,
    val consentActorHeading: DashboardHeading?,
    val consentActorDescription: DashboardHeading?,
    val dataPrincipleHeading: DashboardHeading?,
    val dataPrincipleDescription: DashboardHeading?,
) {
    companion object {
        fun fromJson(json: JsonObject) = ConsentCollectionSection(
            showCheckAllCheckbox = J.bool(json, "show_check_all_checkbox"),
            allCheckboxText = J.str(json, "all_checkbox_text"),
            showIndividualChecks = J.bool(json, "show_individual_checks"),
            heading = J.obj(json, "heading")?.let { DashboardHeading.fromJson(it) },
            description = J.obj(json, "description")?.let { DashboardHeading.fromJson(it) },
            processingPurposeOrder = J.intList(json, "processing_purpose_order"),
            enableCategoryLevelConsent = J.bool(json, "enable_category_level_consent"),
            consentInputType = J.str(json, "consent_input_type"),
            consentInputPosition = J.str(json, "consent_input_position"),
            showConsentInput = J.bool(json, "show_consent_input"),
            showCategoryConsentInput = J.bool(json, "show_category_consent_input"),
            categoryOrder = J.intList(json, "category_order"),
            consentOrder = J.intList(json, "consent_order"),
            categoryPurposeOrder = J.rawMap(json, "category_purpose_order"),
            categoryConsentOrder = J.rawMap(json, "category_consent_order"),
            showDescription = J.bool(json, "show_description"),
            checkboxBorderRadius = J.str(json, "checkbox_border_radius"),
            consentActorHeading = J.obj(json, "consent_actor_heading")?.let { DashboardHeading.fromJson(it) },
            consentActorDescription = J.obj(json, "consent_actor_description")?.let { DashboardHeading.fromJson(it) },
            dataPrincipleHeading = J.obj(json, "data_principal_heading")?.let { DashboardHeading.fromJson(it) },
            dataPrincipleDescription = J.obj(json, "data_principal_description")?.let { DashboardHeading.fromJson(it) },
        )
    }
}

data class DashboardForm(
    val logo: DashboardLogo?,
    val heading: DashboardHeading?,
    val description: DashboardHeading?,
    val fontFamily: String?,
    val colorScheme: String?,
    val borderRadius: String?,
    val privacyPolicyUrl: String?,
    val showPrivacyPolicyUrl: Boolean?,
    val privacyPolicyUrlText: String?,
    val showLanguage: Boolean?,
    val languageDropDown: DashboardLanguageDropdown?,
    val headerLayout: DashboardHeaderLayout?,
) {
    companion object {
        fun fromJson(json: JsonObject) = DashboardForm(
            logo = J.obj(json, "logo")?.let { DashboardLogo.fromJson(it) },
            heading = J.obj(json, "heading")?.let { DashboardHeading.fromJson(it) },
            description = J.obj(json, "description")?.let { DashboardHeading.fromJson(it) },
            fontFamily = J.str(json, "font_family"),
            colorScheme = J.str(json, "color_scheme"),
            borderRadius = J.str(json, "border_radius"),
            privacyPolicyUrl = J.str(json, "privacy_policy_url"),
            showPrivacyPolicyUrl = J.bool(json, "show_privacy_policy_url"),
            privacyPolicyUrlText = J.str(json, "privacy_policy_url_text"),
            showLanguage = J.bool(json, "show_language"),
            languageDropDown = J.obj(json, "language_dropdown")?.let { DashboardLanguageDropdown.fromJson(it) },
            headerLayout = J.obj(json, "header_layout")?.let { DashboardHeaderLayout.fromJson(it) },
        )
    }
}

data class DashboardHeaderLayout(
    val closeIconPosition: String?,
    val dropdownPosition: String?,
    val logoPosition: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = DashboardHeaderLayout(
            closeIconPosition = J.str(json, "close_icon_position"),
            dropdownPosition = J.str(json, "dropdown_position"),
            logoPosition = J.str(json, "logo_position"),
        )
    }
}

data class DashboardLanguageDropdown(
    val backgroundColor: String?,
    val borderRadius: String?,
    val shape: String?,
    val textColor: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = DashboardLanguageDropdown(
            backgroundColor = J.str(json, "background_color"),
            borderRadius = J.str(json, "border_radius"),
            shape = J.str(json, "shape"),
            textColor = J.str(json, "text_color"),
        )
    }
}

data class PiiSection(
    val showPiiSection: Boolean?,
    val showLabels: Boolean?,
    val showBadges: Boolean?,
    val heading: DashboardHeading?,
    val description: DashboardHeading?,
) {
    companion object {
        fun fromJson(json: JsonObject) = PiiSection(
            showPiiSection = J.bool(json, "show_pii_section"),
            showLabels = J.bool(json, "show_labels"),
            showBadges = J.bool(json, "show_badges"),
            heading = J.obj(json, "heading")?.let { DashboardHeading.fromJson(it) },
            description = J.obj(json, "description")?.let { DashboardHeading.fromJson(it) },
        )
    }
}

data class FormFooter(val heading: DashboardHeading?, val description: DashboardHeading?) {
    companion object {
        fun fromJson(json: JsonObject) = FormFooter(
            heading = J.obj(json, "heading")?.let { DashboardHeading.fromJson(it) },
            description = J.obj(json, "description")?.let { DashboardHeading.fromJson(it) },
        )
    }
}

/** Dashboard's own (simpler) Heading shape — distinct from the login/OTP config's Heading. */
data class DashboardHeading(
    val text: String?,
    val color: String?,
    val size: String?,
    val backgroundColor: String?,
    val headingFontWeight: String?,
    val headingFontFamily: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = DashboardHeading(
            text = J.str(json, "text"),
            color = J.str(json, "color"),
            size = J.str(json, "size"),
            backgroundColor = J.str(json, "background_color"),
            headingFontWeight = J.str(json, "font_weight"),
            headingFontFamily = J.str(json, "font_family"),
        )
    }
}

data class DashboardLogo(
    val showLogo: Boolean?,
    val logoUrl: String?,
    val width: String?,
    val height: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = DashboardLogo(
            showLogo = J.bool(json, "show_logo"),
            logoUrl = J.str(json, "logo_url"),
            width = J.str(json, "width"),
            height = J.str(json, "height"),
        )
    }
}
