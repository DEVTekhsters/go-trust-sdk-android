package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class DecrypterApiResponse(
    @SerializedName("success") val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("token") val token: String?,
    @SerializedName("result") val result: Result?,
    @SerializedName("time") val time: Long?
) {
    data class Result(
        @SerializedName("token") val token: String?,
        @SerializedName("data") val data: DecryptorData?
    )

    data class DecryptorData(
        @SerializedName("source_id") val sourceId: Any?,
        @SerializedName("pf_id") val pfId: Any?,
        @SerializedName("customer_id") val customerId: Any?,
        @SerializedName("is_minor") val isMinor: Boolean?,
        @SerializedName("token") val token: String?,
        @SerializedName("subject_identity_values") val subjectIdentityValues: List<PiiValue>?,
        @SerializedName("pii_list") val piiList: List<PiiValue>?,
    )

    data class PiiValue(
        @SerializedName("pii_label_id") val piiLabelId: Any?,
        @SerializedName("pii_label_name") val piiLabelName: String?,
        @SerializedName("pii_value") val piiValue: Any?,
    )
}
