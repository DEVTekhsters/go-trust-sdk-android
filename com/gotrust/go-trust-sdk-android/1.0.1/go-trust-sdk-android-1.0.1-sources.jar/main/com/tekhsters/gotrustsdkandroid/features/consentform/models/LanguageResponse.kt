package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class Language(
    @SerializedName("language_code") val code: String?,
    @SerializedName("language") val name: String?
)
