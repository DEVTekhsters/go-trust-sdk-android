@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.GsonBuilder
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentTransaction
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.MetaInfo

@Composable
fun AuditLogsTab(viewModel: PreferenceCenterViewModel, dataPrincipalId: Int, accentColor: Color) {
    val items = remember { mutableStateOf(listOf<ConsentTransaction>()) }
    var page by remember { mutableIntStateOf(1) }
    var loadingFirst by remember { mutableStateOf(true) }
    var loadingMore by remember { mutableStateOf(false) }
    var hasMore by remember { mutableStateOf(true) }
    var subjectIdentity by remember { mutableStateOf<String?>(null) }
    var payloadToShow by remember { mutableStateOf<ConsentTransaction?>(null) }

    suspend fun loadFirstPage() {
        loadingFirst = true
        hasMore = true
        page = 1
        val result = viewModel.fetchConsentAuditLogs(dataPrincipalId, 1)
        if (result != null) {
            items.value = result.items
            subjectIdentity = result.items.firstOrNull()?.subjectIdentity
            if (result.items.isEmpty()) hasMore = false
        }
        loadingFirst = false
    }

    suspend fun loadNextPage() {
        if (!hasMore || loadingMore) return
        loadingMore = true
        val next = page + 1
        val result = viewModel.fetchConsentAuditLogs(dataPrincipalId, next)
        if (result != null) {
            page = next
            items.value = items.value + result.items
            if (result.items.isEmpty()) hasMore = false
        }
        loadingMore = false
    }

    LaunchedEffect(Unit) { loadFirstPage() }

    val listState = rememberLazyListState()
    val shouldLoadMore by remember {
        derivedStateOf {
            val visibleItems = listState.layoutInfo.visibleItemsInfo
            val lastVisible = visibleItems.lastOrNull()?.index ?: 0
            val total = listState.layoutInfo.totalItemsCount
            total > visibleItems.size && lastVisible >= total - 1
        }
    }
    LaunchedEffect(shouldLoadMore, hasMore, loadingMore, loadingFirst) {
        if (shouldLoadMore && hasMore && !loadingMore && !loadingFirst) loadNextPage()
    }

    when {
        loadingFirst -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        items.value.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No data") }
        else -> {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(12.dp)) {
                item {
                    AuditLogHeader(subjectIdentity ?: "-")
                    Spacer(Modifier.height(12.dp))
                }
                items(items.value) { tx ->
                    TransactionCard(tx = tx, onViewPayload = { payloadToShow = tx })
                    Spacer(Modifier.height(12.dp))
                }
                item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 18.dp), contentAlignment = Alignment.Center) {
                        when {
                            loadingMore -> CircularProgressIndicator()
                            !hasMore -> Text("No more records", color = Color(0xFF546E7A), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    val tx = payloadToShow
    if (tx != null) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { payloadToShow = null }, sheetState = sheetState) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.85f)
                    .padding(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Payload", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { payloadToShow = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
                Divider()
                Spacer(Modifier.height(10.dp))
                val pretty = remember(tx) {
                    GsonBuilder().setPrettyPrinting().create().toJson(
                        com.google.gson.JsonParser.parseString(tx.rawJson.toString())
                    )
                }
                Text(
                    pretty,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 24.dp),
                )
            }
        }
    }
}

@Composable
private fun AuditLogHeader(subjectIdentity: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp))
            .padding(14.dp),
    ) {
        Text(subjectIdentity, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "Complete audit trail with granular consent interaction history",
            color = Color(0xFF546E7A),
            fontSize = 12.sp,
        )
    }
}

@Composable
private fun TransactionCard(tx: ConsentTransaction, onViewPayload: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp)),
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top,
        ) {
            FlowRow(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SmallTag(Icons.Default.Link, shortId(tx.consentTransactionId))
                SmallTag(Icons.Default.Description, tx.collectionTemplateName)
                SmallTag(Icons.Default.Public, tx.consentSource)
                SmallTag(Icons.Default.Apartment, tx.entityName)
                StatusChip(tx.aggregatedConsentStatus)
            }
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onViewPayload) {
                Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.width(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("View Payload")
            }
        }
        Divider()
        tx.metaInfo.forEachIndexed { index, meta ->
            MetaRow(tx = tx, meta = meta)
            if (index != tx.metaInfo.lastIndex) Divider()
        }
    }
}

@Composable
private fun MetaRow(tx: ConsentTransaction, meta: MetaInfo) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Top) {
        FlowRow(
            modifier = Modifier.weight(4f),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            StatusChip(meta.consentStatus)
            Pill(meta.consentPurposeName)
            Pill(meta.piiLabelName)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(6f)) {
            InfoItem("Template", meta.collectionTemplateName)
            InfoItem("Reviewed Privacy Notice", if (meta.reviewedPrivacyNotice) "Yes" else "No")
            InfoItem("Expires", dashIfEmpty(meta.consentExpiration))
            InfoItem("Consent At", dashIfEmpty(tx.consentedAt))
            InfoItem("Privacy notice", meta.privacyNoteName)
            InfoItem("Vendor name", dashIfEmpty(meta.vendorName))
            InfoItem("Language", meta.language)
            InfoItem("Privacy notice Version", meta.privacyNoteVersion?.toString() ?: "-")
            InfoItem("Process name", dashIfEmpty(meta.processingPurposeName))
            InfoItem("Frequency", dashIfEmpty(meta.frequency))
        }
    }
}

@Composable
private fun InfoItem(key: String, value: String) {
    Column(Modifier.padding(bottom = 8.dp)) {
        Text(key, fontSize = 11.sp, color = Color(0xFF78909C))
        Text(value.ifEmpty { "-" }, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF212121))
    }
}

@Composable
private fun SmallTag(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        Modifier
            .background(Color(0xFFF3F4F6), RoundedCornerShape(999.dp))
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.width(14.dp), tint = Color(0xFF546E7A))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 12.sp, color = Color(0xFF37474F), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Pill(text: String) {
    Row(
        Modifier
            .background(Color.White, RoundedCornerShape(999.dp))
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text.ifEmpty { "-" }, fontSize = 12.sp, color = Color(0xFF37474F), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun StatusChip(status: String) {
    val s = status.lowercase().trim()
    val (bg, fg) = when (s) {
        "granted" -> Color(0xFFDCFCE7) to Color(0xFF166534)
        "declined" -> Color(0xFFFEE2E2) to Color(0xFF991B1B)
        "withdrawn" -> Color(0xFFFFEDD5) to Color(0xFF9A3412)
        else -> Color(0xFFE5E7EB) to Color(0xFF111827)
    }
    Row(
        Modifier
            .background(bg, RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(s.ifEmpty { "-" }.uppercase(), fontSize = 12.sp, color = fg, fontWeight = FontWeight.Black)
    }
}

private fun shortId(id: String): String {
    if (id.length <= 18) return id
    return "${id.take(7)}…${id.takeLast(6)}"
}

private fun dashIfEmpty(value: String?): String {
    val s = value?.trim().orEmpty()
    return s.ifEmpty { "-" }
}
