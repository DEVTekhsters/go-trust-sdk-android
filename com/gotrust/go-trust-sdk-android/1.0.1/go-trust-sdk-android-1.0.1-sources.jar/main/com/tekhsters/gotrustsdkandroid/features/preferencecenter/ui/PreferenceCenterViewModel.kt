package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tekhsters.gotrustsdkandroid.core.utils.LanguagePreferences
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.CallBackResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.DecrypterApiResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentAuditPageResult
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentRecord
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.DashboardData
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.LoginConfig
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.UcmConsentBucket
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.UcmCtCpMap
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.UcmPreferenceCategory
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.UcmProcessingPurpose
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.services.PreferenceCenterApiService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PreferenceCenterViewModel : ViewModel() {

    private val api = PreferenceCenterApiService.instance

    private val _uiState = MutableStateFlow<PreferenceCenterUiState>(PreferenceCenterUiState.Loading)
    val uiState: StateFlow<PreferenceCenterUiState> = _uiState.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()
    fun consumeSnackbar() { _snackbarMessage.value = null }

    /**
     * Save outcomes, emitted per attempt. Neither is terminal — the dashboard stays mounted either
     * way — so the activity forwards them to the host's `onSuccess`/`onError` as they happen rather
     * than folding them into the activity result, matching the Flutter SDK's closures.
     */
    private val _saveSuccessEvent = MutableStateFlow<PreferenceSaveSuccess?>(null)
    val saveSuccessEvent: StateFlow<PreferenceSaveSuccess?> = _saveSuccessEvent.asStateFlow()
    fun consumeSaveSuccessEvent() { _saveSuccessEvent.value = null }

    private val _saveErrorEvent = MutableStateFlow<String?>(null)
    val saveErrorEvent: StateFlow<String?> = _saveErrorEvent.asStateFlow()
    fun consumeSaveErrorEvent() { _saveErrorEvent.value = null }

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    // Separate from _isBusy so resending the OTP doesn't also light up the Verify button
    // (and vice versa) — the two actions are independent even though both hit the API.
    private val _isResendBusy = MutableStateFlow(false)
    val isResendBusy: StateFlow<Boolean> = _isResendBusy.asStateFlow()

    private val _languages = MutableStateFlow<List<Language>>(emptyList())
    val languages: StateFlow<List<Language>> = _languages.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("en")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _loginConfig = MutableStateFlow<LoginConfig?>(null)
    val loginConfig: StateFlow<LoginConfig?> = _loginConfig.asStateFlow()

    private val _consentFormLaunchRequest = MutableStateFlow<ConsentFormLaunchRequest?>(null)
    val consentFormLaunchRequest: StateFlow<ConsentFormLaunchRequest?> = _consentFormLaunchRequest.asStateFlow()
    fun consumeConsentFormLaunchRequest() { _consentFormLaunchRequest.value = null }

    /** Text field values for each subject identity type id, keyed by id. */
    val subjectIdentityInputs = mutableStateMapOf<Int, String>()

    /**
     * Which identity fields the user has unlocked for editing, keyed by type id. Tracked per
     * identity rather than as one shared flag so that a form configured with several identities
     * (say email *and* phone) gets an edit affordance on each row, and unlocking one does not
     * silently open the others.
     */
    private val editingSubjectIdentities = mutableStateMapOf<Int, Boolean>()

    // ---- OTP state ----
    private var pendingSubjectIdentityValues: List<Map<String, Any?>> = emptyList()

    /** Set once the consent form hand-off has come back successfully for the identity currently
     * typed into the login form. It stops [submitLogin] from re-entering the "user does not exist"
     * branch — the login flow is resumed from where it was interrupted instead of restarted, so the
     * consent form is presented at most once per identity. Cleared whenever the user edits an
     * identity field, since a different identity may need its own consent. */
    private var consentCompletedForPendingLogin = false

    val otpRemainingSeconds = mutableIntStateOf(120)
    val otpResendEnabled = mutableStateOf(false)

    // ---- Dashboard state ----
    /** Plain (non-Compose-state) holder — nested UcmCtCpMap.consentStatus is mutated in place,
     * so composables must key their recomposition off [dashboardRevision] rather than this field. */
    var dashboardData: DashboardData? = null
        private set
    private val _dashboardRevision = mutableIntStateOf(0)
    val dashboardRevision: State<Int> = _dashboardRevision
    private fun bumpDashboard() { _dashboardRevision.intValue++ }

    val multiSelectConsentValue = mutableStateOf(false)

    /** Subtle full-screen spinner shown only while the save request is in flight (mirrors
     * Flutter's `Loader.display`/`Loader.close`) — not a spinner inside the Update button. */
    val savingOverlayVisible = mutableStateOf(false)

    /** Non-blocking success confirmation shown as an overlay on top of the dashboard (which stays
     * mounted and untouched underneath it — no reload, no navigation) until the user dismisses it. */
    val saveSuccessMessage = mutableStateOf<String?>(null)
    private var saveSuccessAutoDismissJob: kotlinx.coroutines.Job? = null

    /** Bumped when the success dialog is dismissed so DashboardScreen can reset its selected tab
     * back to Privacy Notice, matching the Flutter SDK's DefaultTabController-recreation behavior. */
    private val _resetToFirstTabSignal = mutableIntStateOf(0)
    val resetToFirstTabSignal: State<Int> = _resetToFirstTabSignal

    fun dismissSaveSuccessDialog() {
        saveSuccessAutoDismissJob?.cancel()
        saveSuccessMessage.value = null
        _resetToFirstTabSignal.intValue++
    }

    private var digiLockerCallbackData: CallBackResponse.CallBackData? = null
    private var digiLockerIsMinor: Boolean? = null

    // ---- init params ----
    private var baseUrl: String = ""
    private var customerIdParam: String? = null
    private var preferenceFormIdParam: String? = null
    private var pfToken: String = ""
    private var token: String? = null
    private var consentId: String = ""
    private var initialSubjectValues: Map<String, Any> = emptyMap()
    private var additionalParams: Map<String, Any> = emptyMap()
    private var enableCaptcha: Boolean = true

    // Whatever type the decryptor hands back (numeric or an opaque encrypted string) is kept as-is
    // and forwarded unchanged into later requests — coercing it to a fixed Int/String has broken
    // this before when the value turned out not to be numeric.
    private var resolvedCustomerId: Any? = null
    private var resolvedPfId: Any? = null
    var isMinor: Boolean = false
        private set

    /** Decryptor response from the most recent [loadLoginConfig], kept for its identity/PII
     *  payload in token flow — matches the Flutter SDK's `_decryptedData`. */
    private var decryptedData: DecrypterApiResponse? = null

    /** A non-empty [token] (which wins over [pfToken]) replaces every widget-supplied identifier. */
    private val isTokenFlow: Boolean get() = !token.isNullOrEmpty()

    /** Effective subject identity values: the decryptor's own answer in token flow, otherwise
     *  whatever the caller passed in — matches the Flutter SDK's `_effectiveSubjectIdentityValues`. */
    private val effectiveSubjectIdentityValues: Map<String, Any>
        get() = if (isTokenFlow) {
            (decryptedData?.result?.data?.subjectIdentityValues ?: emptyList())
                .associate { Utils.safeId(it.piiLabelId).toString() to (it.piiValue ?: "") }
        } else initialSubjectValues

    private val effectiveAdditionalParams: Map<String, Any>
        get() = if (isTokenFlow) {
            (decryptedData?.result?.data?.piiList ?: emptyList())
                .associate { Utils.safeId(it.piiLabelId).toString() to (it.piiValue ?: "") }
        } else additionalParams

    fun init(
        baseUrl: String,
        customerId: String?,
        preferenceFormId: String?,
        pfToken: String,
        consentId: String,
        initialSubjectValues: Map<String, Any>,
        additionalParams: Map<String, Any>,
        initialLanguage: String = "en",
        enableCaptcha: Boolean = true,
        token: String? = null,
    ) {
        this.baseUrl = baseUrl
        this.customerIdParam = customerId
        this.preferenceFormIdParam = preferenceFormId
        this.pfToken = pfToken
        this.token = token
        this.consentId = consentId
        this.initialSubjectValues = initialSubjectValues
        this.additionalParams = additionalParams
        // Flutter's LoginPage/OtpPage/dashboard all start from the persisted language unless the
        // caller asked for a specific one, so a pick made in the consent form carries over here.
        this._selectedLanguage.value = LanguagePreferences.resolveInitial(initialLanguage)
        this.enableCaptcha = enableCaptcha
        api.setBaseUrl(baseUrl)
        loadLoginConfig()
    }

    /** Configured name of a subject identity type, by its id. */
    private fun subjectIdentityName(id: Int): String? =
        _loginConfig.value?.subjectIdentityTypes?.firstOrNull { it.id == id }?.name

    /** True when the field for [id] collects a phone number and so carries the static country code. */
    fun isPhoneSubjectIdentity(id: Int): Boolean = PhoneIdentity.isPhoneLabel(subjectIdentityName(id))

    /**
     * The value of a subject identity exactly as it goes into a payload — phone numbers carry the
     * `+91` that the login screen shows as a fixed prefix. Also used for the OTP screen's
     * "code sent to …" line so the UI and the payload can never disagree.
     */
    fun subjectIdentityPayloadValue(id: Int): String =
        PhoneIdentity.forLabel(subjectIdentityName(id), subjectIdentityInputs[id])

    private fun buildSubjectIdentityValuesFromInputs(): List<Map<String, Any?>> =
        subjectIdentityInputs.entries.map { (id, _) ->
            mapOf("pii_label_id" to id, "pii_value" to subjectIdentityPayloadValue(id))
        }

    fun loadLoginConfig() {
        viewModelScope.launch {
            _uiState.value = PreferenceCenterUiState.Loading
            try {
                val decrypted = api.getCustomerAndPreferenceId(customerIdParam, preferenceFormIdParam, pfToken, token)
                decryptedData = decrypted
                resolvedCustomerId = Utils.safeId(decrypted?.result?.data?.customerId)
                resolvedPfId = Utils.safeId(decrypted?.result?.data?.pfId)
                isMinor = decrypted?.result?.data?.isMinor ?: false

                val pfId = resolvedPfId
                val custId = resolvedCustomerId
                if (pfId != null && custId != null) {
                    _loginConfig.value = api.fetchLoginConfig(pfId, custId, _selectedLanguage.value)
                }
                _languages.value = api.fetchLanguages()

                _loginConfig.value?.subjectIdentityTypes?.forEach { si ->
                    val id = si.id ?: return@forEach
                    if (id !in subjectIdentityInputs) {
                        val prefill = effectiveSubjectIdentityValues[id.toString()]?.toString() ?: ""
                        // Phone fields display "+91" as a fixed prefix, so a host-supplied value
                        // that already includes the country code must not be shown behind it too.
                        subjectIdentityInputs[id] =
                            if (PhoneIdentity.isPhoneLabel(si.name)) PhoneIdentity.strip(prefill) else prefill
                    }
                }

                val isAuthEnabled = _loginConfig.value?.configuration?.verifyInputConfiguration?.authentication ?: true
                if (!isAuthEnabled) {
                    pendingSubjectIdentityValues = buildSubjectIdentityValuesFromInputs()
                    loadDashboard()
                    return@launch
                }

                _uiState.value = PreferenceCenterUiState.Login
            } catch (e: Exception) {
                _uiState.value = PreferenceCenterUiState.Error(e.message ?: "Unable to load preference center")
            }
        }
    }

    fun onLanguageChanged(code: String) {
        _selectedLanguage.value = code
        LanguagePreferences.write(code)
        when (_uiState.value) {
            is PreferenceCenterUiState.Dashboard -> loadDashboard()
            is PreferenceCenterUiState.Otp -> reloadOtpConfig()
            else -> loadLoginConfig()
        }
    }

    private var reloadOtpConfigJob: Job? = null

    /**
     * Re-fetches the login config (which carries the OTP screen's copy) and the language list in
     * the newly selected language, without touching `_uiState` - a language switch on the OTP
     * screen must refresh its strings in place, not bounce the user back to Login.
     */
    private fun reloadOtpConfig() {
        reloadOtpConfigJob?.cancel()
        reloadOtpConfigJob = viewModelScope.launch {
            try {
                val pfId = resolvedPfId
                val custId = resolvedCustomerId
                if (pfId != null && custId != null) {
                    _loginConfig.value = api.fetchLoginConfig(pfId, custId, _selectedLanguage.value)
                }
                _languages.value = api.fetchLanguages()
            } catch (e: Exception) {
                _snackbarMessage.value = "Error: ${e.message}"
            }
        }
    }

    fun onSubjectIdentityChanged(id: Int, value: String) {
        // The country code is fixed and shown as a prefix, so a typed or pasted "+91" is folded
        // away instead of accumulating in front of the national number.
        val normalized = if (isPhoneSubjectIdentity(id)) PhoneIdentity.strip(value) else value
        if (subjectIdentityInputs[id] != normalized) consentCompletedForPendingLogin = false
        subjectIdentityInputs[id] = normalized
    }

    /** Whether the field for [id] is currently unlocked for editing. */
    fun isEditingSubjectIdentity(id: Int): Boolean = editingSubjectIdentities[id] == true

    fun toggleEditingSubjectIdentity(id: Int) {
        editingSubjectIdentities[id] = !isEditingSubjectIdentity(id)
    }

    fun submitLogin() {
        val values = buildSubjectIdentityValuesFromInputs()
        if (values.any { (it["pii_value"] as? String).isNullOrBlank() }) {
            _snackbarMessage.value = "Please fill all required fields."
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val resp = api.sendOtp(values)
                    ?: run { _snackbarMessage.value = "No response from server."; return@launch }
                if (resp.userFound == false) {
                    // Previous behavior diverted to the Consent Form here, but that flow requires
                    // a mandatory sourceId which isn't always available in this path. Commented
                    // out rather than removed — see PreferenceCenterConfig.consentId.
                    // pendingSubjectIdentityValues = values
                    // val typedValues = values.associate { it["pii_label_id"].toString() to (it["pii_value"] ?: "") }
                    // _consentFormLaunchRequest.value = ConsentFormLaunchRequest(
                    //     sourceId = consentId,
                    //     initialSubjectValues = effectiveSubjectIdentityValues + typedValues,
                    //     additionalParams = effectiveAdditionalParams,
                    //     initialLanguage = _selectedLanguage.value,
                    //     baseUrl = baseUrl,
                    //     enableCaptcha = enableCaptcha,
                    // )
                    _uiState.value = PreferenceCenterUiState.ConsentNotGiven
                } else {
                    continueAfterIdentityAccepted(values)
                }
            } catch (e: Exception) {
                _snackbarMessage.value = "Error: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    /**
     * Resumes the interrupted login once the identity is known to the backend: either straight to
     * the dashboard when the form is configured without authentication, or to OTP verification.
     * The OTP itself was already dispatched by the `otp/send` call that got us here.
     */
    private fun continueAfterIdentityAccepted(values: List<Map<String, Any?>>) {
        pendingSubjectIdentityValues = values
        val isAuthEnabled = _loginConfig.value?.configuration?.verifyInputConfiguration?.authentication ?: true
        if (!isAuthEnabled) {
            loadDashboard()
            return
        }
        otpRemainingSeconds.intValue = 120
        otpResendEnabled.value = false
        _uiState.value = PreferenceCenterUiState.Otp
    }

    /**
     * Called after the consent-form hand-off activity returns a success result.
     *
     * Resumes the login flow from where it was interrupted rather than restarting it: the user now
     * exists, so all that is left is to generate the OTP and move on to verification (or to the
     * dashboard when the form's configuration disables authentication). Re-running [submitLogin]
     * here re-evaluated `user_found` and reopened the consent form in a loop.
     */
    fun onConsentFormSubmitted() {
        consentCompletedForPendingLogin = true
        val values = pendingSubjectIdentityValues.ifEmpty { buildSubjectIdentityValuesFromInputs() }
        if (values.any { (it["pii_value"] as? String).isNullOrBlank() }) {
            _snackbarMessage.value = "Please fill all required fields."
            return
        }
        val isAuthEnabled = _loginConfig.value?.configuration?.verifyInputConfiguration?.authentication ?: true
        if (!isAuthEnabled) {
            pendingSubjectIdentityValues = values
            loadDashboard()
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            try {
                // Request the OTP for the just-created user. The response's `user_found` is
                // deliberately not re-checked — consent has been given, so the flow continues
                // regardless and a stale `false` can no longer strand the user on the login screen.
                api.sendOtp(values)
                continueAfterIdentityAccepted(values)
            } catch (e: Exception) {
                _snackbarMessage.value = "Error: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    /** Called when the consent-form hand-off activity returns without a successful submission. */
    fun onConsentFormDismissed() {
        // Consent was never recorded, so the next login attempt must be allowed to present the
        // form again instead of walking into an OTP screen for a user that does not exist.
        consentCompletedForPendingLogin = false
    }

    fun resendOtp() {
        viewModelScope.launch {
            _isResendBusy.value = true
            try {
                api.sendOtp(pendingSubjectIdentityValues)
                otpRemainingSeconds.intValue = 120
                otpResendEnabled.value = false
                _snackbarMessage.value = "Code resent"
            } catch (e: Exception) {
                _snackbarMessage.value = "Error: ${e.message}"
            } finally {
                _isResendBusy.value = false
            }
        }
    }

    fun verifyOtp(otp: String) {
        if (otp.length != 6) return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val resp = api.verifyOtp(otp, pendingSubjectIdentityValues)
                if (resp?.success == true && !resp.token.isNullOrEmpty()) {
                    loadDashboard()
                } else {
                    _snackbarMessage.value = resp?.message ?: "Invalid OTP"
                }
            } catch (e: Exception) {
                _snackbarMessage.value = "Error: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    private var loadDashboardJob: Job? = null

    private fun loadDashboard() {
        // A language switch fired while a previous load is still in flight must not let that
        // older request's response (and the evidence token it carries) land after this one's -
        // cancelling it outright is simpler and more robust than racing to ignore its result.
        loadDashboardJob?.cancel()
        loadDashboardJob = viewModelScope.launch {
            _uiState.value = PreferenceCenterUiState.Loading
            try {
                val data = api.fetchDashboardData(pendingSubjectIdentityValues, _selectedLanguage.value)
                dashboardData = data
                if (data?.additionalInfo?.preferenceCenterId != null) {
                    val langs = api.fetchLanguages()
                    _languages.value = langs
                    _selectedLanguage.value = langs.firstOrNull { it.code == _selectedLanguage.value }?.code
                        ?: langs.firstOrNull()?.code ?: "en"
                }
                syncMultiSelectConsentValue()
                bumpDashboard()
                if (data == null) {
                    _uiState.value = PreferenceCenterUiState.Error("Unable to load preference center")
                } else {
                    _uiState.value = PreferenceCenterUiState.Dashboard
                }
            } catch (e: Exception) {
                _uiState.value = PreferenceCenterUiState.Error(e.message ?: "Unable to load preference center")
            }
        }
    }

    fun reloadDashboard() = loadDashboard()

    // ---------------------------------------------------------------------
    // Dashboard: category/purpose tree helpers
    // ---------------------------------------------------------------------

    /** A preference center can span several collection templates (see `additional_info
     * .collection_template_ids`), each surfaced as its own entry in [DashboardData.ucmPreferenceForm]
     * — categories/purposes must be aggregated across all of them, not just the first, or later
     * templates' purposes silently disappear from the dashboard. */
    fun allCategories(): List<UcmPreferenceCategory> {
        val list = dataPrincipalCategories() + consentActorCategories()
        if (list.isEmpty()) {
            val purposeList = dashboardData?.ucmPreferenceForm.orEmpty().flatMap { it.purposeList.orEmpty() }
            if (purposeList.isNotEmpty()) {
                return listOf(UcmPreferenceCategory(null, null, purposeList, null))
            }
        }
        return list
    }

    /** Kept separate from [consentActorCategories] so the minor-form UI can show the
     * "Data Principal"/"Consent Actor" headings above each group; see [allCategories] for the
     * combined, order-agnostic list used everywhere else. */
    fun dataPrincipalCategories(): List<UcmPreferenceCategory> =
        dashboardData?.ucmPreferenceForm.orEmpty().flatMap { it.categoryList?.dataPrincipalCategoryList.orEmpty() }

    fun consentActorCategories(): List<UcmPreferenceCategory> =
        dashboardData?.ucmPreferenceForm.orEmpty().flatMap { it.categoryList?.consentActorCategoryList.orEmpty() }

    private fun ucmPurposes(): List<UcmProcessingPurpose> =
        allCategories().flatMap { it.purposeList.orEmpty() }

    fun syncMultiSelectConsentValue() {
        var hasAny = false
        var allSelected = true
        for (purpose in ucmPurposes()) {
            for (bucket in purpose.consentBucket.orEmpty()) {
                for (ct in bucket.ctCpMapBucket.orEmpty()) {
                    hasAny = true
                    if (ct.consentStatus != true) allSelected = false
                }
            }
        }
        multiSelectConsentValue.value = hasAny && allSelected
    }

    fun toggleAllConsents(value: Boolean) {
        for (purpose in ucmPurposes()) {
            for (bucket in purpose.consentBucket.orEmpty()) {
                for (ct in bucket.ctCpMapBucket.orEmpty()) {
                    ct.consentStatus = value
                }
            }
        }
        multiSelectConsentValue.value = value
        bumpDashboard()
    }

    fun toggleBucketConsent(bucket: UcmConsentBucket, value: Boolean) {
        bucket.ctCpMapBucket.orEmpty().forEach { it.consentStatus = value }
        syncMultiSelectConsentValue()
        bumpDashboard()
    }

    fun getCategoryConsentValue(category: UcmPreferenceCategory): Boolean {
        var hasAny = false
        var hasUnselected = false
        for (purpose in category.purposeList.orEmpty()) {
            for (bucket in purpose.consentBucket.orEmpty()) {
                for (ct in bucket.ctCpMapBucket.orEmpty()) {
                    hasAny = true
                    if (ct.consentStatus != true) hasUnselected = true
                }
            }
        }
        return hasAny && !hasUnselected
    }

    fun isCategoryConsentControlDisabled(category: UcmPreferenceCategory): Boolean {
        for (purpose in category.purposeList.orEmpty()) {
            for (bucket in purpose.consentBucket.orEmpty()) {
                if (bucket.ctCpMapBucket.orEmpty().isNotEmpty()) return false
            }
        }
        return true
    }

    fun applyCategoryConsent(category: UcmPreferenceCategory, value: Boolean) {
        for (purpose in category.purposeList.orEmpty()) {
            for (bucket in purpose.consentBucket.orEmpty()) {
                for (ct in bucket.ctCpMapBucket.orEmpty()) {
                    ct.consentStatus = value
                }
            }
        }
        syncMultiSelectConsentValue()
        bumpDashboard()
    }

    fun getOrderedCategories(categories: List<UcmPreferenceCategory>): List<UcmPreferenceCategory> {
        val section = dashboardData?.preferenceCenterConfiguration?.consentPurposeConfiguration?.consentCollectionSection
        if (section?.enableCategoryLevelConsent != true) return categories
        val order = section.categoryOrder.orEmpty()
        if (order.isEmpty()) return categories
        val orderIndex = order.withIndex().associate { (i, id) -> id to i }
        return categories.sortedWith(compareBy(nullsLast()) { orderIndex[it.processingPurposeCategoryId] })
    }

    fun getOrderedPurposes(category: UcmPreferenceCategory): List<UcmProcessingPurpose> {
        val purposes = category.purposeList.orEmpty()
        if (purposes.isEmpty()) return purposes
        val section = dashboardData?.preferenceCenterConfiguration?.consentPurposeConfiguration?.consentCollectionSection
        var orderIds: List<Int> = emptyList()
        if (section?.enableCategoryLevelConsent == true) {
            val map = section.categoryPurposeOrder
            val categoryId = category.processingPurposeCategoryId
            if (categoryId != null && map != null) {
                for ((key, value) in map) {
                    if (key.toIntOrNull() == categoryId && value.isJsonArray) {
                        orderIds = value.asJsonArray.mapNotNull {
                            if (it.isJsonPrimitive) it.asJsonPrimitive.asString.toIntOrNull() else null
                        }
                        break
                    }
                }
            }
        }
        if (orderIds.isEmpty()) {
            orderIds = section?.processingPurposeOrder.orEmpty()
            if (orderIds.isEmpty()) return purposes
        }
        val orderIndex = orderIds.withIndex().associate { (i, id) -> id to i }
        fun sortId(p: UcmProcessingPurpose): Int? {
            val consentPurposeId = p.consentBucket?.firstOrNull()?.consentPurposeId
            if (section?.enableCategoryLevelConsent == true && consentPurposeId != null) return consentPurposeId
            return p.processingPurposeId
        }
        return purposes.sortedWith(compareBy(nullsLast()) { orderIndex[sortId(it)] })
    }

    private fun validateCompulsoryConsents(): Boolean {
        for (purpose in ucmPurposes()) {
            for (bucket in purpose.consentBucket.orEmpty()) {
                for (ct in bucket.ctCpMapBucket.orEmpty()) {
                    if (ct.compulsoryConsent == true && ct.consentStatus != true) return false
                }
            }
        }
        return true
    }

    fun getDataPrincipalId(): Int {
        dashboardData?.ucmPreferenceForm?.firstOrNull()?.dataPrincipalId?.let { return it }
        for (purpose in ucmPurposes()) {
            for (bucket in purpose.consentBucket.orEmpty()) {
                for (ct in bucket.ctCpMapBucket.orEmpty()) {
                    if (ct.dataPrincipalId != null && ct.dataPrincipalId != 0) return ct.dataPrincipalId
                }
            }
        }
        return 0
    }

    // ---------------------------------------------------------------------
    // Save preferences (with optional DigiLocker minor re-verification)
    // ---------------------------------------------------------------------

    fun onSavePreferencesClicked() {
        if (isMinor) {
            validateDigiLockerThenSave()
        } else {
            savePreferences()
        }
    }

    private fun validateDigiLockerThenSave() {
        viewModelScope.launch {
            _isBusy.value = true
            val digiLockerResponse = api.getDigiLockerResponse(pfToken)
            _isBusy.value = false
            val authUrl = digiLockerResponse?.authorizationUrl
            if (authUrl.isNullOrEmpty()) {
                _uiState.value = PreferenceCenterUiState.MinorVerificationFailed(
                    "Verification Failed. Unable to complete age verification. Please try again later."
                )
                return@launch
            }
            _uiState.value = PreferenceCenterUiState.DigiLockerVerification(authUrl)
        }
    }

    fun onDigiLockerSuccess(code: String, state: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val callback = api.getCallbackApiResponse(code, state)
            _isBusy.value = false
            digiLockerCallbackData = callback?.result
            digiLockerIsMinor = callback?.result?.data?.ageInfo?.isMinor
            if (callback == null) {
                _uiState.value = PreferenceCenterUiState.MinorVerificationFailed(
                    "Verification failed or was cancelled. You cannot update the consents."
                )
                return@launch
            }
            if (digiLockerIsMinor == true) {
                _uiState.value = PreferenceCenterUiState.MinorVerificationFailed(
                    "You are a minor and hence you cannot update the consents."
                )
                return@launch
            }
            _uiState.value = PreferenceCenterUiState.Dashboard
            savePreferences()
        }
    }

    fun onDigiLockerCancelled() {
        _uiState.value = PreferenceCenterUiState.MinorVerificationFailed(
            "Verification failed or was cancelled. You cannot update the consents."
        )
    }

    fun backToDashboardFromMinorFailure() {
        _uiState.value = PreferenceCenterUiState.Dashboard
    }

    private fun savePreferences() {
        val data = dashboardData ?: return
        val ai = data.additionalInfo ?: return
        val ucmForm = data.ucmPreferenceForm?.firstOrNull() ?: return
        if (!validateCompulsoryConsents()) {
            _snackbarMessage.value = "Please choose all compulsory consents before saving."
            return
        }

        val entries = mutableListOf<Map<String, Any?>>()
        val visibleCtIds = mutableSetOf<Int>()

        for (category in allCategories()) {
            val categoryVisible = category.ucmPreferenceVisible != false
            for (purpose in category.purposeList.orEmpty()) {
                val purposeVisible = categoryVisible && purpose.ucmPreferenceVisible != false
                for (bucket in purpose.consentBucket.orEmpty()) {
                    val bucketVisible = purposeVisible && bucket.ucmPreferenceVisible != false
                    for (ct in bucket.ctCpMapBucket.orEmpty()) {
                        val id = ct.id ?: continue
                        entries.add(
                            mapOf(
                                "id" to ct.id,
                                "collection_template_id" to ct.collectionTemplateId,
                                "data_principal_id" to ct.dataPrincipalId,
                                "processing_purpose_id" to ct.processingPurposeId,
                                "processing_purpose_name" to ct.processingPurposeName,
                                "consent_purpose_id" to ct.consentPurposeId,
                                "consent_purpose_name" to ct.consentPurposeName,
                                "pii_label_id" to ct.piiLabelId,
                                "pii_label" to ct.piiLabel,
                                "frequency" to ct.frequency,
                                "consent_lifetime" to ct.consentLifetime,
                                "consent_expiration" to ct.consentExpiration,
                                "default_opt_out_allowed" to ct.defaultOptOutAllowed,
                                "compulsory_consent" to ct.compulsoryConsent,
                                "consent_status" to ct.consentStatus,
                                "backend_consent_status" to ct.backendConsentStatus,
                                "manual_revoke_bool" to ct.manualRevokeBool,
                                "manual_grant_bool" to ct.manualGrantBool,
                                "vendor_id" to ct.vendorId,
                                "vendor_name" to ct.vendorName,
                                "process_id" to ct.processId,
                                "process_name" to ct.processName,
                                "principal_context" to ct.ucmPrincipleContext,
                            )
                        )
                        if (bucketVisible && ct.ucmPreferenceVisible != false) visibleCtIds.add(id)
                    }
                }
            }
        }

        val payload = mutableMapOf<String, Any?>(
            "customer_id" to ai.customerId,
            "verification_key" to ai.verificationKey,
            "subject_identity_values" to pendingSubjectIdentityValues,
            "consent_source" to "apk_preference_center",
            // The consent-form's /records call sends its language as "language_consented_to";
            // /pc-records had no equivalent field at all, so the backend had nothing to check the
            // evidence token's own language claim against once the dashboard had been reloaded in
            // a language other than whatever it associates with the start of the session.
            "language_consented_to" to _selectedLanguage.value,
            "consent_status" to entries,
        )
        if (isMinor) {
            payload["digilocker_evidence"] = digiLockerCallbackData?.data?.userDetails ?: emptyMap<String, Any?>()
        }

        viewModelScope.launch {
            savingOverlayVisible.value = true
            val outcome = try {
                api.saveDashboardPreferences(payload)
            } finally {
                savingOverlayVisible.value = false
            }
            if (outcome.success) {
                val resultData = entries.filter {
                    visibleCtIds.contains(it["id"]) && it["consent_status"] == true
                }.map {
                    mapOf(
                        "processing_purpose_id" to it["processing_purpose_id"],
                        "processing_purpose_name" to it["processing_purpose_name"],
                        "consent_purpose_id" to it["consent_purpose_id"],
                        "consent_purpose_name" to it["consent_purpose_name"],
                        "consent_status" to it["consent_status"],
                        // Two entries can share a purpose and differ only by PII label; without
                        // these the host cannot tell them apart.
                        "pii_label_id" to it["pii_label_id"],
                        "pii_label" to it["pii_label"],
                    )
                }
                lastSavedResult = resultData
                savedAtLeastOnce = true
                _saveSuccessEvent.value = PreferenceSaveSuccess(
                    message = SAVE_SUCCESS_MESSAGE,
                    data = resultData,
                )
                // The in-memory dashboardData already reflects exactly what was just sent (the
                // user's toggles mutated it before this payload was built), so there's no need to
                // hit the display endpoint again — the dashboard stays mounted, unchanged, behind
                // the success dialog. Dismissing the dialog (tap or auto-timeout) is what resets
                // the visible tab back to Privacy Notice — see dismissSaveSuccessDialog().
                saveSuccessMessage.value = SAVE_SUCCESS_MESSAGE
                saveSuccessAutoDismissJob?.cancel()
                saveSuccessAutoDismissJob = launch {
                    delay(3500)
                    dismissSaveSuccessDialog()
                }
            } else {
                // The backend's own reason when it gave one, so the host app learns what actually
                // failed rather than a fixed string; the generic copy stays as the fallback.
                val reason = outcome.message?.takeIf { it.isNotBlank() }
                val statusSuffix = outcome.statusCode?.let { " [$it]" }.orEmpty()
                _saveErrorEvent.value = reason?.let { "$it$statusSuffix" } ?: SAVE_FAILURE_MESSAGE
                _snackbarMessage.value = reason ?: SAVE_FAILURE_MESSAGE
            }
        }
    }

    var lastSavedResult: List<Map<String, Any?>> = emptyList()
        private set

    /** True once any save in this session succeeded — decides the activity's result code. */
    var savedAtLeastOnce: Boolean = false
        private set

    // ---------------------------------------------------------------------
    // Consent Flow / Audit Logs tabs (loaded lazily by their composables)
    // ---------------------------------------------------------------------

    suspend fun getConsentFlow(): List<ConsentRecord> = api.getConsentFlow()

    suspend fun fetchConsentAuditLogs(dataPrincipalId: Int, page: Int): ConsentAuditPageResult? =
        api.fetchConsentAuditLogs(dataPrincipalId, page)

    private companion object {
        /** Verbatim from the Flutter SDK so hosts see identical strings on both platforms. */
        const val SAVE_SUCCESS_MESSAGE = "Preferences saved successfully!"
        const val SAVE_FAILURE_MESSAGE = "Failed to save preferences. Please try again."
    }
}

/** A completed save. [data] is the list of preferences the user actually granted. */
data class PreferenceSaveSuccess(
    val message: String,
    val data: List<Map<String, Any?>>
)
