package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import android.R
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.core.utils.HtmlText
import com.tekhsters.gotrustsdkandroid.core.utils.TextStyleHelper
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.core.utils.getFontWeight
import com.tekhsters.gotrustsdkandroid.core.utils.looksLikeHtml
import com.tekhsters.gotrustsdkandroid.core.utils.parseBorderRadius
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.LanguageSelector
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.UcmConsentBucket
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.UcmPreferenceCategory

private fun px(value: String?, fallback: Double = 0.0): Double {
    if (value.isNullOrEmpty()) return fallback
    return value.replace("px", "").trim().toDoubleOrNull() ?: fallback
}

private fun textAlignFor(key: String?): TextAlign = when (key?.lowercase()) {
    "center" -> TextAlign.Center
    "right" -> TextAlign.Right
    else -> TextAlign.Left
}

private fun boxAlignFor(key: String?): Alignment = when (key?.lowercase()) {
    "center" -> Alignment.Center
    "right" -> Alignment.CenterEnd
    else -> Alignment.CenterStart
}

/**
 * A consent checkbox matching the CMS's `checkbox_border_radius` config, mirroring the Flutter
 * SDK's CheckboxThemeData (which always uses RoundedRectangleBorder, never a circle, and falls
 * back to a small fixed radius when unset). Material3's Checkbox only offers a fixed
 * rounded-square shape, so this is a small custom control instead.
 */
@Composable
private fun ConsentCheckControl(
    checked: Boolean,
    activeColor: Color,
    borderRadius: String?,
    enabled: Boolean = true,
    size: androidx.compose.ui.unit.Dp = 24.dp,
    onCheckedChange: ((Boolean) -> Unit)?,
) {
    val shape: Shape = RoundedCornerShape(parseBorderRadius(borderRadius, 40f).dp)
    Box(
        modifier = Modifier
            .size(size)
            .clip(shape)
            .background(if (checked) activeColor.copy(alpha = if (enabled) 1f else 0.5f) else Color.White)
            .border(1.5.dp, if (checked) Color.Transparent else Color(0xFFBDBDBD), shape)
            .then(
                if (onCheckedChange != null) {
                    Modifier.clickable(enabled = enabled) { onCheckedChange(!checked) }
                } else Modifier
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (checked) {
            Icon(
                Icons.Default.Check,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(size * 0.65f),
            )
        }
    }
}

/**
 * Renders either a [Switch] or a [ConsentCheckControl] depending on the CMS's
 * `consent_input_type` ("toggle" vs "checkbox"), so every consent control (check-all,
 * category-level, bucket-level) stays consistent with that setting.
 */
@Composable
private fun ConsentInputControl(
    checked: Boolean,
    useToggle: Boolean,
    activeColor: Color,
    borderRadius: String?,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit,
) {
    if (useToggle) {
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = androidx.compose.material3.SwitchDefaults.colors(checkedTrackColor = activeColor),
            // Switch reserves an 8dp top inset for its 48dp minimum touch target around a
            // 32dp track, which ConsentCheckControl doesn't have — without this the toggle
            // sits visibly lower than the heading/text it labels. offset() only shifts the
            // draw position, so surrounding layout is unaffected.
            modifier = Modifier.offset(y = (-8).dp),
        )
    } else {
        ConsentCheckControl(
            checked = checked,
            activeColor = activeColor,
            borderRadius = borderRadius,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
        )
    }
}

@Composable
fun DashboardScreen(viewModel: PreferenceCenterViewModel, onClose: () -> Unit) {
    // Reading the revision inside composition subscribes recomposition to in-place mutations
    // of nested UcmCtCpMap.consentStatus, which aren't otherwise observable via Compose state.
    val revision = viewModel.dashboardRevision.value
    val data = viewModel.dashboardData
    val isBusy by viewModel.isBusy.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()

    val cfg = data?.preferenceCenterConfiguration
    val consentConfig = cfg?.consentPurposeConfiguration

    if (cfg == null) {
        Scaffold {
            padding ->
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Unable to load preference center")
                    Spacer(Modifier.height(8.dp))
                    Row {
                        Button(onClick = onClose) { Text("Go Back") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { viewModel.reloadDashboard() }) { Text("Retry") }
                    }
                }
            }
        }
        return
    }

    data class TabDef(val title: String, val content: @Composable () -> Unit)

    val tabs = buildList {
        add(TabDef(cfg.privacyNoticeHeading ?: "Privacy Notice") { PrivacyNoticeTab(data.privacyNote.orEmpty()) })
        if (cfg.showConsent == true) {
            add(TabDef(cfg.preferenceCenterHeading ?: "Consent Preferences") {
                ConsentPreferencesTab(viewModel, consentConfig)
            })
        }
        if (cfg.showDSR == true) {
            add(TabDef(cfg.dsrCenterHeading ?: "DSR") { DsrTab(data.dsr?.dsrContent) })
        }
        if (cfg.showConsentFlow == true) {
            add(TabDef(cfg.consentFlowHeading ?: "Consent Flow") { ConsentFlowTab(viewModel) })
        }
        add(TabDef(cfg.auditLogsHeading ?: "Audit Logs") {
            AuditLogsTab(
                viewModel = viewModel,
                dataPrincipalId = viewModel.getDataPrincipalId(),
                accentColor = Utils.hexToColor(consentConfig?.submitButton?.color ?: "#000000"),
            )
        })
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    if (selectedTab >= tabs.size) selectedTab = 0

    // Dismissing the post-save success dialog bumps this signal to jump back to Privacy Notice,
    // without reloading data or leaving the dashboard.
    val resetTabSignal = viewModel.resetToFirstTabSignal.value
    androidx.compose.runtime.LaunchedEffect(resetTabSignal) {
        if (resetTabSignal > 0) selectedTab = 0
    }

    val accentColor = consentConfig?.form?.colorScheme ?: "#2b6bec"

    Scaffold(
        containerColor = Color.White,
        topBar = {
            DynamicHeaderAppBar(
                closeIconPosition = consentConfig?.form?.headerLayout?.closeIconPosition,
                logoPosition = consentConfig?.form?.headerLayout?.logoPosition,
                dropdownPosition = consentConfig?.form?.headerLayout?.dropdownPosition,
                backgroundColor = "#ffffff",
                onClose = onClose,
                logo = if (!cfg.logoUrl.isNullOrEmpty()) {
                    {
                        AsyncImage(
                            model = cfg.logoUrl,
                            contentDescription = null,
                            modifier = Modifier.height(px(consentConfig?.form?.logo?.height, 40.0).dp),
                        )
                    }
                } else null,
                dropdown = if (consentConfig?.form?.showLanguage == true) {
                    {
                        LanguageSelector(
                            languages = languages.ifEmpty {
                                listOf(com.tekhsters.gotrustsdkandroid.features.consentform.models.Language("en", "English"))
                            },
                            selectedCode = lang,
                            onChanged = { viewModel.onLanguageChanged(it) },
                            colorHex = consentConfig?.form?.languageDropDown?.backgroundColor ?: "#000000",
                            textColor = consentConfig?.form?.languageDropDown?.textColor ?: "#000000",
                        )
                    }
                } else null,
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (!data.basicInfo?.description.isNullOrEmpty()) {
                Column(Modifier.padding(16.dp)) {
                    Text(data.basicInfo?.title ?: "", style = TextStyleHelper.title)
                    Spacer(Modifier.height(8.dp))
                    Text(data.basicInfo?.description ?: "", style = TextStyleHelper.body)
                }
            }

            Row(
                modifier = Modifier
                    .padding(8.dp)
                    .background(Color(0xFFF5F5F5), RoundedCornerShape(12.dp))
                    .padding(8.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                tabs.forEachIndexed { index, tab ->
                    val selected = selectedTab == index
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) Utils.hexToColor(accentColor) else Color.Transparent)
                            .clickable { selectedTab = index }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                    ) {
                        Text(
                            tab.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 13.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = if (selected) Color.White else Color(0xFF757575),
                        )
                    }
                }
            }

            Box(Modifier.weight(1f).padding(8.dp)) {
                tabs[selectedTab].content()
            }
        }
    }
}

@Composable
private fun PrivacyNoticeTab(notes: List<com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.PrivacyNote>) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
        notes.forEach { note ->
            Text(note.title ?: "", style = TextStyleHelper.title)
            Spacer(Modifier.height(4.dp))
            if (looksLikeHtml(note.content)) {
                HtmlText(html = note.content ?: "")
            } else {
                Text(note.content ?: "", style = TextStyleHelper.body)
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun DsrTab(content: String?) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        HtmlText(html = content ?: "")
    }
}


@Composable
private fun ConsentPreferencesTab(
    viewModel: PreferenceCenterViewModel,
    consentConfig: com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentPurposeConfiguration?,
) {
    val section = consentConfig?.consentCollectionSection
    val activeColor = Utils.hexToColor(consentConfig?.form?.colorScheme ?: "#2b6bec")
    val isMinor = viewModel.isMinor
    val isBusy by viewModel.isBusy.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        val consentSectionAlign = consentConfig?.preferenceSectionAlignments?.consentSection

        if (!section?.heading?.text.isNullOrEmpty()) {
            val headingText = section?.heading?.text ?: ""
            val headingColor = section?.heading?.color ?: "#000000"
            val headingSize = px(section?.heading?.size, 20.0)
            val headingWeight = getFontWeight(section?.heading?.headingFontWeight) .let {
                if (it == FontWeight.Normal) FontWeight.Bold else it
            }
            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = boxAlignFor(consentSectionAlign)) {
                if (looksLikeHtml(headingText)) {
                    HtmlText(
                        html = headingText,
                        colorHex = headingColor,
                        fontSize = headingSize,
                        fontWeight = headingWeight,
                        align = consentSectionAlign,
                    )
                } else {
                    Text(
                        text = headingText,
                        color = Utils.hexToColor(headingColor),
                        fontSize = headingSize.sp,
                        fontWeight = headingWeight,
                        textAlign = textAlignFor(consentSectionAlign),
                    )
                }
            }
        }

        if (section?.showCheckAllCheckbox == true) {
            val inputOnRight = (section.consentInputPosition ?: "left").lowercase() == "right"
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                if (!inputOnRight) {
                    ConsentInputControl(
                        checked = viewModel.multiSelectConsentValue.value,
                        useToggle = (section.consentInputType ?: "checkbox").lowercase() == "toggle",
                        activeColor = activeColor,
                        borderRadius = section.checkboxBorderRadius,
                        onCheckedChange = { viewModel.toggleAllConsents(it) },
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(section.allCheckboxText ?: "", style = TextStyleHelper.smallHeading, modifier = Modifier.weight(1f))
                if (inputOnRight) {
                    Spacer(Modifier.width(8.dp))
                    ConsentInputControl(
                        checked = viewModel.multiSelectConsentValue.value,
                        useToggle = (section.consentInputType ?: "checkbox").lowercase() == "toggle",
                        activeColor = activeColor,
                        borderRadius = section.checkboxBorderRadius,
                        onCheckedChange = { viewModel.toggleAllConsents(it) },
                    )
                }
            }
        }

        val enableCategoryLevel = section?.enableCategoryLevelConsent == true

        @Composable
        fun CategoryGroup(categories: List<UcmPreferenceCategory>, heading: com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.DashboardHeading?) {
            val visibleCategories = viewModel.getOrderedCategories(categories)
                .filter { it.ucmPreferenceVisible != false }
            if (visibleCategories.isEmpty()) return

            if (isMinor && !heading?.text.isNullOrEmpty()) {
                val headingText = heading?.text ?: ""
                if (looksLikeHtml(headingText)) {
                    HtmlText(
                        html = headingText,
                        colorHex = heading?.color ?: "#000000",
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                } else {
                    Text(
                        text = headingText,
                        style = TextStyleHelper.title,
                        color = Utils.hexToColor(heading?.color ?: "#000000"),
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
            }

            if (enableCategoryLevel) {
                visibleCategories.forEach { category ->
                    CategoryCard(viewModel, category, consentConfig, activeColor)
                }
            } else {
                visibleCategories.forEach { category ->
                    viewModel.getOrderedPurposes(category)
                        .filter { it.ucmPreferenceVisible != false }
                        .forEach { purpose ->
                            purpose.consentBucket.orEmpty()
                                .filter { it.ucmPreferenceVisible != false }
                                .forEach { bucket ->
                                    ConsentBucketRow(viewModel, bucket, consentConfig, activeColor)
                                }
                        }
                }
            }
        }

        val dataPrincipalCategories = viewModel.dataPrincipalCategories()
        val consentActorCategories = viewModel.consentActorCategories()
        if (dataPrincipalCategories.isEmpty() && consentActorCategories.isEmpty()) {
            // No actor-split category data (e.g. purpose-only forms) — fall back to the
            // combined list, which also covers the purpose-list-only case.
            CategoryGroup(viewModel.allCategories(), null)
        }
        CategoryGroup(dataPrincipalCategories, section?.dataPrincipleHeading)
        CategoryGroup(consentActorCategories, section?.consentActorHeading)

        if (!consentConfig?.formFooter?.description?.text.isNullOrEmpty()) {
            val footerText = consentConfig?.formFooter?.description?.text ?: ""
            if (looksLikeHtml(footerText)) {
                HtmlText(html = footerText, modifier = Modifier.padding(vertical = 12.dp))
            } else {
                Text(text = footerText, style = TextStyleHelper.body, modifier = Modifier.padding(vertical = 12.dp))
            }
        }

        Spacer(Modifier.height(8.dp))
        val submitAlign = consentConfig?.preferenceSectionAlignments?.submitAction ?: "center"
        val submitRadius = 24.0
        Box(Modifier.fillMaxWidth().padding(bottom = 16.dp), contentAlignment = boxAlignFor(submitAlign)) {
            Button(
                onClick = { viewModel.onSavePreferencesClicked() },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                shape = RoundedCornerShape(submitRadius.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 32.dp, vertical = 14.dp),
            ) {
                // Saving now shows a subtle full-screen indicator (see PreferenceCenterActivity)
                // instead of a spinner inside the button, matching the Flutter SDK's Loader overlay.
                Text(
                    text = consentConfig?.submitButton?.text ?: "Save Preferences",
                    color = Color.White,
                    fontSize = px(consentConfig?.submitButton?.size, 14.0).sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun CategoryCard(
    viewModel: PreferenceCenterViewModel,
    category: UcmPreferenceCategory,
    consentConfig: com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentPurposeConfiguration?,
    activeColor: Color,
) {
    // Reading the revision here (not just in the DashboardScreen ancestor) is required: this
    // composable's params (viewModel/category/consentConfig references) never change identity
    // when a checkbox toggles a nested UcmCtCpMap.consentStatus, so Compose would otherwise skip
    // recomposing it entirely and the checkbox would appear stuck.
    viewModel.dashboardRevision.value
    var expanded by remember { androidx.compose.runtime.mutableStateOf(true) }
    val purposes = viewModel.getOrderedPurposes(category).filter { it.ucmPreferenceVisible != false }
    val buckets = purposes.flatMap { it.consentBucket.orEmpty() }.filter { it.ucmPreferenceVisible != false }
    if (buckets.isEmpty()) return

    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(16.dp))
            .padding(12.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
        ) {
            val section = consentConfig?.consentCollectionSection
            val showControl = section?.showConsentInput != false && section?.showCategoryConsentInput != false && section?.showCheckAllCheckbox == true
            val useToggle = (section?.consentInputType ?: "checkbox").lowercase() == "toggle"
            val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"
            if (showControl && !inputOnRight) {
                ConsentInputControl(
                    checked = viewModel.getCategoryConsentValue(category),
                    useToggle = useToggle,
                    activeColor = activeColor,
                    borderRadius = section?.checkboxBorderRadius,
                    enabled = !viewModel.isCategoryConsentControlDisabled(category),
                    onCheckedChange = { viewModel.applyCategoryConsent(category, it) },
                )
                Spacer(Modifier.width(8.dp))
            }
            Text(
                category.processingPurposeCategoryName ?: "",
                style = TextStyleHelper.title,
                modifier = Modifier.weight(1f),
            )
            if (showControl && inputOnRight) {
                Spacer(Modifier.width(8.dp))
                ConsentInputControl(
                    checked = viewModel.getCategoryConsentValue(category),
                    useToggle = useToggle,
                    activeColor = activeColor,
                    borderRadius = section?.checkboxBorderRadius,
                    enabled = !viewModel.isCategoryConsentControlDisabled(category),
                    onCheckedChange = { viewModel.applyCategoryConsent(category, it) },
                )
            }
            Text(if (expanded) "▴" else "▾", modifier = Modifier.padding(start = 8.dp))
        }

        if (expanded) {
            buckets.forEach { bucket ->
                ConsentBucketRow(viewModel, bucket, consentConfig, activeColor)
            }
        }
    }
}

@Composable
private fun ConsentBucketRow(
    viewModel: PreferenceCenterViewModel,
    bucket: UcmConsentBucket,
    consentConfig: com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentPurposeConfiguration?,
    activeColor: Color,
) {
    // See the comment in CategoryCard: this subscribes the composable to in-place mutations of
    // bucket.ctCpMapBucket[].consentStatus, which don't otherwise trigger recomposition here.
    viewModel.dashboardRevision.value
    val section = consentConfig?.consentCollectionSection
    val hasCtcp = bucket.ctCpMapBucket.orEmpty().isNotEmpty()
    // compulsory_consent can be true on any entry of ct_cp_map_bucket (one per
    // pii label/process/vendor), not just the first
    val isCompulsory = bucket.ctCpMapBucket.orEmpty().any { it.compulsoryConsent == true }
    val value = hasCtcp && bucket.ctCpMapBucket!!.first().consentStatus == true
    val showConsentInput = section?.showConsentInput != false
    val showIndividualInput = showConsentInput && section?.showIndividualChecks != false
    val useToggle = (section?.consentInputType ?: "checkbox").lowercase() == "toggle"
    val showDescription = section?.showDescription ?: true
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"

    @Composable
    fun BucketInputControl() {
        ConsentInputControl(
            checked = value,
            useToggle = useToggle,
            activeColor = activeColor,
            borderRadius = section?.checkboxBorderRadius,
            onCheckedChange = { viewModel.toggleBucketConsent(bucket, it) },
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (showIndividualInput && !inputOnRight) {
            BucketInputControl()
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                text = if (isCompulsory) {
                    buildAnnotatedString {
                        append(bucket.consentPurposeName ?: "")
                        withStyle(SpanStyle(color = Color.Red)) { append(" *") }
                    }
                } else {
                    buildAnnotatedString { append(bucket.consentPurposeName ?: "") }
                },
                style = TextStyleHelper.smallHeading,
            )
            if (showDescription && !bucket.consentPurposeDescription.isNullOrEmpty()) {
                if (looksLikeHtml(bucket.consentPurposeDescription)) {
                    HtmlText(html = bucket.consentPurposeDescription)
                } else {
                    Text(bucket.consentPurposeDescription, style = TextStyleHelper.body)
                }
            }
        }
        if (showIndividualInput && inputOnRight) {
            Spacer(Modifier.width(12.dp))
            BucketInputControl()
        }
    }
}
