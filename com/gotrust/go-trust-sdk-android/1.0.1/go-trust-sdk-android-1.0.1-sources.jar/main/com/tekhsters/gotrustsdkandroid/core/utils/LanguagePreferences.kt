package com.tekhsters.gotrustsdkandroid.core.utils

import android.content.Context
import android.content.SharedPreferences

/**
 * Persists the language the user picked from the in-form language selector, mirroring the Flutter
 * SDK's `SharedPreferences` key `language_code`.
 *
 * Flutter's read/write split is deliberately asymmetric and reproduced here as-is:
 *  - Every screen with a language dropdown **writes** the new code
 *    (`consent_form_page.dart:366`, `privacy_notice_screen.dart:88`, `login_page.dart:163`,
 *    `otp_page.dart:120`, `consent_preference_dashboard.dart:1216`).
 *  - Only the preference-center screens **read** it back, and only when the caller left
 *    `initialLanguage` at its `'en'` default — an explicitly requested language always wins
 *    (`login_page.dart:82`, `otp_page.dart:94`, `consent_preference_dashboard.dart:662`).
 *    The consent form does not read it; it starts from `initialLanguage` verbatim.
 */
object LanguagePreferences {

    private const val PREFS_NAME = "go_trust_sdk_prefs"
    private const val KEY_LANGUAGE_CODE = "language_code"
    private const val DEFAULT_LANGUAGE = "en"

    /** Holds application context only — never an Activity — so the singleton cannot leak a screen. */
    @Volatile
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            synchronized(this) {
                if (prefs == null) {
                    prefs = context.applicationContext
                        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                }
            }
        }
    }

    fun read(default: String = DEFAULT_LANGUAGE): String =
        prefs?.getString(KEY_LANGUAGE_CODE, null)?.takeIf { it.isNotBlank() } ?: default

    fun write(code: String) {
        if (code.isBlank()) return
        prefs?.edit()?.putString(KEY_LANGUAGE_CODE, code)?.apply()
    }

    /**
     * Resolves the language a preference-center screen should start in: the persisted choice when
     * the caller did not ask for a specific one, otherwise the caller's request.
     */
    fun resolveInitial(requested: String): String =
        if (requested == DEFAULT_LANGUAGE) read(DEFAULT_LANGUAGE) else requested
}
