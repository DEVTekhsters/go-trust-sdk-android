package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class PrivacyNoticeResponse(
    @SerializedName("success") val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("result") val result: Result?,
    @SerializedName("time") val time: Long?
) {
    data class Result(
        @SerializedName("data") val data: List<PrivacyData>?
    )

    data class PrivacyData(
        @SerializedName("id") val id: Int?,
        @SerializedName("customer_id") val customerId: Int?,
        @SerializedName("entity_id") val entityId: Int?,
        @SerializedName("name") val name: String?,
        @SerializedName("version") val version: Double?,
        @SerializedName("status") val status: Boolean?,
        @SerializedName("created_at") val createdAt: String?,
        @SerializedName("updated_at") val updatedAt: String?,
        @SerializedName("ai_generated") val aiGenerated: Boolean?,
        @SerializedName("content") val content: List<Content>?
    )

    data class Content(
        @SerializedName("id") val id: String?,
        @SerializedName("title") val title: String?,
        @SerializedName("content") val content: String?
    )
}
