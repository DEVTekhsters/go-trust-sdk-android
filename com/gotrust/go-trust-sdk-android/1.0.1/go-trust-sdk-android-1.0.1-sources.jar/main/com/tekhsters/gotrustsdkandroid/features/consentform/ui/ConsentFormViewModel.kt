package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tekhsters.gotrustsdkandroid.FallbackConfig
import com.tekhsters.gotrustsdkandroid.core.utils.LanguagePreferences
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.*
import com.tekhsters.gotrustsdkandroid.features.consentform.services.ApiService
import com.tekhsters.gotrustsdkandroid.features.consentform.services.RecaptchaAttemptResult
import com.tekhsters.gotrustsdkandroid.features.consentform.services.RecaptchaService
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ConsentFormViewModel : ViewModel() {

    private val api = ApiService.instance

    private val _uiState = MutableStateFlow<ConsentFormUiState>(ConsentFormUiState.Loading)
    val uiState: StateFlow<ConsentFormUiState> = _uiState.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    /**
     * Set once the save call succeeds. The form stays mounted underneath — the activity renders
     * the success dialog on top of it and only closes when that dialog is dismissed.
     */
    private val _submitSuccess = MutableStateFlow<ConsentSubmitSuccess?>(null)
    val submitSuccess: StateFlow<ConsentSubmitSuccess?> = _submitSuccess.asStateFlow()


    private val _submitError = MutableStateFlow<ConsentSubmitError?>(null)
    val submitError: StateFlow<ConsentSubmitError?> = _submitError.asStateFlow()

    fun consumeSubmitError() {
        _submitError.value = null
    }

    fun consumeSnackbar() {
        _snackbarMessage.value = null
    }

    private val _languages = MutableStateFlow<List<Language>>(emptyList())
    val languages: StateFlow<List<Language>> = _languages.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("en")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    val piiValues = mutableStateMapOf<String, String>()

    private val _invalidPiiKeys = MutableStateFlow<Set<String>>(emptySet())
    val invalidPiiKeys: StateFlow<Set<String>> = _invalidPiiKeys.asStateFlow()
    
    private val _consentForm = MutableStateFlow<ConsentFormResponse.ConsentFormData?>(null)
    val consentForm: StateFlow<ConsentFormResponse.ConsentFormData?> = _consentForm.asStateFlow()

    private val _checkAllStatus = MutableStateFlow(false)
    val checkAllStatus: StateFlow<Boolean> = _checkAllStatus.asStateFlow()

    private val _hasPartialSelection = MutableStateFlow(false)
    val hasPartialSelection: StateFlow<Boolean> = _hasPartialSelection.asStateFlow()


    private val _consentRevision = MutableStateFlow(0)
    val consentRevision: StateFlow<Int> = _consentRevision.asStateFlow()

    private val _digiLockerResult = MutableStateFlow<CallBackResponse?>(null)

    private val _privacyData = MutableStateFlow<List<PrivacyNoticeResponse.PrivacyData>>(emptyList())
    val privacyData: StateFlow<List<PrivacyNoticeResponse.PrivacyData>> = _privacyData.asStateFlow()

    private val _isLoadingPrivacyNotice = MutableStateFlow(false)
    val isLoadingPrivacyNotice: StateFlow<Boolean> = _isLoadingPrivacyNotice.asStateFlow()

    /** Language of the privacy notice currently in [_privacyData]; `null` when nothing is loaded. */
    private var loadedPrivacyLanguage: String? = null

    private var sourceId: String = ""
    private var token: String? = null
    private var subjectIdentityValues: Map<String, Any> = emptyMap()
    private var additionalParams: Map<String, Any> = emptyMap()
    private var reviewedPrivacyNotice = false
    private var enableCaptcha: Boolean = true

    /** Decryptor response from the most recent [loadAll], kept only for its identity/PII payload
     *  in token flow — [resolvedSourceId] and the minor check already read what they need inline. */
    private var decryptedData: DecrypterApiResponse? = null

    /** A non-empty [token] replaces every widget-supplied identifier for identity resolution. */
    private val isTokenFlow: Boolean get() = !token.isNullOrEmpty()

    /** Effective subject identity values: the decryptor's own answer in token flow, otherwise
     *  whatever the caller passed in — matches the Flutter SDK's `_effectiveSubjectIdentityValues`.
     *  A failed decryptor (fallback mode) leaves no decrypted answer to read, so it falls back to
     *  the caller-supplied values same as the non-token flow — an empty list here is what sends
     *  the fallback display call an empty `subject_identity_values`, which the backend 422s on. */
    private val effectiveSubjectIdentityValues: Map<String, Any>
        get() = if (isTokenFlow && decryptedData != null) {
            (decryptedData?.result?.data?.subjectIdentityValues ?: emptyList())
                .associate { safeId(it.piiLabelId).toString() to (it.piiValue ?: "") }
        } else subjectIdentityValues

    private val effectiveAdditionalParams: Map<String, Any>
        get() = if (isTokenFlow && decryptedData != null) {
            (decryptedData?.result?.data?.piiList ?: emptyList())
                .associate { safeId(it.piiLabelId).toString() to (it.piiValue ?: "") }
        } else additionalParams

    fun init(
        baseUrl: String,
        sourceId: String,
        subjectIdentityValues: Map<String, Any>,
        additionalParams: Map<String, Any>,
        initialLanguage: String = "en",
        enableCaptcha: Boolean = true,
        fallback: FallbackConfig? = null,
        token: String? = null,
    ) {
        this.sourceId = sourceId
        this.token = token
        this.subjectIdentityValues = subjectIdentityValues
        this.additionalParams = additionalParams
        this._selectedLanguage.value = initialLanguage
        this.enableCaptcha = enableCaptcha
        api.setBaseUrl(baseUrl)
        api.setFallback(fallback)
        loadAll()
    }

    /**
     * Built for the very first `getConsentFormData` call, before any form metadata (and therefore
     * any PII label name) is known, so the phone-number country code has to be decided from the
     * value's own shape. See [PhoneIdentity.forUnknownLabel].
     */
    private fun buildSubjectIdentityValuesPayload(): List<Map<String, Any?>> {
        return effectiveSubjectIdentityValues.entries.map {
            mapOf(
                "pii_label_id" to it.key.toInt(),
                "pii_value" to PhoneIdentity.forUnknownLabel(it.value.toString())
            )
        }
    }

    private fun piiLabelName(id: Any?): String? {
        val form = _consentForm.value ?: return null
        val target = id?.toString() ?: return null
        val allPii = (form.piiList?.dataPrincipalPiiList ?: emptyList()) +
                (form.piiList?.consentActorPiiList ?: emptyList())
        return allPii.firstOrNull { safeId(it.id)?.toString() == target }?.name
            ?: form.additionalInfo?.subjectIdentityTypes
                ?.firstOrNull { safeId(it.id)?.toString() == target }?.name
    }

    // pii_label_name is translated per language, so it can't reliably signal "this is a phone
    // field" (see PhoneIdentity.isPhoneLabel) once the form isn't in English. regex_pattern is
    // validation metadata, not display content, so it stays the same in every language.
    private fun piiRegexPatterns(id: Any?): List<String>? {
        val form = _consentForm.value ?: return null
        val target = id?.toString() ?: return null
        val allPii = (form.piiList?.dataPrincipalPiiList ?: emptyList()) +
                (form.piiList?.consentActorPiiList ?: emptyList())
        return allPii.firstOrNull { safeId(it.id)?.toString() == target }?.regEx
    }

    // Set by onLanguageChanged when the language dropdown is used from the optional in-form privacy
    // notice link (isPreConsentGate = false), so fetchFormData's reload - needed to refresh the
    // evidence token for the new language - restores that same screen instead of falling through to
    // its own from-scratch destination (Success, or the mandatory gate), which would silently bounce
    // the user back to the consent form.
    private var restoreOptionalPrivacyNotice = false

    private var loadAllJob: Job? = null
    // Whatever type the decryptor hands back (numeric or an opaque encrypted string) is kept as-is
    // and forwarded unchanged into later requests — coercing it to a fixed Int/String has broken
    // this before when the value turned out not to be numeric.
    private var resolvedSourceId: Any? = null

    fun loadAll() {
        loadAllJob?.cancel()
        loadAllJob = viewModelScope.launch {
            _uiState.value = ConsentFormUiState.Loading
            try {
                // Once DigiLocker has verified the consent actor, re-hitting the decryptor endpoint
                // would overwrite the authorized (valid_consent_actor) token it just handed us with a
                // fresh, unauthorized one — causing a 403 "Consent Actor is not authorized" downstream.
                var resolvedId: Any?
                if (_digiLockerResult.value != null && resolvedSourceId != null) {
                    resolvedId = resolvedSourceId
                } else {
                    val decrypterResponse = api.getConsentFormId(sourceId, token)
                    decryptedData = decrypterResponse
                    resolvedId = safeId(decrypterResponse?.result?.data?.sourceId)

                    // A decryptor failure with no fallback configured is unrecoverable - there is
                    // no source id to fetch the form with. But if the failure just armed fallback
                    // mode, let the flow continue: fetchFormData below routes straight to the
                    // fallback display endpoint instead of the (now-unreachable) primary one, using
                    // the caller-supplied (undecrypted) source id in place of the decryptor's answer
                    // — same as the Flutter SDK's fallback, which never had a decrypted id either.
                    if (resolvedId == null) {
                        if (!api.isFallbackActive) {
                            _uiState.value = ConsentFormUiState.Error("Unable to load consent form")
                            return@launch
                        }
                        resolvedId = sourceId
                    }
                    resolvedSourceId = resolvedId

                    // DigiLocker flow for minors (parity logic)
                    val isMinor = decrypterResponse?.result?.data?.isMinor ?: false
                    if (isMinor && _digiLockerResult.value == null) {
                        val digiLockerRes = api.getDigiLockerResponse(sourceId)
                        if (digiLockerRes?.authorizationUrl != null) {
                            _uiState.value = ConsentFormUiState.DigiLockerVerification(digiLockerRes.authorizationUrl)
                            return@launch
                        }
                        // No authorization URL available: age verification cannot proceed.
                        // Must hard-stop here rather than showing the form to an unverified minor.
                        _uiState.value = ConsentFormUiState.MinorVerificationFailed(
                            "Verification Failed. Unable to complete age verification. Please try again later."
                        )
                        return@launch
                    }
                }

                fetchFormData(resolvedId)
            } catch (e: Exception) {
                _uiState.value = ConsentFormUiState.Error("Unable to load consent form")
            }
        }
    }

    private suspend fun fetchFormData(resolvedId: Any?) {
        val payload = mapOf(
            "source_id" to (resolvedId?.toString() ?: ""),
            "language_code" to _selectedLanguage.value,
            "subject_identity_values" to buildSubjectIdentityValuesPayload()
        )
        val formData = api.getConsentFormData(payload, sourceId)
        if (formData != null) {
            _consentForm.value = formData
            initPiiValues(formData)
            syncCheckAllStatus()
            
            val customerId = safeId(formData.additionalInfo?.customerId)?.toString()
            val formId = safeId(formData.additionalInfo?.formId)?.toString()
            if (customerId != null && formId != null) {
                _languages.value = api.fetchLanguages(customerId, formId) ?: emptyList()
            }

            if (formData.formConfiguration?.form?.showPrivacyNoticeBeforeConsent == true) {
                loadPrivacyNotice()
                _uiState.value = ConsentFormUiState.PrivacyNoticeGating(isPreConsentGate = true)
            } else if (restoreOptionalPrivacyNotice) {
                loadPrivacyNotice()
                _uiState.value = ConsentFormUiState.PrivacyNoticeGating(isPreConsentGate = false)
            } else {
                _uiState.value = ConsentFormUiState.Success
            }
            restoreOptionalPrivacyNotice = false
        } else {
            _uiState.value = ConsentFormUiState.Error("Unable to load consent form")
        }
    }

    private fun safeId(value: Any?): Any? = Utils.safeId(value)

    private fun initPiiValues(formData: ConsentFormResponse.ConsentFormData) {
        piiValues.clear()
        val allPii = (formData.piiList?.dataPrincipalPiiList ?: emptyList()) +
                (formData.piiList?.consentActorPiiList ?: emptyList())
        
        for (pii in allPii) {
            val id = safeId(pii.id) ?: continue
            val context = pii.principalContext ?: ""
            val key = "${context}_$id"
            
            var value = ""
            val isConsentActor = formData.piiList?.consentActorPiiList?.any { safeId(it.id) == id && it.principalContext == context } == true
            val isDataPrincipal = formData.piiList?.dataPrincipalPiiList?.any { safeId(it.id) == id && it.principalContext == context } == true

            if (isConsentActor && _digiLockerResult.value != null) {
                val digiUser = _digiLockerResult.value?.result?.data?.userDetails
                val name = pii.name?.lowercase() ?: ""
                value = when {
                    (name.contains("name") || name == "full name") -> digiUser?.name ?: ""
                    (name.contains("mobile") || name.contains("phone") || name.contains("contact")) -> digiUser?.mobile ?: ""
                    (name.contains("dob") || name.contains("birth")) -> digiUser?.dob ?: ""
                    name.contains("gender") -> digiUser?.gender ?: ""
                    else -> ""
                }
            } else if (isDataPrincipal) {
                val fromParams = effectiveAdditionalParams[id.toString()]?.toString()
                val fromSubject = effectiveSubjectIdentityValues[id.toString()]?.toString()
                value = fromParams ?: fromSubject ?: ""
            }
            // Phone fields render the "+91" as a fixed prefix beside the input, so the editable
            // value must stay the bare national number even when the host app (or DigiLocker)
            // already supplied one carrying the country code.
            piiValues[key] = if (PhoneIdentity.isPhoneLabel(pii.name, pii.regEx)) PhoneIdentity.strip(value) else value
        }
    }

    fun onLanguageChanged(code: String) {
        _selectedLanguage.value = code
        // Flutter persists the pick from both the form and the privacy-notice screen (which routes
        // its dropdown through here too) so the preference center can pick it up later.
        LanguagePreferences.write(code)
        restoreOptionalPrivacyNotice = (_uiState.value as? ConsentFormUiState.PrivacyNoticeGating)
            ?.isPreConsentGate == false
        loadAll()
    }

    fun onDigiLockerSuccess(code: String, state: String) {
        viewModelScope.launch {
            _uiState.value = ConsentFormUiState.Loading
            val response = api.getCallbackApiResponse(code, state)
            if (response != null) {
                _digiLockerResult.value = response
                if (response.result?.data?.ageInfo?.isMinor == true) {
                    _uiState.value = ConsentFormUiState.MinorVerificationFailed(
                        "You are a minor and hence you cannot access the consent form."
                    )
                } else {
                    loadAll()
                }
            } else {
                _uiState.value = ConsentFormUiState.MinorVerificationFailed(
                    "Verification failed or was cancelled. Please try again."
                )
            }
        }
    }

    fun toggleCheckAll(checked: Boolean) {
        _consentForm.value?.let { form ->
            val allCats = (form.categoryList?.dataPrincipalCategoryList ?: emptyList()) +
                    (form.categoryList?.consentActorCategoryList ?: emptyList())
            
            allCats.forEach { cat ->
                if (cat.visible != false) {
                    cat.purposeList?.forEach { purpose ->
                        if (purpose.visible != false) {
                            purpose.buckets?.forEach { bucket ->
                                if (bucket.visible != false) {
                                    bucket.ctcpList?.forEach { ct ->
                                        if (ct.visible != false) {
                                            ct.consentStatus = checked
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        syncCheckAllStatus()
    }

    fun syncCheckAllStatus() {
        val form = _consentForm.value ?: return
        val allCats = (form.categoryList?.dataPrincipalCategoryList ?: emptyList()) +
                (form.categoryList?.consentActorCategoryList ?: emptyList())

        var hasAny = false
        var allSelected = true
        var hasSelected = false
        var hasUnselected = false

        allCats.forEach { cat ->
            if (cat.visible != false) {
                cat.purposeList?.forEach { purpose ->
                    if (purpose.visible != false) {
                        purpose.buckets?.forEach { bucket ->
                            if (bucket.visible != false) {
                                bucket.ctcpList?.forEach { ct ->
                                    if (ct.visible != false) {
                                        hasAny = true
                                        if (ct.consentStatus == true) hasSelected = true else { allSelected = false; hasUnselected = true }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        _checkAllStatus.value = hasAny && allSelected
        _hasPartialSelection.value = hasAny && hasSelected && hasUnselected
        _consentRevision.value++
    }

    /** Primary action button: accept every visible consent, then submit. */
    fun acceptAllAndSubmit(androidContext: Context) {
        toggleCheckAll(true)
        submit(androidContext)
    }

    /** Tertiary action button: keep only compulsory consents on, clear the rest, then submit. */
    fun acceptRequiredAndSubmit(androidContext: Context) {
        _consentForm.value?.let { form ->
            val allCats = (form.categoryList?.dataPrincipalCategoryList ?: emptyList()) +
                    (form.categoryList?.consentActorCategoryList ?: emptyList())
            allCats.forEach { cat ->
                cat.purposeList?.forEach { purpose ->
                    purpose.buckets?.forEach { bucket ->
                        bucket.ctcpList?.forEach { ct ->
                            if (ct.compulsoryConsent != true) {
                                ct.consentStatus = false
                            }
                        }
                    }
                }
            }
        }
        syncCheckAllStatus()
        submit(androidContext)
    }

    fun onPrivacyNoticeAgreed(language: String, id: Int, version: Double) {
        reviewedPrivacyNotice = true
        // Store these for submission
        this.privacyAcceptedData = mapOf(
            "language_consented_to" to language,
            "consented_privacy_notice_id" to id,
            "consented_privacy_notice_version" to version,
            "reviewed_privacy_notice" to true
        )
        _uiState.value = ConsentFormUiState.Success
    }

    private var privacyAcceptedData: Map<String, Any?> = emptyMap()

    fun validateCompulsoryConsents(): Boolean {
        val form = _consentForm.value ?: return false
        val allCats = (form.categoryList?.dataPrincipalCategoryList ?: emptyList()) +
                (form.categoryList?.consentActorCategoryList ?: emptyList())
        
        allCats.forEach { category ->
            category.purposeList?.forEach { purpose ->
                purpose.buckets?.forEach { bucket ->
                    bucket.ctcpList?.forEach { ct ->
                        if (ct.compulsoryConsent == true && ct.consentStatus != true) {
                            return false
                        }
                    }
                }
            }
        }
        return true
    }

    fun getCompulsoryPiiIds(): Set<Any> {
        val ids = mutableSetOf<Any>()
        val form = _consentForm.value ?: return ids
        val allCats = (form.categoryList?.dataPrincipalCategoryList ?: emptyList()) +
                (form.categoryList?.consentActorCategoryList ?: emptyList())
        allCats.forEach { cat ->
            cat.purposeList?.forEach { p ->
                p.buckets?.forEach { b ->
                    b.ctcpList?.forEach { ct ->
                        if (ct.compulsoryConsent == true && ct.piiLabelId != null) {
                            safeId(ct.piiLabelId)?.let { ids.add(it) }
                        }
                    }
                }
            }
        }
        return ids
    }

    fun validatePii(): Boolean {
        val form = _consentForm.value ?: return false
        val compulsoryIds = getCompulsoryPiiIds()
        val allPii = (form.piiList?.dataPrincipalPiiList ?: emptyList()) +
                (form.piiList?.consentActorPiiList ?: emptyList())

        val invalidKeys = mutableSetOf<String>()
        for (pii in allPii) {
            val id = pii.id ?: continue
            val isMandatory = pii.isMandatory || compulsoryIds.contains(id)
            val context = pii.principalContext ?: ""
            val key = "${context}_$id"
            val value = piiValues[key] ?: ""

            if (isMandatory && value.trim().isEmpty()) {
                invalidKeys.add(key)
            }
        }
        _invalidPiiKeys.value = invalidKeys
        return invalidKeys.isEmpty()
    }

    /** Clears the inline error for a field as soon as the user starts fixing it. */
    fun onPiiValueChanged(key: String, value: String) {
        piiValues[key] = value
        if (key in _invalidPiiKeys.value) {
            _invalidPiiKeys.value = _invalidPiiKeys.value - key
        }
    }

    fun toggleCategoryConsent(category: ConsentFormResponse.Category, checked: Boolean) {
        category.purposeList?.forEach { purpose ->
            if (purpose.visible != false) {
                purpose.buckets?.forEach { bucket ->
                    if (bucket.visible != false) {
                        bucket.ctcpList?.forEach { ct ->
                            if (ct.visible != false) {
                                ct.consentStatus = checked
                            }
                        }
                    }
                }
            }
        }
        syncCheckAllStatus()
    }

    fun isCategorySelected(category: ConsentFormResponse.Category): Boolean {
        var hasAny = false
        var allSelected = true
        category.purposeList?.forEach { purpose ->
            if (purpose.visible != false) {
                purpose.buckets?.forEach { bucket ->
                    if (bucket.visible != false) {
                        bucket.ctcpList?.forEach { ct ->
                            if (ct.visible != false) {
                                hasAny = true
                                if (ct.consentStatus != true) allSelected = false
                            }
                        }
                    }
                }
            }
        }
        return hasAny && allSelected
    }

    /**
     * Fetches the privacy notice body for the current language, unless that exact fetch already
     * succeeded. Both entry points need it — the `showPrivacyNoticeBeforeConsent` gate and the
     * link on the form — and only the first one used to load it, so opening the notice from the
     * form gave an empty screen with a permanently disabled Agree button.
     */
    private suspend fun loadPrivacyNotice() {
        val formData = _consentForm.value ?: return
        val customerId = safeId(formData.additionalInfo?.customerId)?.toString() ?: return
        val pnId = safeId(formData.additionalInfo?.privacyNoticeId)?.toString() ?: return
        val language = _selectedLanguage.value
        if (loadedPrivacyLanguage == language && _privacyData.value.isNotEmpty()) return

        _isLoadingPrivacyNotice.value = true
        try {
            val data = api.getPrivacyNotice(customerId, pnId, language)?.result?.data ?: emptyList()
            _privacyData.value = data
            loadedPrivacyLanguage = if (data.isEmpty()) null else language
        } finally {
            _isLoadingPrivacyNotice.value = false
        }
    }

    fun showPrivacyNotice() {
        _uiState.value = ConsentFormUiState.PrivacyNoticeGating(isPreConsentGate = false)
        viewModelScope.launch { loadPrivacyNotice() }
    }

    fun closePrivacyNotice() {
        _uiState.value = ConsentFormUiState.Success
    }

    fun submit(androidContext: Context) {
        if (_isSubmitting.value || _submitSuccess.value != null) return
        val privacyAcceptedData = this.privacyAcceptedData
        if (!validatePii()) {
            _snackbarMessage.value = "Please fill all mandatory PII fields."
            return
        }
        if (!validateCompulsoryConsents()) {
            _snackbarMessage.value = "Please choose all compulsory consents before submitting."
            return
        }
        val form = _consentForm.value ?: return
        val ai = form.additionalInfo ?: return
        
        // 1) Build pii_data
        val piiData = mutableListOf<Map<String, Any>>()
        val allPii = (form.piiList?.dataPrincipalPiiList ?: emptyList()) +
                (form.piiList?.consentActorPiiList ?: emptyList())
        
        for (pii in allPii) {
            val id = safeId(pii.id) ?: continue
            val name = pii.name ?: continue
            val context = pii.principalContext ?: ""
            val key = "${context}_$id"
            val value = piiValues[key] ?: ""
            
            if (value.isNotEmpty()) {
                piiData.add(mapOf(
                    "pii_label_id" to id,
                    "pii_label_name" to name,
                    "pii_value" to PhoneIdentity.forLabel(name, value, pii.regEx),
                    "principal_context" to context
                ))
            }
        }


        val siTypeIds = ai.subjectIdentityTypeIds ?: emptyList()
        val submittedSubjectIdentityValues = siTypeIds.map { siId ->
            val idSafe = safeId(siId)
            val dpKey = "DATA_PRINCIPAL_$idSafe"
            val caKey = "CONSENT_ACTOR_$idSafe"
            val value = piiValues[dpKey] ?: piiValues[caKey] ?: ""
            mapOf(
                "pii_label_id" to idSafe,
                "pii_value" to PhoneIdentity.forLabel(piiLabelName(idSafe), value, piiRegexPatterns(idSafe))
            )
        }

        // 3) consent_status
        val consentStatus = mutableListOf<Map<String, Any?>>()
        val visibleCtIds = mutableSetOf<Any>()
        val allCats = (form.categoryList?.dataPrincipalCategoryList ?: emptyList()) +
                (form.categoryList?.consentActorCategoryList ?: emptyList())

        allCats.forEach { category ->
            val categoryVisible = category.visible != false
            category.purposeList?.forEach { purpose ->
                val pId = safeId(purpose.id) ?: return@forEach
                val pName = purpose.name ?: return@forEach
                val purposeVisible = categoryVisible && purpose.visible != false

                purpose.buckets?.forEach { bucket ->
                    val cpId = safeId(bucket.consentPurposeId) ?: return@forEach
                    val cpName = bucket.consentPurposeName ?: return@forEach
                    val bucketVisible = purposeVisible && bucket.visible != false

                    bucket.ctcpList?.forEach { ct ->
                        val ctId = safeId(ct.id)
                        if (bucketVisible && ct.visible != false && ctId != null) {
                            visibleCtIds.add(ctId)
                        }
                        consentStatus.add(mapOf(
                            "id" to ctId,
                            "processing_purpose_id" to pId,
                            "processing_purpose_name" to pName,
                            "consent_purpose_id" to cpId,
                            "consent_purpose_name" to cpName,
                            "pii_label_id" to safeId(ct.piiLabelId),
                            "pii_label" to ct.piiLabel,
                            "frequency" to null,
                            "consent_lifetime" to safeId(ct.consentLifetime),
                            "consent_expiration" to null,
                            "default_opt_out_allowed" to (ct.defaultOptOutAllowed ?: false),
                            "compulsory_consent" to (ct.compulsoryConsent ?: false),
                            "consent_status" to (ct.consentStatus ?: false),
                            "backend_consent_status" to null,
                            "manual_revoke_bool" to (ct.manualRevokeBool ?: false),
                            "manual_grant_bool" to (ct.manualGrantBool ?: false),
                            "vendor_id" to safeId(ct.vendorId),
                            "vendor_name" to ct.vendorName,
                            "process_id" to safeId(ct.processId),
                            "process_name" to ct.processName,
                            "principal_context" to ct.principalContext
                        ))
                    }
                }
            }
        }

        val payload = mutableMapOf<String, Any?>(
            "customer_id" to safeId(ai.customerId),
            "collection_template_id" to safeId(ai.collectionTemplateId),
            "consent_source" to "apk_form",
            "subject_identity_values" to submittedSubjectIdentityValues,
            "verification_key" to (ai.templateVerificationKey ?: ""),
            "consented_privacy_notice_id" to safeId(privacyAcceptedData["consented_privacy_notice_id"]),
            "consented_privacy_notice_version" to safeId(privacyAcceptedData["consented_privacy_notice_version"]),
            // Always the language the form is currently displayed/submitted in, not whatever
            // language the privacy notice happened to be agreed to in - the user can still switch
            // languages on the main form after that gate, and the evidence token backing this
            // submission is for _selectedLanguage.value, not the earlier privacy-notice choice.
            "language_consented_to" to _selectedLanguage.value,
            "pii_data" to piiData,
            "consent_status" to consentStatus,
            "reviewed_privacy_notice" to (privacyAcceptedData["reviewed_privacy_notice"] ?: false)
        )

        _digiLockerResult.value?.result?.data?.userDetails?.let {
            payload["digilocker_evidence"] = it
        }

        viewModelScope.launch {
            _isSubmitting.value = true
            try {
                // When captcha is disabled the reCAPTCHA webview is never created, no token is
                // requested, and `captcha_token` is left out of the payload entirely.
                if (enableCaptcha) {
                    when (val attempt = RecaptchaService.generateSubmitToken(androidContext)) {
                        is RecaptchaAttemptResult.Success -> {
                            payload["captcha_token"] = attempt.tokenResult.token
                        }
                        is RecaptchaAttemptResult.Failure -> {
                            _snackbarMessage.value = "Unable to verify captcha. Please try again."
                            return@launch
                        }
                    }
                }

                val response = api.saveConsentFormData(payload)
                if (response?.success == true) {
                    // What the host is told the user consented to: the entries that were on
                    // screen and left switched on, in the same shape the Flutter SDK reports.
                    val resultData = consentStatus
                        .filter { it["id"] in visibleCtIds && it["consent_status"] == true }
                        .map { entry ->
                            mapOf(
                                "processing_purpose_id" to entry["processing_purpose_id"],
                                "processing_purpose_name" to entry["processing_purpose_name"],
                                "consent_purpose_id" to entry["consent_purpose_id"],
                                "consent_purpose_name" to entry["consent_purpose_name"],
                                "consent_status" to entry["consent_status"],
                                // Not in Flutter's payload, but without it two entries for the
                                // same purpose (one per PII label) are indistinguishable.
                                "pii_label_id" to entry["pii_label_id"],
                                "pii_label" to entry["pii_label"],
                            )
                        }
                    _submitSuccess.value = ConsentSubmitSuccess(
                        message = response.message ?: "Consent form submitted successfully!",
                        statusCode = response.statusCode,
                        data = resultData
                    )
                } else {
                    val failureMessage = response?.message?.takeIf { it.isNotBlank() }
                    _submitError.value = ConsentSubmitError(
                        statusCode = response?.statusCode,
                        message = failureMessage,
                    )
                    _snackbarMessage.value =
                        failureMessage ?: "Failed to submit consent form. Please try again."
                }
            } finally {
                _isSubmitting.value = false
            }
        }
    }
}

sealed class ConsentFormUiState {
    object Loading : ConsentFormUiState()
    object Success : ConsentFormUiState()
    /** [isPreConsentGate] distinguishes the mandatory gate shown before the form (cross button
     *  must close the whole SDK) from the optional in-form "Privacy Policy" link (cross button
     *  just falls back to the form). */
    data class PrivacyNoticeGating(val isPreConsentGate: Boolean = false) : ConsentFormUiState()
    data class DigiLockerVerification(val url: String) : ConsentFormUiState()
    data class Error(val message: String) : ConsentFormUiState()
    data class MinorVerificationFailed(val message: String) : ConsentFormUiState()
}

data class ConsentSubmitSuccess(
    val message: String,
    val statusCode: Int?,
    val data: List<Map<String, Any?>>
)

/** A rejected submission. Transient — the form stays on screen and the user may resubmit. */
data class ConsentSubmitError(
    val statusCode: Int?,
    val message: String?
)
