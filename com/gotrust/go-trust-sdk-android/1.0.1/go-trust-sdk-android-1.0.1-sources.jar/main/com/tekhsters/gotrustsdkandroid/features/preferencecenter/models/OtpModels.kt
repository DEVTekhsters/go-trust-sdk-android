package com.tekhsters.gotrustsdkandroid.features.preferencecenter.models

import com.google.gson.annotations.SerializedName

/** Mirrors send_otp_model.dart */
data class SendOtpResponse(
    @SerializedName("success") val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("result") val result: Result?,
) {
    val userFound: Boolean? get() = result?.data?.userFound

    data class Result(@SerializedName("data") val data: Data?)
    data class Data(@SerializedName("user_found") val userFound: Boolean?)
}

/** Mirrors verify_otp_model.dart */
data class VerifyOtpResponse(
    @SerializedName("success") val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("result") val result: Result?,
) {
    val token: String? get() = result?.data?.firstOrNull()?.token

    data class Result(@SerializedName("data") val data: List<Data>?)
    data class Data(@SerializedName("token") val token: String?)
}
