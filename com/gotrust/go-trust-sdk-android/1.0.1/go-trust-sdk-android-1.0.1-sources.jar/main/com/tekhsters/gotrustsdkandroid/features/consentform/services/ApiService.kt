package com.tekhsters.gotrustsdkandroid.features.consentform.services

import android.util.Log
import com.tekhsters.gotrustsdkandroid.FallbackConfig
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.*
import okhttp3.Headers
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class ApiService private constructor() {

    private var baseUrl: String = ""
    private var publicToken: String? = null
    private var resolvedSourceId: Any? = null
    private var consentEvidenceToken: String? = null

    private var api: ConsentFormApi? = null

    // Host-provided proxy this session falls back to once GoTrust's primary display/submit APIs
    // start failing. Once _useFallback flips true it stays true for the rest of this ApiService
    // session — set again (and reset) on every setFallback() call, i.e. every new consent form.
    private var fallback: FallbackConfig? = null
    private val fallbackHeaders = mutableMapOf<String, String>()
    // Tracked alongside fallbackHeaders[csrfHeaderName] rather than read from it, so the two
    // can never drift: this is the token as the SDK last received it from refreshCsrfToken(),
    // fallbackHeaders holds what actually goes out on the wire.
    private var fallbackCsrfToken: String? = null
    private var useFallback = false
    val isFallbackActive: Boolean get() = useFallback

    private val fallbackHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY })
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    companion object {
        private const val TAG = "ApiService"
        // A 401/403 on a fallback call triggers a refresh + retry; if the freshly refreshed
        // token is rejected too, refresh again up to this many times before giving up.
        private const val MAX_CSRF_REFRESH_ATTEMPTS = 2
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        val instance: ApiService by lazy { ApiService() }
    }

    fun setFallback(fallback: FallbackConfig?) {
        this.fallback = fallback
        fallbackHeaders.clear()
        fallbackHeaders.putAll(fallback?.headers ?: emptyMap())
        fallbackCsrfToken = null
        useFallback = false
    }

    private data class FallbackHttpResult(val statusCode: Int?, val body: String?, val headers: Headers?)

    private fun updateCookieHeaderValue(cookieHeader: String?, cookieName: String, newValue: String): String {
        val pairs = (cookieHeader ?: "").split(";").map { it.trim() }.filter { it.isNotEmpty() }
        var found = false
        val updated = pairs.map { pair ->
            val eq = pair.indexOf('=')
            val key = (if (eq == -1) pair else pair.substring(0, eq)).trim()
            if (key == cookieName) {
                found = true
                "$cookieName=$newValue"
            } else pair
        }.toMutableList()
        if (!found) updated.add("$cookieName=$newValue")
        return updated.joinToString("; ")
    }

    private fun doFallbackPost(url: String, bodyJson: String): FallbackHttpResult {
        return try {
            val requestBuilder = Request.Builder().url(url).header("Content-Type", "application/json")
            fallbackHeaders.forEach { (k, v) -> requestBuilder.header(k, v) }
            val request = requestBuilder.post(bodyJson.toRequestBody(JSON_MEDIA_TYPE)).build()
            fallbackHttpClient.newCall(request).execute().use { response ->
                FallbackHttpResult(response.code, response.body?.string(), response.headers)
            }
        } catch (e: Exception) {
            Log.e(TAG, "fallback POST $url failed", e)
            FallbackHttpResult(null, null, null)
        }
    }

    private suspend fun fallbackPostWithRetry(url: String, payload: Map<String, Any?>): FallbackHttpResult =
        withContext(Dispatchers.IO) {
            val bodyJson = GsonProvider.gson.toJson(payload)
            var result = doFallbackPost(url, bodyJson)
            var refreshAttempts = 0
            while ((result.statusCode == 401 || result.statusCode == 403) &&
                fallback != null &&
                refreshAttempts < MAX_CSRF_REFRESH_ATTEMPTS
            ) {
                refreshAttempts++
                val fb = fallback!!
                val newToken = fb.refreshCsrfToken()
                if (newToken.isNullOrEmpty()) {
                    Log.d(TAG, "fallbackPostWithRetry: refreshCsrfToken returned no token on " +
                            "attempt $refreshAttempts, aborting retries")
                    break
                }
                fallbackCsrfToken = newToken
                fallbackHeaders[fb.csrfHeaderName] = newToken
                val cookieName = fb.csrfCookieName
                if (!cookieName.isNullOrEmpty()) {
                    fallbackHeaders["Cookie"] =
                        updateCookieHeaderValue(fallbackHeaders["Cookie"], cookieName, newToken)
                }
                result = doFallbackPost(url, bodyJson)
                Log.d(TAG, "fallbackPostWithRetry retry #$refreshAttempts: $url -> ${result.statusCode}")
            }
            result
        }

    fun setBaseUrl(url: String) {
        if (baseUrl == url && api != null) return
        baseUrl = url
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val authInterceptor = Interceptor { chain ->
            val original = chain.request()
            val requestBuilder = original.newBuilder()
            publicToken?.let {
                if (it.isNotEmpty()) {
                    Log.d(TAG, "Adding x-public-token: $it")
                    requestBuilder.header("x-public-token", it)
                }
            }
            chain.proceed(requestBuilder.build())
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .addInterceptor(authInterceptor)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(GsonProvider.gson))
            .build()

        api = retrofit.create(ConsentFormApi::class.java)
    }
    suspend fun fetchLanguages(customerId: String, formId: String): List<Language>? {
        return try {
            val response = api?.fetchLanguages(customerId = customerId, formId = formId)
            if (response?.isSuccessful == true) {
                val list = response.body()?.result?.data?.toMutableList() ?: mutableListOf()
                if (list.none { it.code == "en" }) {
                    list.add(0, Language(code = "en", name = "English"))
                }
                list
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchLanguages error", e)
            emptyList()
        }
    }

    suspend fun checkConsentStatus(sourceId: String, subjectIdentityValues: Map<String, Any?>, token: String? = null): CheckConsentResponse? {
        return try {
            val decrypterResponse = getConsentFormId(sourceId, token)
            val resolvedSourceId = Utils.safeId(decrypterResponse?.result?.data?.sourceId) ?: return null

            // In token flow the caller has no raw PII to pass in — the decryptor's own answer is
            // the effective identity, same as ConsentFormViewModel.effectiveSubjectIdentityValues.
            val effectiveSubjectIdentityValues: Map<String, Any?> = if (!token.isNullOrEmpty()) {
                (decrypterResponse?.result?.data?.subjectIdentityValues ?: emptyList())
                    .associate { Utils.safeId(it.piiLabelId).toString() to it.piiValue }
            } else subjectIdentityValues

            val subjectIdentityValuesList = effectiveSubjectIdentityValues.entries.map {
                mapOf(
                    "pii_label_id" to it.key.toInt(),
                    "pii_value" to PhoneIdentity.forUnknownLabel(it.value?.toString())
                )
            }

            val payload = mapOf(
                "source_id" to resolvedSourceId.toString(),
                "dynamic_consent" to true,
                "subject_identity_values" to subjectIdentityValuesList
            )
            val response = api?.checkConsentStatus(payload)
            if (response?.isSuccessful == true) {
                response.body()
            } else {
                if ((response == null || response.code() >= 500) && fallback != null) {
                    Log.d(TAG, "checkConsentStatus: verify API failed " +
                            "(status=${response?.code()}), switching to fallback for this session")
                    useFallback = true
                }
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "checkConsentStatus error", e)
            if (fallback != null) useFallback = true
            null
        }
    }

    suspend fun getConsentFormData(payload: Map<String, Any?>, sourceId: String?): ConsentFormResponse.ConsentFormData? {
        consentEvidenceToken = null

        var body: ConsentFormResponse? = null
        var evidenceToken: String? = null
        var headerPublicToken: String? = null

        if (!useFallback) {
            try {
                val response = api?.getConsentFormData(payload)
                if (response?.isSuccessful == true) {
                    body = response.body()
                    evidenceToken = response.headers()["x-consent-evidence-token"]
                    headerPublicToken = response.headers()["x-public-token"]
                } else {
                    if ((response == null || response.code() >= 500) && fallback != null) {
                        Log.d(TAG, "getConsentFormData: primary display failed " +
                                "(status=${response?.code()}), switching to fallback for this session")
                        useFallback = true
                    } else if (response == null) {
                        return null
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "getConsentFormData primary call failed", e)
                if (fallback != null) useFallback = true else return null
            }
        }

        if (useFallback) {
            val fb = fallback ?: return null
            val fallbackPayload: Map<String, Any?> = mapOf("source_id" to sourceId)
            val result = fallbackPostWithRetry(fb.displayUrl, fallbackPayload)
            if (result.statusCode == 200 && result.body != null) {
                body = try {
                    GsonProvider.gson.fromJson(result.body, ConsentFormResponse::class.java)
                } catch (e: Exception) {
                    Log.e(TAG, "getConsentFormData: unparseable fallback body", e)
                    null
                }
                evidenceToken = result.headers?.get("x-consent-evidence-token")
                headerPublicToken = result.headers?.get("x-public-token")
            } else {
                return null
            }
        }

        if (body == null) return null

        if (!evidenceToken.isNullOrEmpty()) {
            Log.d(TAG, "Adding x-evidence-token: $evidenceToken")
            consentEvidenceToken = evidenceToken
        }

        if (!headerPublicToken.isNullOrEmpty()) {
            publicToken = headerPublicToken
        }
        body.token?.let { if (it.isNotEmpty()) publicToken = it }
        body.result?.token?.let { if (it.isNotEmpty()) publicToken = it }
        body.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }

        return if (body.result?.data?.formTemplate != null) {
            body.result.data.formTemplate
        } else if (!body.result?.data?.formAccessUrl.isNullOrEmpty()) {
            getPlainJsonToDisplayConsent(body.result!!.data!!.formAccessUrl!!)
        } else null
    }

    suspend fun saveConsentFormData(payload: MutableMap<String, Any?>): SaveConsentResponse? = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build()
            
            // 1) get public IP
            val ipRequest = okhttp3.Request.Builder().url("https://api.ipify.org?format=json").build()
            var ip = "127.0.0.1"
            try {
                client.newCall(ipRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        val json = GsonProvider.gson.fromJson(body, Map::class.java)
                        ip = json["ip"] as? String ?: "127.0.0.1"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get IP", e)
            }

            // 2) look up country & continent
            var countryCode = "IN"
            var continent = "ASIA"
            val geoRequest = okhttp3.Request.Builder().url("https://ipapi.co/$ip/json").build()
            try {
                client.newCall(geoRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        val json = GsonProvider.gson.fromJson(body, Map::class.java)
                        countryCode = json["country"] as? String ?: "IN"
                        continent = json["continent_code"] as? String ?: "ASIA"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get Geo", e)
            }

            val geolocation = "$ip($countryCode)"
            payload["geolocation"] = geolocation
            payload["continent"] = continent

            // Once a session has fallen back (triggered by a primary display failure in
            // getConsentFormData), submissions stay on the fallback submit API for the rest of
            // that session too.
            val fb = fallback
            if (useFallback && fb != null) {
                val result = fallbackPostWithRetry(fb.submitUrl, payload)
                val statusCode = result.statusCode
                val isHttpSuccess = statusCode == 200 || statusCode == 202
                // 202 Accepted responses (the fallback submit API's success status) commonly
                // come back with an empty body, which Gson would throw on, so parse only when
                // there is something to parse.
                val parsed = result.body?.takeIf { it.isNotBlank() }?.let {
                    try {
                        GsonProvider.gson.fromJson(it, SaveConsentResponse::class.java)
                    } catch (e: Exception) {
                        Log.e(TAG, "saveConsentFormData: unparseable fallback body: $it", e)
                        null
                    }
                }
                SaveConsentResponse(
                    success = parsed?.success ?: isHttpSuccess,
                    statusCode = parsed?.statusCode ?: statusCode,
                    message = parsed?.message,
                    result = parsed?.result,
                )
            } else {
                val response = api?.saveConsentFormData(consentEvidenceToken, payload)
                when {
                    response == null -> saveFailure(null, "Consent form service is not initialised")
                    response.isSuccessful -> response.body()
                    // A rejected submission carries the reason in the error body, which `body()` is
                    // always null for. Without this the host's onError only ever sees `null`.
                    else -> parseSaveError(response)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "saveConsentFormData error", e)
            saveFailure(null, e.message ?: e::class.java.simpleName)
        }
    }


    private fun parseSaveError(response: retrofit2.Response<SaveConsentResponse>): SaveConsentResponse {
        val raw = try {
            response.errorBody()?.string()
        } catch (e: Exception) {
            Log.e(TAG, "saveConsentFormData: unreadable error body", e)
            null
        }
        val parsed = raw?.takeIf { it.isNotBlank() }?.let {
            try {
                GsonProvider.gson.fromJson(it, SaveConsentResponse::class.java)
            } catch (e: Exception) {
                Log.e(TAG, "saveConsentFormData: unparseable error body: $it", e)
                null
            }
        }
        return saveFailure(
            statusCode = parsed?.statusCode ?: response.code(),
            message = parsed?.message?.takeIf { it.isNotBlank() }
                ?: raw?.takeIf { it.isNotBlank() }
                ?: "HTTP ${response.code()} ${response.message()}".trim(),
        )
    }

    private fun saveFailure(statusCode: Int?, message: String) =
        SaveConsentResponse(success = false, statusCode = statusCode, message = message, result = null)

    suspend fun getConsentFormId(decryptedSourceId: String?, token: String? = null): DecrypterApiResponse? {
        return try {
            // Token wins over source_id when both are supplied: it replaces raw PII entirely, so
            // the decryptor is never asked to resolve both an identifier and a token at once.
            val data = if (!token.isNullOrEmpty()) {
                mapOf("token" to token)
            } else {
                mapOf("source_id" to decryptedSourceId)
            }
            val payload = mapOf("data" to data)
            val response = api?.getConsentFormId(payload)
            if (response?.isSuccessful == true) {
                val body = response.body()
                
                // Extract public token
                body?.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }
                
                resolvedSourceId = Utils.safeId(body?.result?.data?.sourceId)
                body
            } else {
                if ((response == null || response.code() >= 500) && fallback != null) {
                    Log.d(TAG, "getConsentFormId: decryptor failed " +
                            "(status=${response?.code()}), switching to fallback for this session")
                    useFallback = true
                }
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getConsentFormId error", e)
            if (fallback != null) useFallback = true
            null
        }
    }

    suspend fun getPrivacyNotice(customerId: String, privacyNoticeId: String, languageCode: String): PrivacyNoticeResponse? {
        return try {
            val response = api?.getPrivacyNotice(customerId, resolvedSourceId, languageCode)
            if (response?.isSuccessful == true) {
                response.body()
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getPrivacyNotice error", e)
            null
        }
    }

    suspend fun getPlainJsonToDisplayConsent(url: String): ConsentFormResponse.ConsentFormData? {
        return try {
            val response = api?.getPlainJsonToDisplayConsent(url)
            if (response?.isSuccessful == true) {
                response.body()
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getPlainJsonToDisplayConsent error", e)
            null
        }
    }

    suspend fun getDigiLockerResponse(sourceId: String): DigiLockerResponse? {
        return try {
            val consentUrl = "$baseUrl/public/consent-form?source_id=$sourceId"
            val response = api?.getDigiLockerResponse(consentUrl)
            if (response?.isSuccessful == true) {
                response.body()
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getDigiLockerResponse error", e)
            null
        }
    }

    suspend fun getCallbackApiResponse(code: String, state: String): CallBackResponse? {
        return try {
            val response = api?.getCallbackApiResponse(code, state)
            if (response?.isSuccessful == true) {
                val body = response.body()
                
                // Extract public token
                body?.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }
                
                body
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getCallbackApiResponse error", e)
            null
        }
    }
}
