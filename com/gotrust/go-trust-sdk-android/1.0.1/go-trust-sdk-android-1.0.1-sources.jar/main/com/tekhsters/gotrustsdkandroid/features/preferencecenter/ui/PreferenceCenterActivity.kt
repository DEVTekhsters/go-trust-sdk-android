package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.tekhsters.gotrustsdkandroid.core.callbacks.GoTrustSdkCallbacks
import com.tekhsters.gotrustsdkandroid.core.ui.SaveSuccessDialog
import com.tekhsters.gotrustsdkandroid.core.ui.SavingOverlay
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ADDITIONAL_PARAMS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_BASE_URL
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_CONSENT_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_CUSTOMER_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_DATA_JSON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ENABLE_CAPTCHA
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_LANGUAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_SUBJECT_VALUES
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_MESSAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_PF_TOKEN
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_PREFERENCE_FORM_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SAVED
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SHOW_CROSS_BUTTON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SOURCE_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_STATUS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_TOKEN
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_VIA_LOGIN
import com.tekhsters.gotrustsdkandroid.core.utils.LanguagePreferences
import com.tekhsters.gotrustsdkandroid.core.utils.readCaptchaFlag
import com.tekhsters.gotrustsdkandroid.core.utils.readInitialSubjectValues
import com.tekhsters.gotrustsdkandroid.features.consentform.models.GsonProvider
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.DigiLockerWebView
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.GoTrustSdkActivity

private const val CLOSED_BY_USER_MESSAGE = "Preference center closed by user"

internal class PreferenceCenterActivity : ComponentActivity() {

    private val viewModel: PreferenceCenterViewModel by viewModels()

    // Consent-form-on-login-failure flow is disabled — see PreferenceCenterViewModel.submitLogin().
    // Commented out rather than removed so it can be restored if needed.
    // private val consentFormLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
    //     if (result.resultCode == Activity.RESULT_OK) {
    //         viewModel.onConsentFormSubmitted()
    //     } else {
    //         viewModel.onConsentFormDismissed()
    //     }
    // }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        LanguagePreferences.init(this)

        val baseUrl = intent.getStringExtra(EXTRA_BASE_URL) ?: ""
        val customerId = intent.getStringExtra(EXTRA_CUSTOMER_ID)
        val preferenceFormId = intent.getStringExtra(EXTRA_PREFERENCE_FORM_ID)
        val pfToken = intent.getStringExtra(EXTRA_PF_TOKEN) ?: ""
        val consentId = intent.getStringExtra(EXTRA_CONSENT_ID) ?: ""
        val initialSubjectValues = intent.readInitialSubjectValues()
        @Suppress("UNCHECKED_CAST")
        val additionalParams = intent.getSerializableExtra(EXTRA_ADDITIONAL_PARAMS) as? Map<String, Any> ?: emptyMap()
        val initialLanguage = intent.getStringExtra(EXTRA_INITIAL_LANGUAGE) ?: "en"
        val enableCaptcha = intent.readCaptchaFlag()
        val token = intent.getStringExtra(EXTRA_TOKEN)

        viewModel.init(
            baseUrl = baseUrl,
            customerId = customerId,
            preferenceFormId = preferenceFormId,
            pfToken = pfToken,
            consentId = consentId,
            initialSubjectValues = initialSubjectValues,
            additionalParams = additionalParams,
            initialLanguage = initialLanguage,
            enableCaptcha = enableCaptcha,
            token = token,
        )

        setContent {
            MaterialTheme {
                // Explicit white — M3's default surface colour is a lavender-tinted white.
                Surface(color = Color.White) {
                    val state by viewModel.uiState.collectAsState()
                    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
                    // val consentFormRequest by viewModel.consentFormLaunchRequest.collectAsState()
                    val saveSuccessEvent by viewModel.saveSuccessEvent.collectAsState()
                    val saveErrorEvent by viewModel.saveErrorEvent.collectAsState()
                    val snackbarHostState = remember { SnackbarHostState() }

                    LaunchedEffect(snackbarMessage) {
                        snackbarMessage?.let {
                            snackbarHostState.showSnackbar(it)
                            viewModel.consumeSnackbar()
                        }
                    }

                    // Saving does not close the preference center, so both outcomes reach the host
                    // as they happen instead of waiting for the activity result.
                    LaunchedEffect(saveSuccessEvent) {
                        saveSuccessEvent?.let { event ->
                            GoTrustSdkCallbacks.preferenceCenter?.onSuccess?.invoke(
                                event.message,
                                event.data
                            )
                            viewModel.consumeSaveSuccessEvent()
                        }
                    }

                    LaunchedEffect(saveErrorEvent) {
                        saveErrorEvent?.let { message ->
                            GoTrustSdkCallbacks.preferenceCenter?.onError?.invoke(message)
                            viewModel.consumeSaveErrorEvent()
                        }
                    }

                    // LaunchedEffect(consentFormRequest) {
                    //     val req = consentFormRequest ?: return@LaunchedEffect
                    //     viewModel.consumeConsentFormLaunchRequest()
                    //     val intent = Intent(this@PreferenceCenterActivity, GoTrustSdkActivity::class.java).apply {
                    //         putExtra(EXTRA_BASE_URL, req.baseUrl)
                    //         putExtra(EXTRA_SOURCE_ID, req.sourceId)
                    //         putExtra(EXTRA_INITIAL_SUBJECT_VALUES, HashMap(req.initialSubjectValues))
                    //         putExtra(EXTRA_SHOW_CROSS_BUTTON, true)
                    //         putExtra(EXTRA_INITIAL_LANGUAGE, req.initialLanguage)
                    //         putExtra(EXTRA_ENABLE_CAPTCHA, req.enableCaptcha)
                    //         putExtra(EXTRA_VIA_LOGIN, true)
                    //         putExtra(EXTRA_ADDITIONAL_PARAMS, HashMap(req.additionalParams))
                    //     }
                    //     consentFormLauncher.launch(intent)
                    // }

                    BackHandler {
                        closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                    }

                    // Each screen below hosts its own Scaffold and handles its own window insets;
                    // applying them here too double-pads the app bar and leaves a strip of this
                    // Scaffold's background showing around the nested screen.
                    Scaffold(
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        containerColor = Color.White,
                        contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    ) { padding ->
                        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
                            when (val s = state) {
                                is PreferenceCenterUiState.Loading -> {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator()
                                    }
                                }
                                is PreferenceCenterUiState.Login -> LoginScreen(
                                    viewModel = viewModel,
                                    onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                                )
                                is PreferenceCenterUiState.Otp -> OtpScreen(
                                    viewModel = viewModel,
                                    onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                                )
                                is PreferenceCenterUiState.Dashboard -> DashboardScreen(
                                    viewModel = viewModel,
                                    onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                                )
                                is PreferenceCenterUiState.DigiLockerVerification -> DigiLockerWebView(
                                    url = s.url,
                                    onSuccess = { code, otpState -> viewModel.onDigiLockerSuccess(code, otpState) },
                                )
                                is PreferenceCenterUiState.MinorVerificationFailed -> {
                                    androidx.compose.material3.AlertDialog(
                                        onDismissRequest = {},
                                        title = { androidx.compose.material3.Text("Verification Failed") },
                                        text = { androidx.compose.material3.Text(s.message) },
                                        confirmButton = {
                                            androidx.compose.material3.TextButton(onClick = {
                                                viewModel.backToDashboardFromMinorFailure()
                                            }) { androidx.compose.material3.Text("Close") }
                                        },
                                    )
                                }
                                is PreferenceCenterUiState.ConsentNotGiven -> {
                                    androidx.compose.material3.AlertDialog(
                                        onDismissRequest = {},
                                        title = { androidx.compose.material3.Text("Consent Required") },
                                        text = { androidx.compose.material3.Text(
                                            "Consent has not been given yet. Please provide your consent to continue."
                                        ) },
                                        confirmButton = {
                                            androidx.compose.material3.TextButton(onClick = {
                                                closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                                            }) { androidx.compose.material3.Text("Close") }
                                        },
                                    )
                                }
                                is PreferenceCenterUiState.Error -> {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            androidx.compose.material3.Text(s.message)
                                            androidx.compose.material3.Button(onClick = { viewModel.loadLoginConfig() }) {
                                                androidx.compose.material3.Text("Retry")
                                            }
                                            androidx.compose.material3.Button(onClick = {
                                                closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                                            }) { androidx.compose.material3.Text("Close") }
                                        }
                                    }
                                }
                            }

                            // Overlays below render on top of whichever branch above is active
                            // (the Dashboard, unchanged) instead of replacing it, so saving never
                            // navigates away from — or closes — the preference center.

                            if (viewModel.savingOverlayVisible.value) {
                                SavingOverlay()
                            }

                            val successMessage = viewModel.saveSuccessMessage.value
                            if (successMessage != null) {
                                val accentColorHex = viewModel.dashboardData
                                    ?.preferenceCenterConfiguration
                                    ?.consentPurposeConfiguration
                                    ?.form
                                    ?.colorScheme
                                SaveSuccessDialog(
                                    message = successMessage,
                                    onDismiss = { viewModel.dismissSaveSuccessDialog() },
                                    accentColorHex = accentColorHex,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun closeWithResult(status: String, message: String? = null, dataJson: String? = null) {
        // A save that succeeded earlier in the session is the meaningful outcome even though the
        // user leaves via the close button, so the result reports "success" with the saved data —
        // otherwise a host reading only the result Intent could never tell a saved session from an
        // abandoned one. `onClose` still fires either way, matching Flutter.
        val saved = viewModel.savedAtLeastOnce
        val effectiveStatus = if (saved) "success" else status
        val resultIntent = Intent().apply {
            putExtra(EXTRA_STATUS, effectiveStatus)
            putExtra(EXTRA_SAVED, saved)
            message?.let { putExtra(EXTRA_MESSAGE, it) }
            val payloadJson = dataJson
                ?: if (saved) GsonProvider.gson.toJson(viewModel.lastSavedResult) else null
            payloadJson?.let { putExtra(EXTRA_DATA_JSON, it) }
        }
        setResult(if (saved) Activity.RESULT_OK else Activity.RESULT_CANCELED, resultIntent)

        GoTrustSdkCallbacks.preferenceCenter?.onClose?.invoke(message)
        // Terminal for this session — drop the registration so a host lambda that captured the
        // launching Activity is not held past this screen.
        GoTrustSdkCallbacks.clearPreferenceCenter()

        finish()
    }
}
