package com.tekhsters.gotrustsdkandroid.features.preferencecenter.models

import com.google.gson.JsonObject

/** Mirrors go-trust-mobile-sdk lib/features/consent_preferences/model/consent_audit_log_model.dart */
data class ConsentAuditPageResult(
    val items: List<ConsentTransaction>,
    val totalCount: Int?,
)

data class ConsentTransaction(
    val customerId: Int,
    val entityId: Int,
    val entityName: String,
    val collectionTemplateId: Int,
    val collectionTemplateName: String,
    val dataPrincipalId: Int,
    val subjectIdentity: String,
    val consentSource: String,
    val aggregatedConsentStatus: String,
    val geolocation: String,
    val consentedAt: String,
    val consentTransactionId: String,
    val metaInfo: List<MetaInfo>,
    val rawJson: JsonObject,
) {
    companion object {
        private fun i(json: JsonObject, key: String): Int = J.int(json, key) ?: 0
        private fun s(json: JsonObject, key: String): String = J.str(json, key) ?: ""

        fun fromJson(json: JsonObject) = ConsentTransaction(
            customerId = i(json, "customer_id"),
            entityId = i(json, "entity_id"),
            entityName = s(json, "entity_name"),
            collectionTemplateId = i(json, "collection_template_id"),
            collectionTemplateName = s(json, "collection_template_name"),
            dataPrincipalId = i(json, "data_principal_id"),
            subjectIdentity = s(json, "subject_identity"),
            consentSource = s(json, "consent_source"),
            aggregatedConsentStatus = s(json, "aggregated_consent_status"),
            geolocation = s(json, "geolocation"),
            consentedAt = s(json, "consented_at"),
            consentTransactionId = s(json, "consent_transaction_id"),
            metaInfo = J.arr(json, "meta_info")
                ?.mapNotNull { if (it.isJsonObject) MetaInfo.fromJson(it.asJsonObject) else null }
                ?: emptyList(),
            rawJson = json,
        )
    }
}

data class MetaInfo(
    val language: String,
    val frequency: String?,
    val vendorId: Int?,
    val processId: Int?,
    val vendorName: String?,
    val piiLabelId: Int,
    val piiLabelName: String,
    val processName: String?,
    val consentStatus: String,
    val privacyNoteId: Int,
    val privacyNoteName: String,
    val consentExpiration: String?,
    val consentPurposeId: Int,
    val consentPurposeName: String,
    val privacyNoteVersion: Int?,
    val languageConsentedAt: String,
    val processingPurposeId: Int,
    val processingPurposeName: String,
    val reviewedPrivacyNotice: Boolean,
    val collectionTemplateId: Int,
    val collectionTemplateName: String,
) {
    companion object {
        private fun i(json: JsonObject, key: String): Int = J.int(json, key) ?: 0
        private fun s(json: JsonObject, key: String): String = J.str(json, key) ?: ""

        fun fromJson(json: JsonObject) = MetaInfo(
            language = s(json, "language"),
            frequency = J.str(json, "frequency"),
            vendorId = J.int(json, "vendor_id"),
            processId = J.int(json, "process_id"),
            vendorName = J.str(json, "vendor_name"),
            piiLabelId = i(json, "pii_label_id"),
            piiLabelName = s(json, "pii_label_name"),
            processName = J.str(json, "process_name"),
            consentStatus = s(json, "consent_status"),
            privacyNoteId = i(json, "privacy_note_id"),
            privacyNoteName = s(json, "privacy_note_name"),
            consentExpiration = J.str(json, "consent_expiration"),
            consentPurposeId = i(json, "consent_purpose_id"),
            consentPurposeName = s(json, "consent_purpose_name"),
            privacyNoteVersion = J.int(json, "privacy_note_version"),
            languageConsentedAt = s(json, "language_consented_at"),
            processingPurposeId = i(json, "processing_purpose_id"),
            processingPurposeName = s(json, "processing_purpose_name"),
            reviewedPrivacyNotice = J.bool(json, "reviewed_privacy_notice") ?: false,
            collectionTemplateId = i(json, "collection_template_id"),
            collectionTemplateName = s(json, "collection_template_name"),
        )
    }
}
