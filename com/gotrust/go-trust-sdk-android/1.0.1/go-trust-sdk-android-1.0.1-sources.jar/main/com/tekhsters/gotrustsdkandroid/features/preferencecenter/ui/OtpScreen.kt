package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.core.utils.getFontWeight
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.LanguageSelector
import kotlinx.coroutines.delay

private fun px(value: String?, fallback: Double = 0.0): Double {
    if (value.isNullOrEmpty()) return fallback
    return value.replace("px", "").trim().toDoubleOrNull() ?: fallback
}

/**
 * Occupies an otherwise-empty OTP box so the IME always has a character to delete.
 *
 * Soft keyboards report a backspace as "remove the character before the caret" rather than as a
 * `Key.Backspace` event, so a genuinely empty field produces neither a key event nor an
 * `onValueChange` — the keystroke simply vanishes and the caret can never step back to fix an
 * earlier digit. A single space keeps every backspace observable while rendering as blank.
 */
private const val EMPTY_BOX_PLACEHOLDER = " "

@Composable
fun OtpScreen(viewModel: PreferenceCenterViewModel, onClose: () -> Unit) {
    val config by viewModel.loginConfig.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()
    val isResendBusy by viewModel.isResendBusy.collectAsState()

    val cfg = config?.configuration
    val verifyCfg = cfg?.verifyInputConfiguration

    if (cfg == null || verifyCfg == null) {
        Scaffold { padding ->
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Unable to open OTP page")
                    Spacer(Modifier.height(8.dp))
                    Row {
                        Button(onClick = onClose) { Text("Go Back") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { viewModel.loadLoginConfig() }) { Text("Retry") }
                    }
                }
            }
        }
        return
    }

    val digits = remember { mutableStateListOf("", "", "", "", "", "") }
    val otpInputCfg = verifyCfg.otpInput
    val borderColor = Utils.hexToColor(otpInputCfg?.strokeColor ?: "#D9D9D9")
    val boxSize = (otpInputCfg?.width ?: 40.0).dp
    val bannerBg = verifyCfg.banner?.backgroundColor ?: "#ffffff"

    // Keyed on otpResendEnabled so a resend (which flips it back to false) relaunches the
    // countdown; keyed on Unit it would only ever run once and the timer would stay stuck
    // after the seconds were reset to 120.
    LaunchedEffect(viewModel.otpResendEnabled.value) {
        if (viewModel.otpResendEnabled.value) return@LaunchedEffect
        while (viewModel.otpRemainingSeconds.intValue > 0) {
            delay(1000)
            viewModel.otpRemainingSeconds.intValue -= 1
        }
        viewModel.otpResendEnabled.value = true
    }

    fun tryVerify() {
        val otp = digits.joinToString("")
        if (otp.length == 6) viewModel.verifyOtp(otp)
    }

    val focusRequesters = remember { List(6) { FocusRequester() } }
    val focusManager = LocalFocusManager.current

    // Matches the Flutter page: the first box takes focus as soon as the screen appears.
    LaunchedEffect(Unit) { focusRequesters[0].requestFocus() }

    /**
     * Writes [raw] starting at box [index] and moves focus on. Handles a single keystroke, an
     * overwrite of a filled box, and a 6-digit paste / SMS autofill landing in one field.
     */
    fun onDigitsEntered(index: Int, raw: String) {
        val cleaned = raw.filter { it.isDigit() }
        val current = digits[index]

        // Nothing numeric left in the box means the user just deleted: either the digit that was
        // here, or — the box being empty already — the placeholder, which is the signal to step
        // back and clear the digit before it.
        if (cleaned.isEmpty()) {
            if (current.isNotEmpty()) {
                digits[index] = ""
            } else if (index > 0) {
                digits[index - 1] = ""
                focusRequesters[index - 1].requestFocus()
            }
            return
        }

        // Typing into a filled box arrives as "old+new"; keep only what the user just added.
        val incoming = if (current.isNotEmpty() && cleaned.length > 1 && cleaned.startsWith(current)) {
            cleaned.removePrefix(current)
        } else {
            cleaned
        }

        var cursor = index
        for (c in incoming) {
            if (cursor > 5) break
            digits[cursor] = c.toString()
            cursor++
        }

        // Park the caret on the last box once the code is complete rather than dropping focus:
        // with no focused field a backspace has nothing to act on, which left a fully typed code
        // impossible to correct after a failed verification.
        focusRequesters[cursor.coerceAtMost(5)].requestFocus()
        if (cursor > 5) tryVerify()
    }

    Scaffold(
        containerColor = Utils.hexToColor(bannerBg),
        topBar = {
            DynamicHeaderAppBar(
                closeIconPosition = verifyCfg.headerLayout?.closeIconPosition,
                logoPosition = verifyCfg.headerLayout?.logoPosition,
                dropdownPosition = verifyCfg.headerLayout?.dropdownPosition,
                backgroundColor = bannerBg,
                onClose = onClose,
                logo = if (!verifyCfg.logo?.logoUrl.isNullOrEmpty()) {
                    { AsyncImage(model = verifyCfg.logo?.logoUrl, contentDescription = null, modifier = Modifier.height(px(verifyCfg.logo?.height, 32.0).dp)) }
                } else null,
                dropdown = if (cfg.consentPurposeConfiguration?.form?.showLanguage == true) {
                    {
                        LanguageSelector(
                            languages = languages.ifEmpty {
                                listOf(com.tekhsters.gotrustsdkandroid.features.consentform.models.Language("en", "English"))
                            },
                            selectedCode = lang,
                            onChanged = { viewModel.onLanguageChanged(it) },
                            colorHex = verifyCfg.languageDropdown?.backgroundColor ?: "#000000",
                            textColor = verifyCfg.languageDropdown?.textColor ?: "#000000",
                        )
                    }
                } else null,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 24.dp),
        ) {
            Text(
                text = verifyCfg.heading?.text ?: "",
                color = Utils.hexToColor(verifyCfg.heading?.color ?: "#000000"),
                fontSize = px(verifyCfg.heading?.size, 18.0).sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "${verifyCfg.description?.beforeEmail ?: ""} ${lastIdentityValues(viewModel)} ${verifyCfg.description?.afterEmail ?: ""}",
                color = Utils.hexToColor(verifyCfg.description?.color ?: "#000000"),
                fontSize = px(verifyCfg.description?.size, 14.0).sp,
                fontWeight = getFontWeight(verifyCfg.description?.fontWeight),
            )
            Spacer(Modifier.height(24.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                for (i in 0 until 6) {
                    OutlinedTextField(
                        // A TextFieldValue rather than a plain String so the caret can be pinned
                        // after the box's single character. Compose carries the previous selection
                        // over when the hosted value changes, which would leave the caret at
                        // offset 0 after a delete — and a backspace with nothing before the caret
                        // is another silently dropped keystroke.
                        value = TextFieldValue(
                            text = digits[i].ifEmpty { EMPTY_BOX_PLACEHOLDER },
                            selection = TextRange(1),
                        ),
                        onValueChange = { newVal -> onDigitsEntered(i, newVal.text) },
                        singleLine = true,
                        textStyle = TextStyle(textAlign = TextAlign.Center, fontSize = 16.sp),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = if (i == 5) ImeAction.Done else ImeAction.Next,
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { focusRequesters[(i + 1).coerceAtMost(5)].requestFocus() },
                            onDone = { focusManager.clearFocus(); tryVerify() },
                        ),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = borderColor,
                            unfocusedBorderColor = borderColor,
                        ),
                        modifier = Modifier
                            .width(boxSize)
                            .height(56.dp)
                            .focusRequester(focusRequesters[i])
                            // Backspace in an empty box steps back and clears the previous digit;
                            // otherwise the caret would be stuck with nothing left to delete.
                            .onKeyEvent { event ->
                                if (event.type == KeyEventType.KeyDown &&
                                    event.key == Key.Backspace &&
                                    digits[i].isEmpty() && i > 0
                                ) {
                                    digits[i - 1] = ""
                                    focusRequesters[i - 1].requestFocus()
                                    true
                                } else {
                                    false
                                }
                            },
                    )
                    if (i != 5) Spacer(Modifier.width((otpInputCfg?.spacingBetween ?: 8.0).dp))
                }
            }

            Spacer(Modifier.weight(1f))

            Button(
                onClick = { tryVerify() },
                enabled = !isBusy,
                shape = RoundedCornerShape(px(verifyCfg.borderRadius, 12.0).dp),
                colors = ButtonDefaults.buttonColors(containerColor = Utils.hexToColor(verifyCfg.submitButton?.backgroundColor ?: "#2b6bec")),
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) {
                if (isBusy) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.height(20.dp))
                } else {
                    Text(
                        text = verifyCfg.submitButton?.text ?: "Verify",
                        color = Utils.hexToColor(verifyCfg.submitButton?.textColor ?: "#ffffff"),
                        fontSize = px(verifyCfg.submitButton?.size, 14.0).sp,
                        fontWeight = getFontWeight(verifyCfg.submitButton?.fontWeight),
                    )
                }
            }
            Spacer(Modifier.height(8.dp))

            if (viewModel.otpResendEnabled.value) {
                OutlinedButton(
                    onClick = { viewModel.resendOtp() },
                    enabled = !isResendBusy,
                    shape = RoundedCornerShape(px(verifyCfg.borderRadius, 12.0).dp),
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                ) {
                    if (isResendBusy) {
                        CircularProgressIndicator(
                            color = Utils.hexToColor(verifyCfg.secondaryButton?.textColor ?: "#000000"),
                            modifier = Modifier.height(20.dp),
                        )
                    } else {
                        Text(
                            text = verifyCfg.secondaryButton?.text ?: "Resend Code",
                            color = Utils.hexToColor(verifyCfg.secondaryButton?.textColor ?: "#000000"),
                        )
                    }
                }
            } else {
                Box(Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                    val m = viewModel.otpRemainingSeconds.intValue / 60
                    val s = viewModel.otpRemainingSeconds.intValue % 60
                    Text("Resend Code in $m:${s.toString().padStart(2, '0')}")
                }
            }
        }
    }
}

/** Shows each identity the way it was submitted, so a phone number reads back with its `+91`. */
private fun lastIdentityValues(viewModel: PreferenceCenterViewModel): String =
    viewModel.subjectIdentityInputs.keys.joinToString(", ") { viewModel.subjectIdentityPayloadValue(it) }
