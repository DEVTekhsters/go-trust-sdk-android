package com.tekhsters.gotrustsdkandroid.features.consentform.services

import com.google.gson.annotations.SerializedName
import com.tekhsters.gotrustsdkandroid.features.consentform.models.*
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface ConsentFormApi {

    @GET("universal/public/api/v2/translator/language-codes")
    suspend fun fetchLanguages(
        @Query("mode") mode: String = "form",
        @Query("customer_id") customerId: String,
        @Query("form_id") formId: String
    ): Response<LanguageResponseWrapper>

    @POST("universal/public/api/v2/ct/verify")
    suspend fun checkConsentStatus(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<CheckConsentResponse>

    @POST("universal/public/api/v6/gtf/display")
    suspend fun getConsentFormData(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<ConsentFormResponse>

    @GET("universal/public/api/v6/gtf/display")
    suspend fun fetchConsentFormData(
        @Query("source_id") sourceId: Any,
        @Query("language_code") languageCode: String,
        @Query("subject_identity") subjectIdentity: String
    ): Response<ConsentFormResponse>

    @POST("universal/public/api/v3/data-collector/records")
    suspend fun saveConsentFormData(
        @Header("x-consent-evidence-token") evidenceToken: String?,
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<SaveConsentResponse>

    @POST("universal/public/api/v1/security/decryptor")
    suspend fun getConsentFormId(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<DecrypterApiResponse>

    @GET("universal/public/api/v2/ct/frequency-list")
    suspend fun getFrequencyList(
        @Query("language_code") languageCode: String
    ): Response<ResponseBody> // Using ResponseBody for now if FrequencyListResponse is not yet defined or complex

    @GET("universal/public/api/v2/pn/display")
    suspend fun getPrivacyNotice(
        @Query("customer_id") customerId: String,
        @Query("source_id") sourceId: Any?,
        @Query("language_code") languageCode: String
    ): Response<PrivacyNoticeResponse>

    @GET
    suspend fun getPlainJsonToDisplayConsent(
        @Url url: String
    ): Response<ConsentFormResponse.ConsentFormData>

    @GET("universal/public/api/v3/digilocker/login")
    suspend fun getDigiLockerResponse(
        @Query("redirect_uri") redirectUri: String
    ): Response<DigiLockerResponse>

    @GET("universal/public/api/v3/digilocker/callback")
    suspend fun getCallbackApiResponse(
        @Query("code") code: String,
        @Query("state") state: String
    ): Response<CallBackResponse>
}

// Wrapper for Language response since it's nested in result.data in Flutter
data class LanguageResponseWrapper(
    @SerializedName("result") val result: Result?
) {
    data class Result(
        @SerializedName("data") val data: List<Language>?
    )
}
