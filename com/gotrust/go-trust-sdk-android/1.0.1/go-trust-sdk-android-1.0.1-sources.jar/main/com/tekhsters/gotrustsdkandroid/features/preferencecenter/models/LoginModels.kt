package com.tekhsters.gotrustsdkandroid.features.preferencecenter.models

import com.google.gson.JsonObject

/** Mirrors go-trust-mobile-sdk lib/features/consent_preferences/model/login_model.dart */
data class LoginConfig(
    val subjectIdentityTypeId: Int? = null,
    val subjectIdentityTypeName: String? = null,
    val subjectIdentityTypes: List<SubjectIdentityTypes>? = null,
    val configuration: PreferenceCenterConfiguration? = null,
) {
    companion object {
        fun fromJson(json: JsonObject): LoginConfig {
            val dataList = J.arr(J.obj(json, "result"), "data")
            val data = dataList?.firstOrNull { it.isJsonObject }?.asJsonObject ?: return LoginConfig()
            val rawConfig = J.obj(data, "preference_center_configuration")
            val configuration = when {
                rawConfig != null && J.obj(rawConfig, "mobile") != null ->
                    PreferenceCenterConfiguration.fromJson(J.obj(rawConfig, "mobile")!!)
                rawConfig != null && J.obj(rawConfig, "desktop") != null ->
                    PreferenceCenterConfiguration.fromJson(J.obj(rawConfig, "desktop")!!)
                rawConfig != null -> PreferenceCenterConfiguration.fromJson(rawConfig)
                else -> null
            }
            return LoginConfig(
                subjectIdentityTypeId = J.int(data, "subject_identity_type_id"),
                subjectIdentityTypeName = J.str(data, "subject_identity_type_name"),
                subjectIdentityTypes = J.arr(data, "subject_identity_types")
                    ?.mapNotNull { if (it.isJsonObject) SubjectIdentityTypes.fromJson(it.asJsonObject) else null },
                configuration = configuration,
            )
        }
    }
}

data class SubjectIdentityTypes(
    val id: Int?,
    val name: String?,
    val position: Int?,
) {
    companion object {
        fun fromJson(json: JsonObject) = SubjectIdentityTypes(
            id = J.int(json, "id"),
            name = J.str(json, "name"),
            position = J.int(json, "position"),
        )
    }
}

data class PreferenceCenterConfiguration(
    val fontFamily: String?,
    val logoUrl: String?,
    val showLogo: Boolean?,
    val showCookie: Boolean?,
    val showConsent: Boolean?,
    val showDSR: Boolean?,
    val title: String?,
    val description: String?,
    val privacyNoticeHeading: String?,
    val preferenceCenterHeading: String?,
    val dsrCenterHeading: String?,
    val dsrUrl: String?,
    val dpoEmail: String?,
    val dsrContent: String?,
    val consentPurposeConfiguration: LoginConsentPurposeConfiguration?,
    val userInputConfiguration: UserInputConfiguration?,
    val verifyInputConfiguration: VerifyInputConfiguration?,
) {
    companion object {
        fun fromJson(json: JsonObject) = PreferenceCenterConfiguration(
            fontFamily = J.str(json, "fontFamily"),
            logoUrl = J.str(json, "logoUrl") ?: J.str(json, "logo_url"),
            showLogo = J.bool(json, "showLogo"),
            showCookie = J.bool(json, "showCookie"),
            showConsent = J.bool(json, "showConsent"),
            showDSR = J.bool(json, "showDSR"),
            title = J.str(json, "title"),
            description = J.str(json, "description"),
            privacyNoticeHeading = J.str(json, "privacy_notice_heading"),
            preferenceCenterHeading = J.str(json, "preference_center_heading"),
            dsrCenterHeading = J.str(json, "dsr_center_heading"),
            dsrUrl = J.str(json, "dsrURL"),
            dpoEmail = J.str(json, "dpoEmail"),
            dsrContent = J.str(json, "dsrContent"),
            consentPurposeConfiguration = J.obj(json, "consent_purpose_configuration")
                ?.let { LoginConsentPurposeConfiguration.fromJson(it) },
            userInputConfiguration = J.obj(json, "user_input_configuration")
                ?.let { UserInputConfiguration.fromJson(it) },
            verifyInputConfiguration = J.obj(json, "verify_input_configuration")
                ?.let { VerifyInputConfiguration.fromJson(it) },
        )
    }
}

data class LoginConsentPurposeConfiguration(val form: LoginConsentFormConfiguration?) {
    companion object {
        fun fromJson(json: JsonObject) = LoginConsentPurposeConfiguration(
            form = J.obj(json, "form")?.let { LoginConsentFormConfiguration.fromJson(it) }
        )
    }
}

data class LoginConsentFormConfiguration(val showLanguage: Boolean?) {
    companion object {
        fun fromJson(json: JsonObject) = LoginConsentFormConfiguration(J.bool(json, "show_language"))
    }
}

data class UserInputConfiguration(
    val logo: Logo?,
    val heading: Heading?,
    val description: Heading?,
    val submitButton: BannerModel?,
    val borderRadius: String?,
    val fontFamily: String?,
    val banner: BannerModel?,
    val closeIcon: CloseIcon?,
    val headerLayout: HeaderLayout?,
    val formSection: FormSection?,
    val footerSection: FormSection?,
    val headerSection: FormSection?,
    val languageDropdown: LanguageDropdownModel?,
    val emailInput: EmailInputModel?,
) {
    companion object {
        fun fromJson(json: JsonObject) = UserInputConfiguration(
            logo = J.obj(json, "logo")?.let { Logo.fromJson(it) },
            heading = J.obj(json, "heading")?.let { Heading.fromJson(it) },
            description = J.obj(json, "description")?.let { Heading.fromJson(it) },
            submitButton = J.obj(json, "submit_button")?.let { BannerModel.fromJson(it) },
            borderRadius = J.str(json, "border_radius"),
            fontFamily = J.str(json, "font_family"),
            banner = J.obj(json, "banner")?.let { BannerModel.fromJson(it) },
            closeIcon = J.obj(json, "close_icon")?.let { CloseIcon.fromJson(it) },
            headerLayout = J.obj(json, "header_layout")?.let { HeaderLayout.fromJson(it) },
            formSection = J.obj(json, "form_section")?.let { FormSection.fromJson(it) },
            footerSection = J.obj(json, "footer_section")?.let { FormSection.fromJson(it) },
            headerSection = J.obj(json, "header_section")?.let { FormSection.fromJson(it) },
            languageDropdown = J.obj(json, "language_dropdown")?.let { LanguageDropdownModel.fromJson(it) },
            emailInput = J.obj(json, "email_input")?.let { EmailInputModel.fromJson(it) },
        )
    }
}

data class EmailInputModel(
    val backgroundColor: String?,
    val borderColor: String?,
    val borderRadius: Double?,
    val borderWidth: Double?,
    val height: Double?,
    val width: Double?,
    val shape: String?,
    val labelColor: String?,
    val textColor: String?,
    val padding: PaddingModel?,
) {
    companion object {
        fun fromJson(json: JsonObject) = EmailInputModel(
            backgroundColor = J.str(json, "background_color"),
            borderColor = J.str(json, "border_color"),
            borderRadius = J.doublePx(json, "border_radius"),
            borderWidth = J.double(json, "border_width"),
            height = J.doublePx(json, "height"),
            width = J.doublePx(json, "width"),
            shape = J.str(json, "shape"),
            labelColor = J.str(json, "labelColor"),
            textColor = J.str(json, "textColor"),
            padding = J.obj(json, "padding")?.let { PaddingModel.fromJson(it) },
        )
    }
}

data class Logo(
    val showLogo: Boolean?,
    val logoUrl: String?,
    val width: String?,
    val height: String?,
    val marginBottom: Double?,
    val opacity: Double?,
    val padding: PaddingModel?,
) {
    companion object {
        fun fromJson(json: JsonObject) = Logo(
            showLogo = J.bool(json, "show_logo"),
            logoUrl = J.str(json, "logo_url"),
            width = J.str(json, "width"),
            height = J.str(json, "height"),
            marginBottom = J.double(json, "margin_bottom"),
            opacity = J.double(json, "opacity"),
            padding = J.obj(json, "padding")?.let { PaddingModel.fromJson(it) },
        )
    }
}

data class Heading(
    val text: String?,
    val color: String?,
    val size: String?,
    val fontFamily: String?,
    val fontWeight: String?,
    val marginBottom: Double?,
    val padding: PaddingModel?,
    val textFormatting: TextFormatting?,
) {
    companion object {
        fun fromJson(json: JsonObject) = Heading(
            text = J.str(json, "text"),
            color = J.str(json, "color"),
            size = J.str(json, "size"),
            fontFamily = J.str(json, "font_family"),
            fontWeight = J.str(json, "font_weight"),
            marginBottom = J.double(json, "margin_bottom"),
            padding = J.obj(json, "padding")?.let { PaddingModel.fromJson(it) },
            textFormatting = J.obj(json, "text_formatting")?.let { TextFormatting.fromJson(it) },
        )
    }
}

data class VerifyInputConfiguration(
    val logo: Logo?,
    val heading: Heading?,
    val description: Description?,
    val submitButton: SubmitButtonModel?,
    val secondaryButton: SubmitButtonModel?,
    val borderRadius: String?,
    val fontFamily: String?,
    val authentication: Boolean?,
    val closeIcon: CloseIcon?,
    val banner: BannerModel?,
    val headerLayout: HeaderLayout?,
    val otpInput: OtpInput?,
    val languageDropdown: LanguageDropdownModel?,
) {
    companion object {
        fun fromJson(json: JsonObject) = VerifyInputConfiguration(
            logo = J.obj(json, "logo")?.let { Logo.fromJson(it) },
            heading = J.obj(json, "heading")?.let { Heading.fromJson(it) },
            description = J.obj(json, "description")?.let { Description.fromJson(it) },
            submitButton = J.obj(json, "submit_button")?.let { SubmitButtonModel.fromJson(it) },
            secondaryButton = J.obj(json, "secondary_button")?.let { SubmitButtonModel.fromJson(it) },
            borderRadius = J.str(json, "border_radius"),
            fontFamily = J.str(json, "font_family"),
            authentication = J.bool(json, "authentication"),
            closeIcon = J.obj(json, "close_icon")?.let { CloseIcon.fromJson(it) },
            banner = J.obj(json, "banner")?.let { BannerModel.fromJson(it) },
            headerLayout = J.obj(json, "header_layout")?.let { HeaderLayout.fromJson(it) },
            otpInput = J.obj(json, "otp_input")?.let { OtpInput.fromJson(it) },
            languageDropdown = J.obj(json, "language_dropdown")?.let { LanguageDropdownModel.fromJson(it) },
        )
    }
}

data class Description(
    val beforeEmail: String?,
    val afterEmail: String?,
    val color: String?,
    val size: String?,
    val fontFamily: String?,
    val fontWeight: String?,
    val padding: PaddingModel?,
    val textFormatting: TextFormatting?,
) {
    companion object {
        fun fromJson(json: JsonObject) = Description(
            beforeEmail = J.str(json, "before_email"),
            afterEmail = J.str(json, "after_email"),
            color = J.str(json, "color"),
            size = J.str(json, "size"),
            fontFamily = J.str(json, "font_family"),
            fontWeight = J.str(json, "font_weight"),
            padding = J.obj(json, "padding")?.let { PaddingModel.fromJson(it) },
            textFormatting = J.obj(json, "text_formatting")?.let { TextFormatting.fromJson(it) },
        )
    }
}

data class BannerModel(
    val backgroundColor: String?,
    val borderColor: String?,
    val borderWidth: Double?,
    val borderRadius: Double?,
    val height: Double?,
    val width: Double?,
    val padding: PaddingModel?,
    val text: String?,
    val textColor: String?,
    val fontFamily: String?,
    val fontWeight: String?,
    val fontSize: Double?,
    val color: String?,
    val size: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = BannerModel(
            backgroundColor = J.str(json, "background_color"),
            borderColor = J.str(json, "border_color"),
            borderWidth = J.double(json, "border_width"),
            borderRadius = J.doublePx(json, "border_radius"),
            height = J.doublePx(json, "height"),
            width = J.doublePx(json, "width"),
            padding = J.obj(json, "padding")?.let { PaddingModel.fromJson(it) },
            text = J.str(json, "text"),
            textColor = J.str(json, "text_color"),
            fontFamily = J.str(json, "font_family"),
            fontWeight = J.str(json, "font_weight"),
            fontSize = J.double(json, "size"),
            color = J.str(json, "color"),
            size = J.str(json, "size"),
        )
    }
}

data class PaddingModel(
    val top: Double?,
    val bottom: Double?,
    val left: Double?,
    val right: Double?,
) {
    companion object {
        fun fromJson(json: JsonObject) = PaddingModel(
            top = J.double(json, "top"),
            bottom = J.double(json, "bottom"),
            left = J.double(json, "left"),
            right = J.double(json, "right"),
        )
    }
}

data class CloseIcon(val backgroundColor: String?, val color: String?, val weight: String?) {
    companion object {
        fun fromJson(json: JsonObject) = CloseIcon(
            backgroundColor = J.str(json, "background_color"),
            color = J.str(json, "color"),
            weight = J.str(json, "weight"),
        )
    }
}

data class HeaderLayout(
    val closeIconPosition: String?,
    val dropdownPosition: String?,
    val logoPosition: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = HeaderLayout(
            closeIconPosition = J.str(json, "close_icon_position"),
            dropdownPosition = J.str(json, "dropdown_position"),
            logoPosition = J.str(json, "logo_position"),
        )
    }
}

data class FormSection(val padding: PaddingModel?) {
    companion object {
        fun fromJson(json: JsonObject) = FormSection(J.obj(json, "padding")?.let { PaddingModel.fromJson(it) })
    }
}

data class TextFormatting(
    val alignment: String?,
    val bold: Boolean?,
    val italic: Boolean?,
    val underline: Boolean?,
) {
    companion object {
        fun fromJson(json: JsonObject) = TextFormatting(
            alignment = J.str(json, "alignment"),
            bold = J.bool(json, "bold"),
            italic = J.bool(json, "italic"),
            underline = J.bool(json, "underline"),
        )
    }
}

data class OtpInput(
    val backgroundColor: String?,
    val fontFamily: String?,
    val fontSize: Double?,
    val fontWeight: String?,
    val height: Double?,
    val width: Double?,
    val shape: String?,
    val spacingBetween: Double?,
    val strokeColor: String?,
    val strokeWeight: Double?,
    val textColor: String?,
    val padding: PaddingModel?,
) {
    companion object {
        fun fromJson(json: JsonObject) = OtpInput(
            backgroundColor = J.str(json, "background_color"),
            fontFamily = J.str(json, "font_family"),
            fontSize = J.double(json, "font_size"),
            fontWeight = J.str(json, "font_weight"),
            height = J.doublePx(json, "height"),
            width = J.doublePx(json, "width"),
            shape = J.str(json, "shape"),
            spacingBetween = J.double(json, "spacing_between"),
            strokeColor = J.str(json, "stroke_color"),
            strokeWeight = J.double(json, "stroke_weight"),
            textColor = J.str(json, "text_color"),
            padding = J.obj(json, "padding")?.let { PaddingModel.fromJson(it) },
        )
    }
}

data class SubmitButtonModel(
    val backgroundColor: String?,
    val color: String?,
    val textColor: String?,
    val fontFamily: String?,
    val fontWeight: String?,
    val size: String?,
    val height: Double?,
    val width: Double?,
    val shape: String?,
    val text: String?,
    val padding: PaddingModel?,
) {
    companion object {
        fun fromJson(json: JsonObject) = SubmitButtonModel(
            backgroundColor = J.str(json, "background_color"),
            color = J.str(json, "color"),
            textColor = J.str(json, "text_color"),
            fontFamily = J.str(json, "font_family"),
            fontWeight = J.str(json, "font_weight"),
            size = J.str(json, "size"),
            height = J.doublePx(json, "height"),
            width = J.doublePx(json, "width"),
            shape = J.str(json, "shape"),
            text = J.str(json, "text"),
            padding = J.obj(json, "padding")?.let { PaddingModel.fromJson(it) },
        )
    }
}

data class LanguageDropdownModel(
    val backgroundColor: String?,
    val fontFamily: String?,
    val fontWeight: String?,
    val fontSize: Double?,
    val height: Double?,
    val width: Double?,
    val strokeColor: String?,
    val textColor: String?,
) {
    companion object {
        fun fromJson(json: JsonObject) = LanguageDropdownModel(
            backgroundColor = J.str(json, "background_color"),
            fontFamily = J.str(json, "font_family"),
            fontWeight = J.str(json, "font_weight"),
            fontSize = J.double(json, "font_size"),
            height = J.doublePx(json, "height"),
            width = J.doublePx(json, "width"),
            strokeColor = J.str(json, "stroke_color"),
            textColor = J.str(json, "text_color"),
        )
    }
}
