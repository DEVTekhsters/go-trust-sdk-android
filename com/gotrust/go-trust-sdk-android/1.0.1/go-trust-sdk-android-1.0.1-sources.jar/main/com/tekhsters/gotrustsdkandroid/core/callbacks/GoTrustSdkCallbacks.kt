package com.tekhsters.gotrustsdkandroid.core.callbacks

import com.tekhsters.gotrustsdkandroid.FallbackConfig

class ConsentFormCallbacks(
    val onSuccess: ((statusCode: Int?, message: String?, data: List<Map<String, Any?>>) -> Unit)? = null,
    val onError: ((statusCode: Int?, message: String?) -> Unit)? = null,
    val onClose: ((message: String?) -> Unit)? = null,
)


class PreferenceCenterCallbacks(
    val onSuccess: ((message: String?, data: List<Map<String, Any?>>) -> Unit)? = null,
    val onError: ((message: String?) -> Unit)? = null,
    val onClose: ((message: String?) -> Unit)? = null,
)


object GoTrustSdkCallbacks {

    @Volatile
    var consentForm: ConsentFormCallbacks? = null

    @Volatile
    var preferenceCenter: PreferenceCenterCallbacks? = null

    /** Set by [com.tekhsters.gotrustsdkandroid.GoTrustSdk.showConsentForm] for the same reason
     *  [consentForm] lives here: a suspend lambda can't cross an Intent. */
    @Volatile
    var fallback: FallbackConfig? = null


    fun clearConsentForm() {
        consentForm = null
        fallback = null
    }

    fun clearPreferenceCenter() {
        preferenceCenter = null
    }
}
