package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class ConsentFormResponse(
    @SerializedName("success") val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("token") val token: String?,
    @SerializedName("result") val result: Result?,
    @SerializedName("time") val time: Long?
) {
    data class Result(
        @SerializedName("token") val token: String?,
        @SerializedName("data") val data: Data?,
        @SerializedName("count") val count: Int?
    )

    data class Data(
        @SerializedName("form_access_url") val formAccessUrl: String?,
        @SerializedName("version") val version: Int?,
        @SerializedName("token") val token: String?,
        @SerializedName("form_template") val formTemplate: ConsentFormData?
    )

    data class ConsentFormData(
        @SerializedName("additional_info") val additionalInfo: AdditionalInfo?,
        @SerializedName("basic_info") val basicInfo: BasicInfo?,
        @SerializedName("form_configuration") val formConfiguration: FormConfiguration?,
        @SerializedName("pii_list") val piiList: PiiList?,
        @SerializedName("category_list") val categoryList: CategoryList?
    )

    data class AdditionalInfo(
        @SerializedName("form_id") val formId: Any?,
        @SerializedName("customer_id") val customerId: Any?,
        @SerializedName("subject_identity_type_id") val subjectIdentityTypeId: Any?,
        @SerializedName("subject_identity_type_name") val subjectIdentityTypeName: String?,
        @SerializedName("collection_template_id") val collectionTemplateId: Any?,
        @SerializedName("collection_template_name") val collectionTemplateName: String?,
        @SerializedName("template_verfication_key") val templateVerificationKey: String?,
        @SerializedName("form_url") val formUrl: String?,
        @SerializedName("captcha_needed") val captchaNeeded: String?,
        @SerializedName("form_redirect_url") val formRedirectUrl: String?,
        @SerializedName("is_published") val isPublished: Boolean?,
        @SerializedName("created_at") val createdAt: String?,
        @SerializedName("updated_at") val updatedAt: String?,
        @SerializedName("entity_id") val entityId: Any?,
        @SerializedName("active_status_of_collection_template") val activeStatusOfCollectionTemplate: Boolean?,
        @SerializedName("privacy_notice_id") val privacyNoticeId: Any?,
        @SerializedName("privacy_notice_name") val privacyNoticeName: String?,
        @SerializedName("privacy_notice_version") val privacyNoticeVersion: Any?,
        @SerializedName("privacy_notice_url") val privacyNoticeUrl: String?,
        @SerializedName("form_link_expiry_duration") val formLinkExpiryDuration: Any?,
        @SerializedName("subject_identity_type_ids") val subjectIdentityTypeIds: List<Any>?,
        @SerializedName("subject_identity_types") val subjectIdentityTypes: List<SubjectIdentityTypes>?
    )

    data class SubjectIdentityTypes(
        @SerializedName("id") val id: Any?,
        @SerializedName("name") val name: String?,
        @SerializedName("position") val position: Any?
    )

    data class BasicInfo(
        @SerializedName("title") val title: String?,
        @SerializedName("description") val description: String?,
        @SerializedName("pii_input_heading") val piiInputHeading: String?,
        @SerializedName("preference_input_heading") val preferenceInputHeading: String?,
        @SerializedName("form_footer_content") val formFooterContent: String?
    )

    data class FormConfiguration(
        @SerializedName("form") val form: ConfgForm?,
        @SerializedName("pii_section") val piiSection: PiiSection?,
        @SerializedName("consent_collection_section") val consentCollectionSection: ConsentCollectionSection?,
        @SerializedName("form_footer") val formFooter: FormFooter?,
        @SerializedName("submit_button") val submitButton: Heading?,
        @SerializedName("section_alignments") val sectionAlignments: SectionAlignments?,
        @SerializedName("action_buttons") val actionButtons: List<ActionButton>?,
        @SerializedName("button_orientation") val buttonOrientation: String?
    )

    data class SectionAlignments(
        @SerializedName("banner") val banner: String?,
        @SerializedName("illustration") val illustration: String?,
        @SerializedName("submit_action") val submitAction: String?,
        @SerializedName("footer") val footer: String?,
        @SerializedName("consent_section") val consentSection: String?,
        @SerializedName("pii_section") val piiSection: String?
    )

    data class ActionButton(
        @SerializedName("id") val id: String?,
        @SerializedName("enabled") val enabled: Boolean?,
        @SerializedName("text") val text: String?,
        @SerializedName("color") val color: String?,
        @SerializedName("text_color") val textColor: String?,
        @SerializedName("size") val size: String?,
        @SerializedName("font_weight") val fontWeight: String?,
        @SerializedName("border_radius") val borderRadius: String?,
        @SerializedName("border_color") val borderColor: String?,
        @SerializedName("border_width") val borderWidth: String?,
        @SerializedName("shape") val shape: String?
    )

    data class PiiSection(
        @SerializedName("show_pii_section") val showPiiSection: Boolean?,
        @SerializedName("show_badges") val showBadges: Boolean?,
        @SerializedName("description") val description: Heading?,
        @SerializedName("consent_actor_heading") val consentActorHeading: Heading?,
        @SerializedName("consent_actor_description") val consentActorDescription: Heading?,
        @SerializedName("data_principal_heading") val dataPrincipalHeading: Heading?,
        @SerializedName("data_principal_description") val dataPrincipalDescription: Heading?
    )

    data class ConsentCollectionSection(
        @SerializedName("show_check_all_checkbox") val showCheckAllCheckbox: Boolean?,
        @SerializedName("all_checkbox_text") val allCheckboxText: String?,
        @SerializedName("show_individual_checks") val showIndividualChecks: Boolean?,
        @SerializedName("heading") val heading: Heading?,
        @SerializedName("description") val description: Heading?,
        @SerializedName("processing_purpose_order") val processingPurposeOrder: List<Int>?,
        @SerializedName("enable_category_level_consent") val enableCategoryLevelConsent: Boolean?,
        @SerializedName("consent_input_type") val consentInputType: String?,
        @SerializedName("consent_input_position") val consentInputPosition: String?,
        @SerializedName("show_consent_input") val showConsentInput: Boolean?,
        @SerializedName("show_category_consent_input") val showCategoryConsentInput: Boolean?,
        @SerializedName("category_order") val categoryOrder: List<Int>?,
        @SerializedName("consent_order") val consentOrder: List<Int>?,
        @SerializedName("category_purpose_order") val categoryPurposeOrder: Map<String, Any>?,
        @SerializedName("category_consent_order") val categoryConsentOrder: Map<String, Any>?,
        @SerializedName("checkbox_border_radius") val checkboxBorderRadius: String?
    )

    data class ConfgForm(
        @SerializedName("logo") val logo: Logo?,
        @SerializedName("heading") val heading: Heading?,
        @SerializedName("description") val description: Heading?,
        @SerializedName("font_family") val fontFamily: String?,
        @SerializedName("color_scheme") val colorScheme: String?,
        @SerializedName("border_radius") val borderRadius: String?,
        @SerializedName("privacy_policy_url") val privacyPolicyUrl: String?,
        @SerializedName("show_privacy_policy_url") val showPrivacyPolicyUrl: Boolean?,
        @SerializedName("privacy_policy_url_text") val privacyPolicyUrlText: String?,
        @SerializedName("show_language") val showLanguage: Boolean?,
        @SerializedName("show_privacy_notice_before_consent") val showPrivacyNoticeBeforeConsent: Boolean?,
        @SerializedName("divider_opacity") val dividerOpacity: Any?,
        @SerializedName("language_dropdown") val languageDropDown: LanguageDropdown?,
        @SerializedName("spacing") val spacing: Spacing?,
        @SerializedName("illustration_image") val illustrationImage: IllustrationImage?,
        @SerializedName("background_color") val formBackgroundColor:  String?
    )

    data class IllustrationImage(
        @SerializedName("file_name") val fileName: String?,
        @SerializedName("illustration_image_url") val illustrationImageUrl: String?,
        @SerializedName("show_illustration_image") val showIllustrationImage: Boolean?,
        @SerializedName("width") val width: String?,
        @SerializedName("height") val height: String?
    )

    data class Spacing(
        @SerializedName("description") val description: String?,
        @SerializedName("footer") val footer: String?,
        @SerializedName("heading") val heading: String?,
        @SerializedName("pii_section") val piiSection: String?
    )

    data class LanguageDropdown(
        @SerializedName("background_color") val backgroundColor: String?,
        @SerializedName("border_radius") val borderRadius: String?,
        @SerializedName("shape") val shape: String?,
        @SerializedName("text_color") val textColor: String?
    )

    data class Logo(
        @SerializedName("show_logo") val showLogo: Boolean?,
        @SerializedName("logo_url") val logoUrl: String?,
        @SerializedName("width") val width: String?,
        @SerializedName("height") val height: String?,
        @SerializedName("opacity") val opacity: Any?
    )

    data class Heading(
        @SerializedName("text") val text: String?,
        @SerializedName("color") val color: String?,
        @SerializedName("size") val size: String?,
        @SerializedName("font_weight") val fontWeight: String?,
        @SerializedName("border_radius") val borderRadius: String?,
        @SerializedName("shape") val shape: String?
    )

    data class FormFooter(
        @SerializedName("heading") val heading: Heading?,
        @SerializedName("description") val description: Heading?
    )

    data class PiiList(
        @SerializedName("CONSENT_ACTOR") val consentActorPiiList: List<PiiLabel>?,
        @SerializedName("DATA_PRINCIPAL") val dataPrincipalPiiList: List<PiiLabel>?
    )

    data class PiiLabel(
        @SerializedName("pii_label_id") val id: Int?,
        @SerializedName("pii_label_name") val name: String?,
        @SerializedName("is_mandatory") val isMandatory: Boolean = false,
        @SerializedName("regex_pattern") val regEx: List<String>?,
        @SerializedName("principal_context") val principalContext: String?
    )

    data class CategoryList(
        @SerializedName("CONSENT_ACTOR") val consentActorCategoryList: List<Category>?,
        @SerializedName("DATA_PRINCIPAL") val dataPrincipalCategoryList: List<Category>?
    )

    data class Category(
        @SerializedName("processing_purpose_category_id") val processingPurposeCategoryId: Any?,
        @SerializedName("processing_purpose_category_name") val processingPurposeCategoryName: String?,
        @SerializedName("purpose_list") val purposeList: List<ProcessingPurpose>?,
        @SerializedName("visible") val visible: Boolean?
    )

    data class ProcessingPurpose(
        @SerializedName("processing_purpose_id") val id: Any?,
        @SerializedName("processing_purpose_name") val name: String?,
        @SerializedName("consent_bucket") val buckets: List<ConsentBucket>?,
        @SerializedName("visible") val visible: Boolean?
    )

    data class ConsentBucket(
        @SerializedName("consent_purpose_id") val consentPurposeId: Any?,
        @SerializedName("consent_purpose_name") val consentPurposeName: String?,
        @SerializedName("consent_purpose_description") val consentPurposeDescription: String?,
        @SerializedName("pii_labels") val piiLabels: List<String>?,
        @SerializedName("vendors") val vendors: List<Any>?,
        @SerializedName("processes") val processes: List<String>?,
        @SerializedName("ct_cp_map_bucket") val ctcpList: List<CtCpMap>?,
        @SerializedName("visible") val visible: Boolean?
    )

    data class CtCpMap(
        @SerializedName("id") val id: Any?,
        @SerializedName("pii_label_id") val piiLabelId: Any?,
        @SerializedName("pii_label") val piiLabel: String?,
        @SerializedName("compulsory_consent") val compulsoryConsent: Boolean?,
        @SerializedName("consent_status") var consentStatus: Boolean?,
        @SerializedName("default_opt_out_allowed") val defaultOptOutAllowed: Boolean?,
        @SerializedName("process_id") val processId: Any?,
        @SerializedName("process_name") val processName: String?,
        @SerializedName("manual_revoke_bool") val manualRevokeBool: Boolean?,
        @SerializedName("manual_grant_bool") val manualGrantBool: Boolean?,
        @SerializedName("vendor_id") val vendorId: Any?,
        @SerializedName("vendor_name") val vendorName: String?,
        @SerializedName("visible") val visible: Boolean?,
        @SerializedName("principal_context") val principalContext: String?,
        @SerializedName("consent_lifetime") val consentLifetime: Any?
    )
}
