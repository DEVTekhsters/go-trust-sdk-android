package com.tekhsters.gotrustsdkandroid.features.preferencecenter.services

import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.tekhsters.gotrustsdkandroid.features.consentform.models.CallBackResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.DecrypterApiResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.DigiLockerResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentAuditPageResult
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentRecord
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentTransaction
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.DashboardData
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.J
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.LoginConfig
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.SendOtpResponse
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.VerifyOtpResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class PreferenceCenterApiService private constructor() {

    private var baseUrl: String = ""
    private var api: PreferenceCenterApi? = null
    private val plainGson = Gson()

    // Whatever type the decryptor hands back (numeric or an opaque encrypted string) is kept as-is
    // and forwarded unchanged into later requests — coercing it to a fixed Int/String has broken
    // this before when the value turned out not to be numeric.
    var customerId: Any = "1"
        private set
    var preferenceFormId: Any = "1"
        private set
    private var subjectIdentityValues: List<Map<String, Any?>> = emptyList()
    private var publicToken: String? = null
    private var consentEvidenceToken: String? = null

    companion object {
        private const val TAG = "PreferenceCenterApiService"
        val instance: PreferenceCenterApiService by lazy { PreferenceCenterApiService() }
    }

    fun setBaseUrl(url: String) {
        if (baseUrl == url && api != null) return
        baseUrl = url

        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }
        val authInterceptor = Interceptor { chain ->
            val requestBuilder = chain.request().newBuilder()
            publicToken?.takeIf { it.isNotEmpty() }?.let { requestBuilder.header("x-public-token", it) }
            chain.proceed(requestBuilder.build())
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .addInterceptor(authInterceptor)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(plainGson))
            .build()

        api = retrofit.create(PreferenceCenterApi::class.java)
    }

    private fun extractPublicToken(body: JsonObject?): String? {
        if (body == null) return null
        body["token"]?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return it }
        val result = body.getAsJsonObject("result") ?: return null
        result["token"]?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return it }
        val data = result.get("data")
        if (data != null && data.isJsonObject) {
            data.asJsonObject["token"]?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return it }
        } else if (data != null && data.isJsonArray && data.asJsonArray.size() > 0) {
            val first = data.asJsonArray.first()
            if (first.isJsonObject) {
                first.asJsonObject["token"]?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return it }
            }
        }
        return null
    }

    suspend fun fetchLanguages(): List<Language> {
        return try {
            val response = api?.fetchLanguages(customerId = customerId, preferenceCenterId = preferenceFormId)
            if (response?.isSuccessful == true) {
                val body = response.body()
                val rawList = body?.getAsJsonObject("result")?.getAsJsonArray("data")
                val list = rawList?.mapNotNull {
                    if (it.isJsonObject) plainGson.fromJson(it, Language::class.java) else null
                }?.toMutableList() ?: mutableListOf()
                if (list.none { it.code == "en" }) {
                    list.add(0, Language(code = "en", name = "English"))
                }
                list
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchLanguages error", e)
            emptyList()
        }
    }

    suspend fun fetchLoginConfig(preferenceFormId: Any, customerId: Any, languageCode: String): LoginConfig? {
        return try {
            this.preferenceFormId = preferenceFormId
            this.customerId = customerId
            val response = api?.fetchLoginConfig(customerId = customerId, preferenceFormId = preferenceFormId, languageCode = languageCode)
            if (response?.isSuccessful == true) {
                response.body()?.let { LoginConfig.fromJson(it) }
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "fetchLoginConfig error", e)
            null
        }
    }

    suspend fun sendOtp(subjectIdentityValues: List<Map<String, Any?>>): SendOtpResponse? {
        return try {
            val payload = mapOf(
                "customer_id" to customerId,
                "preference_center_id" to preferenceFormId,
                "subject_identity_values" to subjectIdentityValues,
            )
            val response = api?.sendOtp(payload)
            if (response?.isSuccessful == true) response.body() else null
        } catch (e: Exception) {
            Log.e(TAG, "sendOtp error", e)
            null
        }
    }

    suspend fun verifyOtp(otp: String, subjectIdentityValues: List<Map<String, Any?>>): VerifyOtpResponse? {
        return try {
            val payload = mapOf(
                "customer_id" to customerId,
                "preference_center_id" to preferenceFormId,
                "otp" to otp,
                "subject_identity_values" to subjectIdentityValues,
            )
            val response = api?.verifyOtp(payload)
            if (response?.isSuccessful == true) {
                val body = response.body()
                body?.token?.takeIf { it.isNotEmpty() }?.let { publicToken = it }
                body
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "verifyOtp error", e)
            null
        }
    }

    suspend fun fetchDashboardData(subjectIdentityValues: List<Map<String, Any?>>, languageCode: String): DashboardData? {
        return try {
            this.subjectIdentityValues = subjectIdentityValues
            // The dashboard is reloaded whenever the language changes, and the evidence token is
            // language-specific. Clearing it here guarantees a stale token from the previous
            // language can never be silently reused if this response doesn't carry a fresh one.
            consentEvidenceToken = null
            val payload = mapOf(
                "customer_id" to customerId,
                "preference_center_id" to preferenceFormId,
                "subject_identity_values" to subjectIdentityValues,
                "language_code" to languageCode,
            )
            val response = api?.fetchDashboardData(payload)
            if (response?.isSuccessful == true) {
                val evidenceToken = response.headers()["x-consent-evidence-token"]
                // Two reloads (e.g. a rapid language switch, or a switch fired while the previous
                // one is still in flight) can have their responses arrive out of order. Checking
                // the token's own `language_code` claim against the language actually requested by
                // *this* call - rather than trusting whatever the header carries - stops a token
                // from an older, superseded reload from ever being cached over a newer one.
                consentEvidenceToken = evidenceToken
                response.body()?.getAsJsonObject("result")?.getAsJsonObject("data")?.let { DashboardData.fromJson(it) }
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "fetchDashboardData error", e)
            null
        }
    }

    /**
     * True unless the evidence JWT's own `language_code` claim can be read and it disagrees with
     * [expectedLanguageCode]. Tokens that can't be decoded (unexpected format) are let through
     * rather than dropped, so this only ever narrows caching, never blocks it outright.
     */
    private fun tokenLanguageMatches(token: String, expectedLanguageCode: String): Boolean {
        val claim = decodeJwtClaim(token, "language_code") ?: return true
        return claim == expectedLanguageCode
    }

    private fun decodeJwtClaim(token: String, claim: String): String? {
        return try {
            val parts = token.split(".")
            if (parts.size < 2) return null
            val payloadBytes = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val json = plainGson.fromJson(String(payloadBytes, Charsets.UTF_8), JsonObject::class.java)
            json?.get(claim)?.takeIf { it.isJsonPrimitive }?.asString
        } catch (e: Exception) {
            null
        }
    }

    suspend fun saveDashboardPreferences(payload: MutableMap<String, Any?>): SaveOutcome = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(0, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.SECONDS)
                .build()

            var ip = "127.0.0.1"
            try {
                client.newCall(okhttp3.Request.Builder().url("https://api.ipify.org?format=json").build()).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = plainGson.fromJson(resp.body?.string(), Map::class.java)
                        ip = json["ip"] as? String ?: "127.0.0.1"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get IP", e)
            }

            var countryCode = "IN"
            var continent = "ASIA"
            try {
                client.newCall(okhttp3.Request.Builder().url("https://ipapi.co/$ip/json").build()).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = plainGson.fromJson(resp.body?.string(), Map::class.java)
                        countryCode = json["country"] as? String ?: "IN"
                        continent = json["continent_code"] as? String ?: "ASIA"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get Geo", e)
            }

            payload["geolocation"] = "$ip($countryCode)"
            payload["continent"] = continent

            val response = api?.saveDashboardPreferences(consentEvidenceToken, payload)
                ?: return@withContext SaveOutcome(
                    success = false,
                    statusCode = null,
                    message = "Preference center service is not initialised",
                )

            // 201 is what a stored record answers with; anything else is a failure whose reason
            // sits in the response body, so it is carried through to the host's onError.
            val bodyJson = if (response.isSuccessful) {
                response.body()
            } else {
                try {
                    response.errorBody()?.string()
                        ?.takeIf { it.isNotBlank() }
                        ?.let { plainGson.fromJson(it, JsonObject::class.java) }
                } catch (e: Exception) {
                    Log.e(TAG, "saveDashboardPreferences: unreadable error body", e)
                    null
                }
            }
            SaveOutcome(
                success = response.code() == 201,
                statusCode = J.int(bodyJson, "status_code") ?: response.code(),
                message = J.str(bodyJson, "message")?.takeIf { it.isNotBlank() },
            )
        } catch (e: Exception) {
            Log.e(TAG, "saveDashboardPreferences error", e)
            SaveOutcome(
                success = false,
                statusCode = null,
                message = e.message ?: e::class.java.simpleName,
            )
        }
    }

    suspend fun getCustomerAndPreferenceId(customerId: String?, pfId: String?, pfToken: String?, token: String? = null): DecrypterApiResponse? {
        return try {
            // token wins over pfToken when both are supplied (minor flow); pfToken alone still
            // drives the decryptor when no token is present.
            val resolvedToken = if (!token.isNullOrEmpty()) token else pfToken
            val data = if (!resolvedToken.isNullOrEmpty()) {
                mapOf("token" to resolvedToken)
            } else {
                mapOf("customer_id" to customerId, "pf_id" to pfId)
            }
            val response = api?.getCustomerAndPreferenceId(mapOf("data" to data))
            if (response?.isSuccessful == true) {
                val body = response.body()
                body?.result?.data?.token?.takeIf { it.isNotEmpty() }?.let { publicToken = it }
                body
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getCustomerAndPreferenceId error", e)
            null
        }
    }

    suspend fun getDigiLockerResponse(pfToken: String): DigiLockerResponse? {
        return try {
            val prefUrl = "$baseUrl/public/pf?token=$pfToken"
            val response = api?.getDigiLockerResponse(prefUrl)
            if (response?.isSuccessful == true) response.body() else null
        } catch (e: Exception) {
            Log.e(TAG, "getDigiLockerResponse error", e)
            null
        }
    }

    suspend fun getCallbackApiResponse(code: String, state: String): CallBackResponse? {
        return try {
            val response = api?.getCallbackApiResponse(code, state)
            if (response?.isSuccessful == true) {
                val body = response.body()
                body?.result?.data?.token?.takeIf { it.isNotEmpty() }?.let { publicToken = it }
                body
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getCallbackApiResponse error", e)
            null
        }
    }

    suspend fun getConsentFlow(): List<ConsentRecord> {
        return try {
            val payload = mapOf(
                "customer_id" to customerId.toString(),
                "preference_center_id" to preferenceFormId.toString(),
                "subject_identity_values" to subjectIdentityValues,
            )
            val response = api?.getConsentFlow(payload)
            if (response?.isSuccessful == true) {
                val records = response.body()
                    ?.getAsJsonObject("result")
                    ?.getAsJsonObject("data")
                    ?.getAsJsonArray("consent_records")
                records?.mapNotNull { if (it.isJsonObject) ConsentRecord.fromJson(it.asJsonObject) else null } ?: emptyList()
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "getConsentFlow error", e)
            emptyList()
        }
    }

    suspend fun fetchConsentAuditLogs(dataPrincipalId: Int, page: Int): ConsentAuditPageResult? {
        return try {
            val response = api?.fetchConsentAuditLogs(
                customerId = customerId,
                dataPrincipalId = dataPrincipalId,
                pageNumber = page,
            )
            if (response?.isSuccessful == true) {
                val result = response.body()?.getAsJsonObject("result")
                val total = result?.get("count")?.takeIf { it.isJsonPrimitive }?.asInt
                val items = result?.getAsJsonArray("data")
                    ?.mapNotNull { if (it.isJsonObject) ConsentTransaction.fromJson(it.asJsonObject) else null }
                    ?: emptyList()
                ConsentAuditPageResult(items = items, totalCount = total)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchConsentAuditLogs error", e)
            null
        }
    }
}

/**
 * Outcome of a preference save. The backend's own [statusCode] and [message] are kept so a
 * rejected save can tell the host app what actually went wrong instead of a fixed string.
 */
data class SaveOutcome(
    val success: Boolean,
    val statusCode: Int?,
    val message: String?,
)
