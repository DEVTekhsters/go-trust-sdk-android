package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class SaveConsentResponse(
    @SerializedName("success") val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("result") val result: SaveConsentResult?
) {
    data class SaveConsentResult(
        @SerializedName("data") val data: List<SaveConsentRecord>?,
        @SerializedName("count") val count: Int?
    )

    data class SaveConsentRecord(
        @SerializedName("id") val id: Int?
    )
}
