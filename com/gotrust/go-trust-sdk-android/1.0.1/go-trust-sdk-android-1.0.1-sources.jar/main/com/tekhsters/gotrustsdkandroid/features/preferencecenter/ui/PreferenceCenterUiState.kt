package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

sealed class PreferenceCenterUiState {
    object Loading : PreferenceCenterUiState()
    object Login : PreferenceCenterUiState()
    object Otp : PreferenceCenterUiState()
    object Dashboard : PreferenceCenterUiState()
    data class DigiLockerVerification(val url: String) : PreferenceCenterUiState()
    data class MinorVerificationFailed(val message: String) : PreferenceCenterUiState()
    object ConsentNotGiven : PreferenceCenterUiState()
    data class Error(val message: String) : PreferenceCenterUiState()
}

/** One-shot request to hand off to the existing consent-form flow when a subject isn't found yet. */
data class ConsentFormLaunchRequest(
    val sourceId: String,
    val initialSubjectValues: Map<String, Any>,
    val additionalParams: Map<String, Any>,
    val initialLanguage: String,
    val baseUrl: String,
    val enableCaptcha: Boolean,
)
