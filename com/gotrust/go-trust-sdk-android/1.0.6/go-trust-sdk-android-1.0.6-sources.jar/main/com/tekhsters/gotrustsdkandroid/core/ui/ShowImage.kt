package com.tekhsters.gotrustsdkandroid.core.ui

import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.parsePxToDp


@Composable
fun ShowImage(
    iconObjectKey: String?,
    iconWidth: String? = "100",
    iconHeight: String? = "35",
    getImageUrl: suspend (String?) -> String?,
    alignment: Alignment = Alignment.CenterStart,
    modifier: Modifier = Modifier

) {
    // isNullOrEmpty, not just null: ConsentFormScreen gates only on showLogo, so an empty
    // configured value would otherwise fire a pointless download (or, with
    // logoShownThroughBaseUrl on, resolve to a bare baseUrl).
    if (iconObjectKey.isNullOrEmpty()) return

    var resolvedUrl by remember(iconObjectKey) { mutableStateOf<String?>(null) }

    LaunchedEffect(iconObjectKey) {
        resolvedUrl = getImageUrl(iconObjectKey)
    }

    if (resolvedUrl != null) {
        AsyncImage(
            model = resolvedUrl,
            imageLoader = rememberLogoImageLoader(),
            contentDescription = "Image",
            modifier = modifier
                .width(parsePxToDp(iconWidth, fallback = 24f))
                .height(parsePxToDp(iconHeight, fallback = 24f)),
            alignment = alignment,
            contentScale = ContentScale.Fit
        )
    }
}