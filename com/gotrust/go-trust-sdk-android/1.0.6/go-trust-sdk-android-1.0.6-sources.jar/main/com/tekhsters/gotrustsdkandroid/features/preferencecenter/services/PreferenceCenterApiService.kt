package com.tekhsters.gotrustsdkandroid.features.preferencecenter.services

import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.tekhsters.gotrustsdkandroid.core.utils.CryptoException
import com.tekhsters.gotrustsdkandroid.core.utils.CryptoManager
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.CallBackResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.GsonProvider
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.*
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language
import com.tekhsters.gotrustsdkandroid.features.consentform.models.DecrypterApiResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.DigiLockerResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.security.PublicKey
import java.util.Arrays
import java.util.UUID
import java.util.concurrent.TimeUnit

class PreferenceCenterApiService private constructor() {

    private var baseUrl: String = ""
    private var api: PreferenceCenterApi? = null
    private val plainGson = Gson()

    @Volatile
    private var currentSessionAesKey: ByteArray? = null
    @Volatile
    private var currentSessionId: String? = null
    private val cryptoSessionMutex = Mutex()
    private var sessionVersion: Int = 1

    private var authToken: String? = null

    @Volatile
    private var latestPlaintextErrorBody: String? = null

    @Volatile
    private var latestPlaintextErrorCode: Int? = null

    @Volatile
    private var latestCryptoError: Throwable? = null

    // Whatever type the decryptor hands back (numeric or an opaque encrypted string) is kept as-is
    // and forwarded unchanged into later requests — coercing it to a fixed Int/String has broken
    // this before when the value turned out not to be numeric.
    var customerId: Any = "1"
        private set
    var preferenceFormId: Any = "1"
        private set
    private var subjectIdentityValues: List<Map<String, Any?>> = emptyList()
    private var publicToken: String? = null
    private var consentEvidenceToken: String? = null

    companion object {
        private const val TAG = "PreferenceCenterApiService"
        val instance: PreferenceCenterApiService by lazy { PreferenceCenterApiService() }
    }

    fun setAuthToken(token: String?) {
        this.authToken = token
    }

    /** See `ApiService.logoShownThroughBaseUrl` — the preference centre has its own singleton. */
    private var logoShownThroughBaseUrl = false

    fun setLogoShownThroughBaseUrl(enabled: Boolean) {
        logoShownThroughBaseUrl = enabled
    }

    /** See `ApiService.resolveImageUrl`. */
    suspend fun resolveImageUrl(objectKey: String): String? =
        // Checked before the flag: a value that is already an absolute url (a host-supplied
        // headerLogo, or a config that stores full urls) is rendered as-is and must never get
        // baseUrl prefixed onto it or be sent to the download api.
        if (objectKey.startsWith("http://") || objectKey.startsWith("https://")) {
            objectKey
        } else if (logoShownThroughBaseUrl) {
            baseUrl.trimEnd('/') + "/" + objectKey.trimStart('/')
        } else {
            fetchImageUrl(objectKey)?.result?.downloadUrl
        }

    fun setBaseUrl(url: String) {
        if (baseUrl == url && api != null) return
        baseUrl = url
        currentSessionAesKey = null
        currentSessionId = null

        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }
        val authInterceptor = Interceptor { chain ->
            val requestBuilder = chain.request().newBuilder()
            publicToken?.takeIf { it.isNotEmpty() }?.let {
                requestBuilder.header("x-public-token", it)
            }
            authToken?.takeIf { it.isNotEmpty() }?.let {
                Log.d("AUTH_TOKEN", "Adding Authorization : $it")
                requestBuilder.header("Authorization", "Bearer $it")
            }
            chain.proceed(requestBuilder.build())
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .addInterceptor(authInterceptor)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(plainGson))
            .build()

        api = retrofit.create(PreferenceCenterApi::class.java)
    }

    private suspend fun ensureSessionAesKey(): Boolean {
        if (currentSessionAesKey != null && !currentSessionId.isNullOrEmpty()) return true
        return cryptoSessionMutex.withLock {
            if (currentSessionAesKey != null && !currentSessionId.isNullOrEmpty()) return true
            try {
                val keyPair = CryptoManager.getOrCreateRsaKeyPair()
                val androidPublicKeyPem = CryptoManager.exportPublicKeyToPem(keyPair.public)
                val req = PublicKeyRequest(publicKey = androidPublicKeyPem)
                val response = api?.getPublicKey(req)
                if (response?.isSuccessful == true) {
                    val body = response.body()
                    val encryptedKeyStr = body?.encrypted_key
                    if (!encryptedKeyStr.isNullOrEmpty()) {
                        val encryptedKeyBytes = CryptoManager.Base64Url.decode(encryptedKeyStr)
                        val aes1KeyBytes = CryptoManager.decryptRsaOaep256(
                            privateKey = keyPair.private,
                            encryptedBytes = encryptedKeyBytes
                        )
                        sessionVersion = body.version ?: 1
                        currentSessionId = body.session_id ?: UUID.randomUUID().toString()
                        currentSessionAesKey = aes1KeyBytes
                        true
                    } else false
                } else false
            } catch (e: Exception) {
                Log.e(TAG, "Failed during session key exchange with GoTrust", e)
                false
            }
        }
    }

    private suspend fun resetSession() {
        cryptoSessionMutex.withLock {
            currentSessionAesKey = null
            currentSessionId = null
        }
    }

    private suspend inline fun <reified Req, reified Res> executeEncryptedRequest(
        payload: Req,
        backendPath: String,
        crossinline apiCall: suspend (
            EncryptedRequestEnvelope
        ) -> retrofit2.Response<ResponseBody>
    ): Res? {

        latestCryptoError = null
        latestPlaintextErrorCode = null
        latestPlaintextErrorBody = null

        if (!ensureSessionAesKey()) {
            return null
        }

        val activeAesKey = cryptoSessionMutex.withLock {
            val key = currentSessionAesKey
            currentSessionAesKey = null
            key
        } ?: run {
            Log.e(TAG, "Session AES key unexpectedly null")
            return null
        }

        val iv = CryptoManager.generateRequestIv()

        try {
            val sessionId = currentSessionId ?: run {
                Log.e(TAG, "Session ID unexpectedly null")
                resetSession()
                return null
            }
            val timestamp = System.currentTimeMillis() / 1000

            val jsonPayload = GsonProvider.gson.toJson(payload)
            val payloadBytes = jsonPayload.toByteArray(Charsets.UTF_8)

            val requestAad = CryptoManager.buildAad(
                version = sessionVersion,
                sessionId = sessionId,
                timestamp = timestamp,
                httpMethod = "POST",
                backendPath = backendPath,
                direction = "request",
                requestTag = ""
            )

            val (ciphertextBytes, tagBytes) = CryptoManager.encryptAesGcm(
                aesKey = activeAesKey,
                iv = iv,
                aad = requestAad,
                plainText = payloadBytes
            )

            val envelope = EncryptedRequestEnvelope(
                version = sessionVersion,
                session_id = sessionId,
                timestamp = timestamp,
                iv = CryptoManager.Base64Url.encode(iv),
                ciphertext = CryptoManager.Base64Url.encode(ciphertextBytes),
                tag = CryptoManager.Base64Url.encode(tagBytes)
            )

            val response = apiCall(envelope)
            val responseBody = response.body()?.string()

            latestPlaintextErrorCode = response.code()

            response.headers()["x-consent-evidence-token"]?.let {
                if (it.isNotEmpty()) {
                    consentEvidenceToken = it
                }
            }

            response.headers()["x-public-token"]?.let {
                if (it.isNotEmpty()) {
                    publicToken = it
                }
            }

            if (!response.isSuccessful) {
                resetSession()
                latestPlaintextErrorCode = response.code()
                latestPlaintextErrorBody = response.errorBody()?.string() ?: responseBody
                return null
            }

            if (responseBody.isNullOrEmpty()) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Successful response had an empty body")
                )
                return null
            }

            val responseEnvelope = try {
                GsonProvider.gson.fromJson(
                    responseBody,
                    EncryptedResponseEnvelope::class.java
                )
            } catch (e: Exception) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(e)
                Log.e(TAG, "Invalid encrypted response envelope", e)
                return null
            }

            if (responseEnvelope == null) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Response envelope is null")
                )
                return null
            }

            val resIvStr = responseEnvelope.iv
            val resCiphertextStr = responseEnvelope.ciphertext
            val resTagStr = responseEnvelope.tag
            val nextEncryptedKeyStr = responseEnvelope.encrypted_key

            if (resIvStr.isNullOrEmpty() || resCiphertextStr.isNullOrEmpty() || resTagStr.isNullOrEmpty() || nextEncryptedKeyStr.isNullOrEmpty()) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Response missing iv/ciphertext/tag/encrypted_key")
                )
                Log.e(TAG, "Security Alert: encrypted response missing fields")
                return null
            }

            val responseSessionId = responseEnvelope.session_id
            if (responseSessionId != null && responseSessionId != sessionId) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Response session_id mismatch")
                )
                Log.e(TAG, "Security Alert: session_id mismatch")
                return null
            }

            val resIv = CryptoManager.Base64Url.decode(resIvStr)
            val resCiphertext = CryptoManager.Base64Url.decode(resCiphertextStr)
            val resTag = CryptoManager.Base64Url.decode(resTagStr)

            if (resIv.isEmpty() || resIv[0] != CryptoManager.RESPONSE_NONCE_PREFIX) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Invalid response nonce prefix")
                )
                Log.e(TAG, "Security Alert: response nonce prefix invalid")
                return null
            }

            val keyPair = CryptoManager.getOrCreateRsaKeyPair()
            val nextEncryptedKeyBytes = CryptoManager.Base64Url.decode(nextEncryptedKeyStr)
            val nextAesKeyBytes = try {
                CryptoManager.decryptRsaOaep256(
                    privateKey = keyPair.private,
                    encryptedBytes = nextEncryptedKeyBytes
                )
            } catch (e: Exception) {
                resetSession()
                latestCryptoError = CryptoException.RsaFailure(e)
                Log.e(TAG, "Failed to decrypt next session AES key from response envelope", e)
                return null
            }

            val responseTimestamp = responseEnvelope.timestamp ?: timestamp
            val responseAad = CryptoManager.buildAad(
                version = sessionVersion,
                sessionId = sessionId,
                timestamp = responseTimestamp,
                httpMethod = "POST",
                backendPath = backendPath,
                direction = "response",
                requestTag = envelope.tag
            )

            val decryptedBytes = try {
                CryptoManager.decryptAesGcm(
                    aesKey = nextAesKeyBytes,
                    iv = resIv,
                    aad = responseAad,
                    ciphertext = resCiphertext,
                    tag = resTag
                )
            } catch (e: Exception) {
                resetSession()
                latestCryptoError = if (e is CryptoException) e else CryptoException.AesFailure(e)
                Log.e(TAG, "Failed to decrypt response payload", e)
                return null
            }

            cryptoSessionMutex.withLock {
                currentSessionAesKey = nextAesKeyBytes
                currentSessionId = responseSessionId ?: sessionId
            }

            return GsonProvider.gson.fromJson(
                String(decryptedBytes, Charsets.UTF_8),
                Res::class.java
            )

        } catch (e: CryptoException) {
            resetSession()
            latestCryptoError = e
            Log.e(TAG, "Encrypted API request failed - crypto error", e)
            return null
        } catch (e: Exception) {
            resetSession()
            latestCryptoError = e
            Log.e(TAG, "Encrypted API request failed", e)
            return null
        } finally {
            java.util.Arrays.fill(activeAesKey, 0.toByte())
        }
    }

    private fun extractPublicToken(body: JsonObject?): String? {
        if (body == null) return null
        body["token"]?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return it }
        val result = body.getAsJsonObject("result") ?: return null
        result["token"]?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return it }
        val data = result.get("data")
        if (data != null && data.isJsonObject) {
            data.asJsonObject["token"]?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return it }
        } else if (data != null && data.isJsonArray && data.asJsonArray.size() > 0) {
            val first = data.asJsonArray.first()
            if (first.isJsonObject) {
                first.asJsonObject["token"]?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return it }
            }
        }
        return null
    }

    suspend fun fetchLanguages(): List<Language> {
        return try {
            val payload = LanguageRequestBody(
                customerId = customerId,
                preferenceCenterId = preferenceFormId,
            )

            val body = executeEncryptedRequest<LanguageRequestBody, JsonObject>(
                payload,
                "/public/api/v4/translator/language-codes"
            ) { envelope ->
                api!!.fetchLanguages(envelope)
            }

            val rawList = body?.getAsJsonObject("result")?.getAsJsonArray("data")
            val list = rawList?.mapNotNull {
                if (it.isJsonObject) plainGson.fromJson(it, Language::class.java) else null
            }?.toMutableList() ?: mutableListOf()
            if (list.none { it.code == "en" }) {
                list.add(0, Language(code = "en", name = "English"))
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "fetchLanguages error", e)
            emptyList()
        }
    }

    suspend fun fetchLoginConfig(preferenceFormId: Any, customerId: Any, languageCode: String): LoginConfig? {
        return try {
            this.preferenceFormId = preferenceFormId
            this.customerId = customerId
            val payload = LoginConfigRequest(
                customerId = customerId,
                preferenceFormId = preferenceFormId,
                languageCode = languageCode
            )
            val body = executeEncryptedRequest<LoginConfigRequest, JsonObject>(
                payload,
                "/public/api/v2/pc/identity/ask"
            ) { envelope ->
                api!!.fetchLoginConfig(envelope)
            }
            body?.let { LoginConfig.fromJson(it) }
        } catch (e: Exception) {
            Log.e(TAG, "fetchLoginConfig error", e)
            null
        }
    }

    suspend fun sendOtp(subjectIdentityValues: List<Map<String, Any?>>): SendOtpResponse? {
        return try {
            val payload = mapOf(
                "customer_id" to customerId,
                "preference_center_id" to preferenceFormId,
                "subject_identity_values" to subjectIdentityValues,
            )
            executeEncryptedRequest<Map<String, Any?>, SendOtpResponse>(
                payload,
                "/public/api/v5/pc/otp/send"
            ) { envelope ->
                api!!.sendOtp(envelope)
            }
        } catch (e: Exception) {
            Log.e(TAG, "sendOtp error", e)
            null
        }
    }

    suspend fun verifyOtp(otp: String, subjectIdentityValues: List<Map<String, Any?>>): VerifyOtpResponse? {
        return try {
            val payload = mapOf(
                "customer_id" to customerId,
                "preference_center_id" to preferenceFormId,
                "otp" to otp,
                "subject_identity_values" to subjectIdentityValues,
            )
            val body = executeEncryptedRequest<Map<String, Any?>, VerifyOtpResponse>(
                payload,
                "/public/api/v5/pc/otp/verify"
            ) { envelope ->
                api!!.verifyOtp(envelope)
            }
            body?.token?.takeIf { it.isNotEmpty() }?.let { publicToken = it }
            body
        } catch (e: Exception) {
            Log.e(TAG, "verifyOtp error", e)
            null
        }
    }

    suspend fun fetchDashboardData(subjectIdentityValues: List<Map<String, Any?>>, languageCode: String): DashboardData? {
        return try {
            this.subjectIdentityValues = subjectIdentityValues
            consentEvidenceToken = null
            val payload = mapOf(
                "customer_id" to customerId,
                "preference_center_id" to preferenceFormId,
                "subject_identity_values" to subjectIdentityValues,
                "language_code" to languageCode,
            )
            executeEncryptedRequest<Map<String, Any?>, JsonObject>(
                payload,
                "/public/api/v7/pc/display"
            ) { envelope ->
                api!!.fetchDashboardData(envelope)
            }?.getAsJsonObject("result")?.getAsJsonObject("data")?.let { DashboardData.fromJson(it) }
        } catch (e: Exception) {
            Log.e(TAG, "fetchDashboardData error", e)
            null
        }
    }

    /**
     * True unless the evidence JWT's own `language_code` claim can be read and it disagrees with
     * [expectedLanguageCode]. Tokens that can't be decoded (unexpected format) are let through
     * rather than dropped, so this only ever narrows caching, never blocks it outright.
     */
    private fun tokenLanguageMatches(token: String, expectedLanguageCode: String): Boolean {
        val claim = decodeJwtClaim(token, "language_code") ?: return true
        return claim == expectedLanguageCode
    }

    private fun decodeJwtClaim(token: String, claim: String): String? {
        return try {
            val parts = token.split(".")
            if (parts.size < 2) return null
            val payloadBytes = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val json = plainGson.fromJson(String(payloadBytes, Charsets.UTF_8), JsonObject::class.java)
            json?.get(claim)?.takeIf { it.isJsonPrimitive }?.asString
        } catch (e: Exception) {
            null
        }
    }

    suspend fun saveDashboardPreferences(payload: MutableMap<String, Any?>): SaveOutcome = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(0, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.SECONDS)
                .build()

            var ip = "127.0.0.1"
            try {
                client.newCall(okhttp3.Request.Builder().url("https://api.ipify.org?format=json").build()).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = plainGson.fromJson(resp.body?.string(), Map::class.java)
                        ip = json["ip"] as? String ?: "127.0.0.1"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get IP", e)
            }

            var countryCode = "IN"
            var continent = "ASIA"
            try {
                client.newCall(okhttp3.Request.Builder().url("https://ipapi.co/$ip/json").build()).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = plainGson.fromJson(resp.body?.string(), Map::class.java)
                        countryCode = json["country"] as? String ?: "IN"
                        continent = json["continent_code"] as? String ?: "ASIA"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get Geo", e)
            }

            payload["geolocation"] = "$ip($countryCode)"
            payload["continent"] = continent

            val bodyJson = executeEncryptedRequest<Map<String, Any?>, JsonObject>(
                payload,
                "/public/api/v4/data-collector/pc-records"
            ) { envelope ->
                api!!.saveDashboardPreferences(consentEvidenceToken, envelope)
            }

            val statusCode = latestPlaintextErrorCode ?: 201
            SaveOutcome(
                success = statusCode == 201,
                statusCode = J.int(bodyJson, "status_code") ?: statusCode,
                message = J.str(bodyJson, "message")?.takeIf { it.isNotBlank() } ?: latestPlaintextErrorBody,
            )
        } catch (e: Exception) {
            Log.e(TAG, "saveDashboardPreferences error", e)
            SaveOutcome(
                success = false,
                statusCode = null,
                message = e.message ?: e::class.java.simpleName,
            )
        }
    }

    suspend fun getCustomerAndPreferenceId(customerId: String?, pfId: String?, pfToken: String?, token: String? = null): DecrypterApiResponse? {
        return try {
            val resolvedToken = if (!token.isNullOrEmpty()) token else pfToken
            val data = if (!resolvedToken.isNullOrEmpty()) {
                mapOf("token" to resolvedToken)
            } else {
                mapOf("customer_id" to customerId, "pf_id" to pfId)
            }
            val body = executeEncryptedRequest<Map<String, Any?>, DecrypterApiResponse>(
                mapOf("data" to data),
                "/public/api/v3/security/entrypoint"
            ) { envelope ->
                api!!.getCustomerAndPreferenceId(envelope)
            }
            body?.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }
            body
        } catch (e: Exception) {
            Log.e(TAG, "getCustomerAndPreferenceId error", e)
            null
        }
    }

    suspend fun getDigiLockerResponse(pfToken: String): DigiLockerResponse? {
        return try {
            val prefUrl = "$baseUrl/public/pf?token=$pfToken"
            val payload = DigiLockerLoginRequest(redirectUri = prefUrl)
            executeEncryptedRequest<DigiLockerLoginRequest, DigiLockerResponse>(
                payload,
                "/public/api/v4/digilocker/login"
            ) { envelope ->
                api!!.getDigiLockerResponse(envelope)
            }
        } catch (e: Exception) {
            Log.e(TAG, "getDigiLockerResponse error", e)
            null
        }
    }

    suspend fun getCallbackApiResponse(code: String, state: String): CallBackResponse? {
        return try {
            val payload = DigiLockerCallbackRequest(code = code, state = state)
            val body = executeEncryptedRequest<DigiLockerCallbackRequest, CallBackResponse>(
                payload,
                "/public/api/v4/digilocker/callback"
            ) { envelope ->
                api!!.getCallbackApiResponse(envelope)
            }
            body?.result?.data?.token?.takeIf { it.isNotEmpty() }?.let { publicToken = it }
            body
        } catch (e: Exception) {
            Log.e(TAG, "getCallbackApiResponse error", e)
            null
        }
    }

    suspend fun getConsentFlow(): List<ConsentRecord> {
        return try {
            val payload = mapOf(
                "customer_id" to customerId.toString(),
                "preference_center_id" to preferenceFormId.toString(),
                "subject_identity_values" to subjectIdentityValues,
            )

            Log.d("payload of flow log"," ${payload}")
            val body = executeEncryptedRequest<Map<String, Any?>, JsonObject>(
                payload,
                "/public/api/v5/subject-consent-manager/consent-info/graph"
            ) { envelope ->
                api!!.getConsentFlow(envelope)
            }
            val records = body?.getAsJsonObject("result")
                ?.getAsJsonObject("data")
                ?.getAsJsonArray("consent_records")
            records?.mapNotNull { if (it.isJsonObject) ConsentRecord.fromJson(it.asJsonObject) else null } ?: emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "getConsentFlow error", e)
            emptyList()
        }
    }

    suspend fun fetchConsentAuditLogs(dataPrincipalId: Int, page: Int): ConsentAuditPageResult? {
        return try {
            val payload = ConsentAuditLogsRequest(
                customerId = customerId ,
                dataPrincipalId = dataPrincipalId.toString(),
                pageNumber = page
            )

            Log.d("payload of audit log"," ${payload}")
            val body = executeEncryptedRequest<ConsentAuditLogsRequest, JsonObject>(
                payload,
                "/public/api/v5/subject-consent-manager/consent-info/per-principals"
            ) { envelope ->
                api!!.fetchConsentAuditLogs(envelope)
            }
            val result = body?.getAsJsonObject("result")
            val total = result?.get("count")?.takeIf { it.isJsonPrimitive }?.asInt
            val items = result?.getAsJsonArray("data")
                ?.mapNotNull { if (it.isJsonObject) ConsentTransaction.fromJson(it.asJsonObject) else null }
                ?: emptyList()
            ConsentAuditPageResult(items = items, totalCount = total)
        } catch (e: Exception) {
            Log.e(TAG, "fetchConsentAuditLogs error", e)
            null
        }
    }

     // this function is for calling the image download Api and get the response

    suspend fun fetchImageUrl(iconUrl: String?): ImageDownloadResponse? {
        return try {
            val payload = mapOf("objectKey" to iconUrl)
            val response = api?.fetchImageUrl(payload)
            if(response?.isSuccessful == true){
                val body = response.body()
                body
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchImageUrl error", e)
            null
        }
    }
}

/**
 * Outcome of a preference save. The backend's own [statusCode] and [message] are kept so a
 * rejected save can tell the host app what actually went wrong instead of a fixed string.
 */
data class SaveOutcome(
    val success: Boolean,
    val statusCode: Int?,
    val message: String?,
)
