package com.tekhsters.gotrustsdkandroid.core.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import coil.ImageLoader
import coil.decode.SvgDecoder

/**
 * Coil loader for tenant logos and icons. Coil's default loader cannot decode SVG, so a tenant
 * serving `/assets/svg/logo.svg` rendered nothing at all; [SvgDecoder] only engages when the
 * response actually sniffs as SVG, so raster logos go down the usual path untouched and no
 * per-url extension check is needed.
 */
@Composable
fun rememberLogoImageLoader(): ImageLoader {
    val context = LocalContext.current
    return remember(context) {
        ImageLoader.Builder(context)
            .components { add(SvgDecoder.Factory()) }
            .build()
    }
}
