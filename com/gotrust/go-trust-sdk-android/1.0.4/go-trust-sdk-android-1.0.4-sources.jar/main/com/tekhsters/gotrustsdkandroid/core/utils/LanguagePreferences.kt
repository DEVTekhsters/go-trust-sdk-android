package com.tekhsters.gotrustsdkandroid.core.utils

import android.content.Context
import android.content.SharedPreferences

/**
 * Persists the language the user picked from the in-form language selector, separated into
 * independent keys for the consent form and preference center so they do not influence each other.
 *
 * Both modules start from their own persisted language choice unless the caller explicitly
 * requested one (by passing an `initialLanguage` other than 'en').
 */
object LanguagePreferences {

    private const val PREFS_NAME = "go_trust_sdk_prefs"
    private const val KEY_LANGUAGE_CODE_CONSENT = "language_code_consent"
    private const val KEY_LANGUAGE_CODE_PREF = "language_code_pref"
    private const val DEFAULT_LANGUAGE = "en"

    /** Holds application context only — never an Activity — so the singleton cannot leak a screen. */
    @Volatile
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            synchronized(this) {
                if (prefs == null) {
                    prefs = context.applicationContext
                        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                }
            }
        }
    }

    private fun read(key: String, default: String = DEFAULT_LANGUAGE): String =
        prefs?.getString(key, null)?.takeIf { it.isNotBlank() } ?: default

    private fun write(key: String, code: String) {
        if (code.isBlank()) return
        prefs?.edit()?.putString(key, code)?.apply()
    }
    // this id used for the consent form
    fun readConsent(default: String = DEFAULT_LANGUAGE): String = read(KEY_LANGUAGE_CODE_CONSENT, default)
    fun writeConsent(code: String) = write(KEY_LANGUAGE_CODE_CONSENT, code)

    //this is used for the preference form
    fun readPref(default: String = DEFAULT_LANGUAGE): String = read(KEY_LANGUAGE_CODE_PREF, default)
    fun writePref(code: String) = write(KEY_LANGUAGE_CODE_PREF, code)

    /**
     * Resolves the language a preference-center screen should start in: the persisted choice when
     * the caller did not ask for a specific one, otherwise the caller's request
     * .
     */
    fun resolveInitial(requested: String): String =
        if (requested == DEFAULT_LANGUAGE) readPref(DEFAULT_LANGUAGE) else requested
}
