package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tekhsters.gotrustsdkandroid.core.utils.HtmlText
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node

sealed interface HtmlBlock {
    data class Content(val html: String) : HtmlBlock
    data class Table(
        val headerRows: List<List<String>>,
        val bodyRows: List<List<String>>
    ) : HtmlBlock {
        val columnCount: Int
            get() = (headerRows + bodyRows).maxOfOrNull { it.size } ?: 0
    }
}

fun parseHtmlBlocks(html: String): List<HtmlBlock> {
    val body = Jsoup.parseBodyFragment(html).body()
    val blocks = mutableListOf<HtmlBlock>()
    val buffer = StringBuilder()

    fun flush() {
        if (buffer.isNotBlank()) blocks.add(HtmlBlock.Content(buffer.toString()))
        buffer.clear()
    }

    fun walk(node: Node) {
        if (node is Element && node.tagName() == "table") {
            flush()
            blocks.add(parseTable(node))
        } else if (node is Element && node.selectFirst("table") != null) {
            // wrapper (div/section/etc.) containing a table -> look inside it
            node.childNodes().forEach { walk(it) }
        } else {
            buffer.append(node.outerHtml())
        }
    }

    body.childNodes().forEach { walk(it) }
    flush()
    return blocks
}

private fun parseTable(table: Element): HtmlBlock.Table {
    val headerRows = mutableListOf<List<String>>()
    val bodyRows = mutableListOf<List<String>>()

    table.select("tr").forEach { tr ->
        if (tr.closest("table") != table) return@forEach // skip nested tables

        val cells = tr.children().filter { it.tagName() == "th" || it.tagName() == "td" }
        if (cells.isEmpty()) return@forEach

        val row = cells.map { it.html() }
        val isHeader = tr.parent()?.tagName() == "thead" || cells.all { it.tagName() == "th" }
        if (isHeader) headerRows.add(row) else bodyRows.add(row)
    }

    // Optional: uncomment only if the backend always sends the header row as <td>
    // if (headerRows.isEmpty() && bodyRows.size > 1) headerRows.add(bodyRows.removeAt(0))

    return HtmlBlock.Table(headerRows, bodyRows)
}

@Composable
fun ConsentHtmlContent(
    html: String,
    modifier: Modifier = Modifier,
    headerBgColor: String? = null,
    headerTextColor: String? = null
) {

    if (!html.contains("<table", ignoreCase = true)) {
        HtmlText(html = html, modifier = modifier)
        return
    }

    val blocks = remember(html) { parseHtmlBlocks(html) }
    Column(modifier = modifier.fillMaxWidth()) {
        blocks.forEach { block ->
            when (block) {
                is HtmlBlock.Content -> HtmlText(html = block.html)
                is HtmlBlock.Table -> HtmlTable(block,headerBgColor, headerTextColor)
            }
        }
    }
}

@Composable
fun HtmlTable(
    table: HtmlBlock.Table,
    headerBgColor: String? ,
    headerTextColor: String?,
    modifier: Modifier = Modifier
) {
    val cols = table.columnCount
    if (cols == 0) return

    val headerBg = Utils.hexToColor(headerBgColor ?: "#EEEEEE")
    val headerTextHex = headerTextColor ?: "#000000"
    val borderColor = Color(0xFFBDBDBD)

//   if the column is more than 3 then according to this condition it
//   will become scrollable and the width of the table will be the same

    val scrollable = cols > 3
    val scrollModifier = if (scrollable) Modifier.horizontalScroll(rememberScrollState()) else Modifier

    Box(modifier = modifier.padding(vertical = 8.dp).fillMaxWidth().then(scrollModifier)) {
        Column(
            modifier = (if (scrollable) Modifier else Modifier.fillMaxWidth())
                .border(1.dp, borderColor)
        ) {
            table.headerRows.forEach { row ->
                HtmlTableRow(row, cols, scrollable, true, headerBg, headerTextHex, borderColor)
            }
            table.bodyRows.forEach { row ->
                HtmlTableRow(row, cols, scrollable, false, headerBg, headerTextHex, borderColor)
            }
        }
    }
}

@Composable
private fun HtmlTableRow(
    cells: List<String>,
    cols: Int,
    scrollable: Boolean,
    isHeader: Boolean,
    headerBg: Color,
    headerTextHex: String,
    borderColor: Color
) {
    Row(modifier = Modifier.height(IntrinsicSize.Min)) {
        repeat(cols) { i ->
            val cellHtml = cells.getOrNull(i) ?: ""
            val cellModifier = (if (scrollable) Modifier.width(130.dp) else Modifier.weight(1f))
                .fillMaxHeight()
                .border(0.5.dp, borderColor)
                .background(if (isHeader) headerBg else Color.Transparent)
                .padding(8.dp)

            Box(modifier = cellModifier) {
                HtmlText(
                    html = cellHtml,
                    colorHex = if (isHeader) headerTextHex else "#000000",
                    fontSize = 12.0,
                    fontWeight = if (isHeader) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}