package com.tekhsters.gotrustsdkandroid.features.consentform.models

import com.google.gson.annotations.SerializedName

data class PublicKeyRequest(
    @SerializedName("public_key") val publicKey: String
)

data class PublicKeyResponse(
    @SerializedName("version") val version: Int?,
    @SerializedName("session_id") val session_id: String?,
    @SerializedName("encrypted_key") val encrypted_key: String?
)

data class EncryptedRequestEnvelope(
    @SerializedName("version") val version: Int,
    @SerializedName("session_id") val session_id: String,
    @SerializedName("timestamp") val timestamp: Long,
    @SerializedName("iv") val iv: String,
    @SerializedName("ciphertext") val ciphertext: String,
    @SerializedName("tag") val tag: String
)

data class EncryptedResponseEnvelope(
    @SerializedName("version") val version: Int?,
    @SerializedName("session_id") val session_id: String?,
    @SerializedName("timestamp") val timestamp: Long?,
    @SerializedName("encrypted_key") val encrypted_key: String?,
    @SerializedName("iv") val iv: String?,
    @SerializedName("ciphertext") val ciphertext: String?,
    @SerializedName("tag") val tag: String?
)
