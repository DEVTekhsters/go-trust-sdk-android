package com.tekhsters.gotrustsdkandroid.features.consentform.services

import com.google.gson.annotations.SerializedName
import com.tekhsters.gotrustsdkandroid.features.consentform.models.*
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface ConsentFormApi {

    @POST("universal/public/api/v4/translator/language-codes")
    suspend fun fetchLanguages(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("backend/api/public/download")
    suspend fun fetchImageUrl(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<ImageDownloadUrlResponse>

    @POST("universal/public/api/v4/ct/verify")
    suspend fun checkConsentStatus(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("universal/public/api/v7/gtf/display")
    suspend fun getConsentFormData(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @GET("universal/public/api/v6/gtf/display")
    suspend fun fetchConsentFormData(
        @Query("source_id") sourceId: Any,
        @Query("language_code") languageCode: String,
        @Query("subject_identity") subjectIdentity: String
    ): Response<ResponseBody>

    @POST("universal/public/api/v4/data-collector/records")
    suspend fun saveConsentFormData(
        @Header("x-consent-evidence-token") evidenceToken: String?,
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("universal/public/api/v3/security/entrypoint")
    suspend fun getConsentFormId(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @Headers("accept: application/json")
    @POST("universal/public/api/v1/security/auth/public-key")
    suspend fun sendPublicKey(
        @Body request: PublicKeyRequest
    ): Response<PublicKeyResponse>



    @GET("universal/public/api/v2/ct/frequency-list")
    suspend fun getFrequencyList(
        @Query("language_code") languageCode: String
    ): Response<ResponseBody>

    @Headers("accept: application/json")
    @POST("universal/public/api/v3/pn/display")
    suspend fun getPrivacyNotice(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @GET
    suspend fun getPlainJsonToDisplayConsent(
        @Url url: String
    ): Response<ConsentFormResponse.ConsentFormData>

    @POST("universal/public/api/v4/digilocker/login")
    suspend fun getDigiLockerResponse(
        @Query("redirect_uri") redirectUri: String
    ): Response<DigiLockerResponse>

    @POST("universal/public/api/v4/digilocker/callback")
    suspend fun getCallbackApiResponse(
        @Query("code") code: String,
        @Query("state") state: String
    ): Response<CallBackResponse>
}

// Wrapper for Language response since it's nested in result.data in Flutter
data class LanguageResponseWrapper(
    @SerializedName("result") val result: Result?
) {
    data class Result(
        @SerializedName("data") val data: List<Language>?
    )
}

data class LanguageRequest(
    @SerializedName("mode") val mode: String = "form",
    @SerializedName("customer_id") val customerId: String,
    @SerializedName("form_id") val formId: String
)

data class PrivacyNoticeRequest(
    @SerializedName("customer_id") val customerId: String,
    @SerializedName("privacy_notice_id") val privacyNoticeId: String?,
    @SerializedName("source_id") val sourceId: Any?,
    @SerializedName("language_code") val languageCode: String
)
