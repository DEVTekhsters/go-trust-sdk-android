package com.tekhsters.gotrustsdkandroid.features.consentform.services

import android.util.Log
import com.tekhsters.gotrustsdkandroid.FallbackConfig
import com.tekhsters.gotrustsdkandroid.core.utils.CryptoException
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.*
import okhttp3.Headers
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import com.tekhsters.gotrustsdkandroid.core.utils.CryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.security.PublicKey
import java.util.Arrays
import java.util.UUID
import java.util.concurrent.TimeUnit

class ApiService private constructor() {

    private var baseUrl: String = ""
    private var publicToken: String? = null
    private var authToken: String? = null
    private var resolvedSourceId: Any? = null
    private var consentEvidenceToken: String? = null

    private var api: ConsentFormApi? = null

    @Volatile
    private var currentSessionAesKey: ByteArray? = null
    @Volatile
    private var currentSessionId: String? = null

    private val cryptoSessionMutex = Mutex()
    private var sessionVersion: Int = 1

    @Volatile
    private var latestPlaintextErrorBody: String? = null
    @Volatile
    private var latestPlaintextErrorCode: Int? = null

    // Set whenever executeEncryptedRequest fails for a crypto/protocol reason
    // (bad tag, malformed envelope, request_id mismatch, unsupported
    // version/enc, etc.) rather than a plain HTTP error, so callers/telemetry
    // can tell the two apart instead of everything collapsing to "null".
    @Volatile
    private var latestCryptoError: Throwable? = null

    // Host-provided proxy this session falls back to once GoTrust's primary display/submit APIs
    // start failing. Once _useFallback flips true it stays true for the rest of this ApiService
    // session — set again (and reset) on every setFallback() call, i.e. every new consent form.
    private var fallback: FallbackConfig? = null
    private val fallbackHeaders = mutableMapOf<String, String>()
    // Tracked alongside fallbackHeaders[csrfHeaderName] rather than read from it, so the two
    // can never drift: this is the token as the SDK last received it from refreshCsrfToken(),
    // fallbackHeaders holds what actually goes out on the wire.
    private var fallbackCsrfToken: String? = null
    private var useFallback = false
    val isFallbackActive: Boolean get() = useFallback

    private val fallbackHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY })
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    companion object {
        private const val TAG = "ApiService"
        // A 401/403 on a fallback call triggers a refresh + retry; if the freshly refreshed
        // token is rejected too, refresh again up to this many times before giving up.
        private const val MAX_CSRF_REFRESH_ATTEMPTS = 2
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        val instance: ApiService by lazy { ApiService() }
    }

    fun setFallback(fallback: FallbackConfig?) {
        this.fallback = fallback
        fallbackHeaders.clear()
        fallbackHeaders.putAll(fallback?.headers ?: emptyMap())
        fallbackCsrfToken = null
        useFallback = false
    }

    fun setAuthToken(token: String?) {
        this.authToken = token
    }

    private data class FallbackHttpResult(val statusCode: Int?, val body: String?, val headers: Headers?)

    private fun updateCookieHeaderValue(cookieHeader: String?, cookieName: String, newValue: String): String {
        val pairs = (cookieHeader ?: "").split(";").map { it.trim() }.filter { it.isNotEmpty() }
        var found = false
        val updated = pairs.map { pair ->
            val eq = pair.indexOf('=')
            val key = (if (eq == -1) pair else pair.substring(0, eq)).trim()
            if (key == cookieName) {
                found = true
                "$cookieName=$newValue"
            } else pair
        }.toMutableList()
        if (!found) updated.add("$cookieName=$newValue")
        return updated.joinToString("; ")
    }

    private fun doFallbackPost(url: String, bodyJson: String): FallbackHttpResult {
        return try {
            val requestBuilder = Request.Builder().url(url).header("Content-Type", "application/json")
            fallbackHeaders.forEach { (k, v) -> requestBuilder.header(k, v) }
            val request = requestBuilder.post(bodyJson.toRequestBody(JSON_MEDIA_TYPE)).build()
            fallbackHttpClient.newCall(request).execute().use { response ->
                FallbackHttpResult(response.code, response.body?.string(), response.headers)
            }
        } catch (e: Exception) {
            Log.e(TAG, "fallback POST $url failed", e)
            FallbackHttpResult(null, null, null)
        }
    }

    private suspend fun fallbackPostWithRetry(url: String, payload: Map<String, Any?>): FallbackHttpResult =
        withContext(Dispatchers.IO) {
            val bodyJson = GsonProvider.gson.toJson(payload)
            var result = doFallbackPost(url, bodyJson)
            var refreshAttempts = 0
            while ((result.statusCode == 401 || result.statusCode == 403) &&
                fallback != null &&
                refreshAttempts < MAX_CSRF_REFRESH_ATTEMPTS
            ) {
                refreshAttempts++
                val fb = fallback!!
                val newToken = fb.refreshCsrfToken()
                if (newToken.isNullOrEmpty()) {
                    Log.d(TAG, "fallbackPostWithRetry: refreshCsrfToken returned no token on " +
                            "attempt $refreshAttempts, aborting retries")
                    break
                }
                fallbackCsrfToken = newToken
                fallbackHeaders[fb.csrfHeaderName] = newToken
                val cookieName = fb.csrfCookieName
                if (!cookieName.isNullOrEmpty()) {
                    fallbackHeaders["Cookie"] =
                        updateCookieHeaderValue(fallbackHeaders["Cookie"], cookieName, newToken)
                }
                result = doFallbackPost(url, bodyJson)
                Log.d(TAG, "fallbackPostWithRetry retry #$refreshAttempts: $url -> ${result.statusCode}")
            }
            result
        }

    fun setBaseUrl(url: String) {
        if (baseUrl == url && api != null) return
        baseUrl = url
        currentSessionAesKey = null
        currentSessionId = null
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val authInterceptor = Interceptor { chain ->
            val original = chain.request()
            val requestBuilder = original.newBuilder()
            publicToken?.let {
                if (it.isNotEmpty()) {
                    Log.d(TAG, "Adding x-public-token: $it")
                    requestBuilder.header("x-public-token", it)
                }
            }
            authToken?.let {
                if (it.isNotEmpty()) {
                    Log.d("AUTH_TOKEN", "Adding Authorization : $it")
                    requestBuilder.header("Authorization", "Bearer $it")
                }
            }
            chain.proceed(requestBuilder.build())
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .addInterceptor(authInterceptor)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(GsonProvider.gson))
            .build()

        api = retrofit.create(ConsentFormApi::class.java)
    }
    suspend fun fetchLanguages(customerId: String, formId: String): List<Language>? {
        return try {
            val request = LanguageRequest(
                mode = "form",
                customerId = customerId,
                formId = formId)
            val body = executeEncryptedRequest<LanguageRequest, LanguageResponseWrapper>(request, "/public/api/v4/translator/language-codes") { envelope ->
                api!!.fetchLanguages(envelope)
            }
            if (body != null) {
                val list = body.result?.data?.toMutableList() ?: mutableListOf()
                if (list.none { it.code == "en" }) {
                    list.add(0, Language(code = "en", name = "English"))
                }
                list
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchLanguages error", e)
            emptyList()
        }
    }

    private suspend fun ensureSessionAesKey(): Boolean {
        if (currentSessionAesKey != null && !currentSessionId.isNullOrEmpty()) return true
        return cryptoSessionMutex.withLock {
            if (currentSessionAesKey != null && !currentSessionId.isNullOrEmpty()) return true
            try {
                val keyPair = CryptoManager.getOrCreateRsaKeyPair()
                val androidPublicKeyPem = CryptoManager.exportPublicKeyToPem(keyPair.public)
                val req = PublicKeyRequest(publicKey = androidPublicKeyPem)
                val response = api?.sendPublicKey(req)
                if (response?.isSuccessful == true) {
                    val body = response.body()
                    val encryptedKeyStr = body?.encrypted_key
                    if (!encryptedKeyStr.isNullOrEmpty()) {
                        val encryptedKeyBytes = CryptoManager.Base64Url.decode(encryptedKeyStr)
                        val aes1KeyBytes = CryptoManager.decryptRsaOaep256(
                            privateKey = keyPair.private,
                            encryptedBytes = encryptedKeyBytes
                        )
                        sessionVersion = body.version ?: 1
                        currentSessionId = body.session_id
                        currentSessionAesKey = aes1KeyBytes
                        true
                    } else false
                } else false
            } catch (e: Exception) {
                Log.e(TAG, "Failed during session key exchange ", e)
                false
            }
        }
    }

    private suspend fun resetSession() {
        cryptoSessionMutex.withLock {
            currentSessionAesKey = null
            currentSessionId = null
        }
    }

    private suspend inline fun <reified Req, reified Res> executeEncryptedRequest(
        payload: Req,
        backendPath: String,
        crossinline apiCall: suspend (
            EncryptedRequestEnvelope
        ) -> retrofit2.Response<okhttp3.ResponseBody>
    ): Res? {

        latestCryptoError = null

        if (!ensureSessionAesKey()) {
            return null
        }

        val activeAesKey = cryptoSessionMutex.withLock {
            val key = currentSessionAesKey
            currentSessionAesKey = null
            key
        } ?: run {
            Log.e(TAG, "Session AES key unexpectedly null")
            return null
        }

        val iv = CryptoManager.generateRequestIv()

        try {
            val sessionId = currentSessionId ?: run {
                Log.e(TAG, "Session ID unexpectedly null")
                resetSession()
                return null
            }
            val timestamp = System.currentTimeMillis() / 1000

            val jsonPayload = GsonProvider.gson.toJson(payload)
            val payloadBytes = jsonPayload.toByteArray(Charsets.UTF_8)

            val requestAad = CryptoManager.buildAad(
                version = sessionVersion,
                sessionId = sessionId,
                timestamp = timestamp,
                httpMethod = "POST",
                backendPath = backendPath,
                direction = "request",
                requestTag = ""
            )

            val (ciphertextBytes, tagBytes) = CryptoManager.encryptAesGcm(
                aesKey = activeAesKey,
                iv = iv,
                aad = requestAad,
                plainText = payloadBytes
            )

            val envelope = EncryptedRequestEnvelope(
                version = sessionVersion,
                session_id = sessionId,
                timestamp = timestamp,
                iv = CryptoManager.Base64Url.encode(iv),
                ciphertext = CryptoManager.Base64Url.encode(ciphertextBytes),
                tag = CryptoManager.Base64Url.encode(tagBytes)
            )

            val response = apiCall(envelope)
            val responseBody = response.body()?.string()

            response.headers()["x-consent-evidence-token"]?.let {
                if (it.isNotEmpty()) {
                    consentEvidenceToken = it
                }
            }

            response.headers()["x-public-token"]?.let {
                if (it.isNotEmpty()) {
                    publicToken = it
                }
            }

            if (!response.isSuccessful) {
                resetSession()
                latestPlaintextErrorCode = response.code()
                latestPlaintextErrorBody = response.errorBody()?.string() ?: responseBody
                return null
            }

            if (responseBody.isNullOrEmpty()) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Successful response had an empty body")
                )
                return null
            }

            val responseEnvelope = try {
                GsonProvider.gson.fromJson(
                    responseBody,
                    EncryptedResponseEnvelope::class.java
                )
            } catch (e: Exception) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(e)
                Log.e(TAG, "Invalid encrypted response envelope", e)
                return null
            }

            if (responseEnvelope == null) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Response envelope is null")
                )
                return null
            }

            val resIvStr = responseEnvelope.iv
            val resCiphertextStr = responseEnvelope.ciphertext
            val resTagStr = responseEnvelope.tag
            val nextEncryptedKeyStr = responseEnvelope.encrypted_key

            if (resIvStr.isNullOrEmpty() || resCiphertextStr.isNullOrEmpty() || resTagStr.isNullOrEmpty() || nextEncryptedKeyStr.isNullOrEmpty()) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Response missing iv/ciphertext/tag/encrypted_key")
                )
                Log.e(TAG, "Security Alert: encrypted response missing fields")
                return null
            }

            val responseSessionId = responseEnvelope.session_id
            if (responseSessionId != null && responseSessionId != sessionId) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Response session_id mismatch")
                )
                Log.e(TAG, "Security Alert: session_id mismatch")
                return null
            }

            val resIv = CryptoManager.Base64Url.decode(resIvStr)
            val resCiphertext = CryptoManager.Base64Url.decode(resCiphertextStr)
            val resTag = CryptoManager.Base64Url.decode(resTagStr)

            if (resIv.isEmpty() || resIv[0] != CryptoManager.RESPONSE_NONCE_PREFIX) {
                resetSession()
                latestCryptoError = CryptoException.AesFailure(
                    IllegalStateException("Invalid response nonce prefix")
                )
                Log.e(TAG, "Security Alert: response nonce prefix invalid")
                return null
            }

            val keyPair = CryptoManager.getOrCreateRsaKeyPair()
            val nextEncryptedKeyBytes = CryptoManager.Base64Url.decode(nextEncryptedKeyStr)
            val nextAesKeyBytes = try {
                CryptoManager.decryptRsaOaep256(
                    privateKey = keyPair.private,
                    encryptedBytes = nextEncryptedKeyBytes
                )
            } catch (e: Exception) {
                resetSession()
                latestCryptoError = CryptoException.RsaFailure(e)
                Log.e(TAG, "Failed to decrypt next session AES key from response envelope", e)
                return null
            }

            val responseTimestamp = responseEnvelope.timestamp ?: timestamp
            val responseAad = CryptoManager.buildAad(
                version = sessionVersion,
                sessionId = sessionId,
                timestamp = responseTimestamp,
                httpMethod = "POST",
                backendPath = backendPath,
                direction = "response",
                requestTag = envelope.tag
            )

            val decryptedBytes = try {
                CryptoManager.decryptAesGcm(
                    aesKey = nextAesKeyBytes,
                    iv = resIv,
                    aad = responseAad,
                    ciphertext = resCiphertext,
                    tag = resTag
                )
            } catch (e: Exception) {
                resetSession()
                latestCryptoError = if (e is CryptoException) e else CryptoException.AesFailure(e)
                Log.e(TAG, "Failed to decrypt response payload", e)
                return null
            }

            cryptoSessionMutex.withLock {
                currentSessionAesKey = nextAesKeyBytes
                currentSessionId = responseSessionId ?: sessionId
            }

            return GsonProvider.gson.fromJson(
                String(decryptedBytes, Charsets.UTF_8),
                Res::class.java
            )

        } catch (e: CryptoException) {
            resetSession()
            latestCryptoError = e
            Log.e(TAG, "Encrypted API request failed - crypto error", e)
            return null
        } catch (e: Exception) {
            resetSession()
            latestCryptoError = e
            Log.e(TAG, "Encrypted API request failed", e)
            return null
        } finally {
            java.util.Arrays.fill(activeAesKey, 0.toByte())
        }
    }


    suspend fun checkConsentStatus(sourceId: String, subjectIdentityValues: Map<String, Any?>, token: String? = null, dynamicConsent:Boolean? ): CheckConsentResponse? {
        try {
            val decrypterResponse = getConsentFormId(sourceId, token)
            resolvedSourceId =
                Utils.safeId(decrypterResponse?.result?.data?.sourceId)?.toString() ?: return null

            // In token flow, identities come from the decryptor; otherwise they are host-supplied.
            val identities = if (!token.isNullOrEmpty()) {
                (decrypterResponse?.result?.data?.subjectIdentityValues ?: emptyList())
                    .associate { Utils.safeId(it.piiLabelId).toString() to it.piiValue }
            } else subjectIdentityValues

            return verifyConsent(resolvedSourceId.toString(), identities, dynamicConsent)
        } catch (e: Exception) {
            Log.e(TAG, "checkConsentStatus error", e)
            return null
        }
    }

    /**
     * Internal-ish helper that avoids re-hitting the decryptor when the response is already known.
     */
    suspend fun verifyConsent(
        resolvedSourceId: String,
        subjectIdentityValues: Map<String, Any?>,
        dynamicConsent: Boolean? = null
    ): CheckConsentResponse? {
        return try {
            val subjectIdentityValuesList = subjectIdentityValues.entries.map {
                mapOf(
                    "pii_label_id" to it.key.toInt(),
                    "pii_value" to PhoneIdentity.forUnknownLabel(it.value?.toString())
                )
            }

//resolvedSourceId is already converted to string above

            val payload = mapOf(
                "source_id" to resolvedSourceId,
                "dynamic_consent" to dynamicConsent,
                "subject_identity_values" to subjectIdentityValuesList
            )
            val body = executeEncryptedRequest<Map<String, Any?>, CheckConsentResponse>(payload,"/public/api/v4/ct/verify" ) { envelope ->
                api!!.checkConsentStatus(envelope)
            }
            if (body != null) {
                body
            } else {
                if ((latestPlaintextErrorCode == null || latestPlaintextErrorCode!! >= 500) && fallback != null) {
                    Log.d(TAG, "checkConsentStatus: verify API failed (status=$latestPlaintextErrorCode), switching to fallback for this session")
                    useFallback = true
                }
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "checkConsentStatus error", e)
            if (fallback != null) useFallback = true
            null
        }
    }

    suspend fun getConsentFormData(payload: Map<String, Any?>, sourceId: String?): ConsentFormResponse.ConsentFormData? {
        consentEvidenceToken = null
        latestPlaintextErrorBody = null
        latestPlaintextErrorCode = null

        var body: ConsentFormResponse? = null
        var evidenceToken: String? = null
        var headerPublicToken: String? = null

        if (!useFallback) {
            try {
                body = executeEncryptedRequest<Map<String, Any?>, ConsentFormResponse>(payload,backendPath = "/public/api/v7/gtf/display") { envelope ->
                    api!!.getConsentFormData(envelope)
                }
                if (body == null) {
                    if ((latestPlaintextErrorCode == null || latestPlaintextErrorCode!! >= 500) && fallback != null) {
                        Log.d(TAG, "getConsentFormData: primary display failed (status=$latestPlaintextErrorCode), switching to fallback for this session")
                        useFallback = true
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "getConsentFormData primary call failed", e)
                if (fallback != null) useFallback = true else return null
            }
        }

        if (useFallback) {
            val fb = fallback ?: return null
            val fallbackPayload: Map<String, Any?> = mapOf("source_id" to sourceId)
            val result = fallbackPostWithRetry(fb.displayUrl, fallbackPayload)
            if (result.statusCode == 200 && result.body != null) {
                body = try {
                    GsonProvider.gson.fromJson(result.body, ConsentFormResponse::class.java)
                } catch (e: Exception) {
                    Log.e(TAG, "getConsentFormData: unparseable fallback body", e)
                    null
                }
                result.headers?.get("x-consent-evidence-token")?.let { if (it.isNotEmpty()) consentEvidenceToken = it }
                result.headers?.get("x-public-token")?.let { if (it.isNotEmpty()) publicToken = it }
            } else {
                return null
            }
        }

        if (body == null) return null

        body.token?.let { if (it.isNotEmpty()) publicToken = it }
        body.result?.token?.let { if (it.isNotEmpty()) publicToken = it }
        body.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }

        return if (body.result?.data?.formTemplate != null) {
            body.result.data.formTemplate
        } else if (!body.result?.data?.formAccessUrl.isNullOrEmpty()) {
            getPlainJsonToDisplayConsent(body.result.data.formAccessUrl)
        } else null
    }

    suspend fun saveConsentFormData(payload: MutableMap<String, Any?>): SaveConsentResponse = withContext(Dispatchers.IO) {
        latestPlaintextErrorBody = null
        latestPlaintextErrorCode = null
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build()

            // 1) get public IP
            val ipRequest = Request.Builder().url("https://api.ipify.org?format=json").build()
            var ip = "127.0.0.1"
            try {
                client.newCall(ipRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val respBody = response.body?.string()
                        val json = GsonProvider.gson.fromJson(respBody, Map::class.java)
                        ip = json["ip"] as? String ?: "127.0.0.1"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get IP", e)
            }

            // 2) look up country & continent
            var countryCode = "IN"
            var continent = "ASIA"
            val geoRequest = Request.Builder().url("https://ipapi.co/$ip/json").build()
            try {
                client.newCall(geoRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val respBody = response.body?.string()
                        val json = GsonProvider.gson.fromJson(respBody, Map::class.java)
                        countryCode = json["country"] as? String ?: "IN"
                        continent = json["continent_code"] as? String ?: "ASIA"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get Geo", e)
            }

            val geolocation = "$ip($countryCode)"
            payload["geolocation"] = geolocation
            payload["continent"] = continent

            val fb = fallback
            if (useFallback && fb != null) {
                val result = fallbackPostWithRetry(fb.submitUrl, payload)
                val statusCode = result.statusCode
                val isHttpSuccess = statusCode == 200 || statusCode == 202
                val parsed = result.body?.takeIf { it.isNotBlank() }?.let {
                    try {
                        GsonProvider.gson.fromJson(it, SaveConsentResponse::class.java)
                    } catch (e: Exception) {
                        Log.e(TAG, "saveConsentFormData: unparseable fallback body: $it", e)
                        null
                    }
                }
                SaveConsentResponse(
                    success = parsed?.success ?: isHttpSuccess,
                    statusCode = parsed?.statusCode ?: statusCode,
                    message = parsed?.message,
                    result = parsed?.result,
                )
            } else {
                val body = executeEncryptedRequest<Map<String, Any?>, SaveConsentResponse>(payload,"/public/api/v4/data-collector/records" ) { envelope ->
                    api!!.saveConsentFormData(consentEvidenceToken, envelope)
                }
                if (body != null) {
                    body
                } else {
                    val errStr = latestPlaintextErrorBody
                    val code = latestPlaintextErrorCode
                    if (!errStr.isNullOrEmpty()) {
                        val parsed = try {
                            GsonProvider.gson.fromJson(errStr, SaveConsentResponse::class.java)
                        } catch (_: Exception) {
                            null
                        }
                        saveFailure(
                            statusCode = parsed?.statusCode ?: code,
                            message = parsed?.message?.takeIf { it.isNotBlank() }
                                ?: errStr.takeIf { it.isNotBlank() }
                                ?: "HTTP $code",
                        )
                    } else {
                        // No plaintext HTTP error was recorded — this was a
                        // crypto/protocol failure (see latestCryptoError) or a
                        // transport exception, not an HTTP-level rejection.
                        saveFailure(
                            code,
                            latestCryptoError?.message ?: "Consent form service submission failed"
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "saveConsentFormData error", e)
            saveFailure(null, e.message ?: e::class.java.simpleName)
        }
    }


    private fun saveFailure(statusCode: Int?, message: String) =
        SaveConsentResponse(success = false, statusCode = statusCode, message = message, result = null)

    suspend fun getConsentFormId(decryptedSourceId: String?, token: String? = null): DecrypterApiResponse? {
        latestPlaintextErrorBody = null
        latestPlaintextErrorCode = null
        return try {
            val data = if (!token.isNullOrEmpty()) {
                mapOf("token" to token)
            } else {
                mapOf("source_id" to decryptedSourceId)
            }
            val payload = mapOf("data" to data)
            val body = executeEncryptedRequest<Map<String, Any?>, DecrypterApiResponse>(payload , "/public/api/v3/security/entrypoint") { envelope ->
                api!!.getConsentFormId(envelope)
            }
            if (body != null) {
                body.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }
                resolvedSourceId = Utils.safeId(body.result?.data?.sourceId)
                body
            } else {
                if ((latestPlaintextErrorCode == null || latestPlaintextErrorCode!! >= 500) && fallback != null) {
                    Log.d(TAG, "getConsentFormId: decryptor failed (status=$latestPlaintextErrorCode), switching to fallback for this session")
                    useFallback = true
                }
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getConsentFormId error", e)
            if (fallback != null) useFallback = true
            null
        }
    }

    suspend fun getPrivacyNotice(customerId: String, privacyNoticeId: String, languageCode: String): PrivacyNoticeResponse? {
        return try {
            val request = PrivacyNoticeRequest(
                customerId = customerId,
                privacyNoticeId = privacyNoticeId,
                sourceId = resolvedSourceId,
                languageCode = languageCode
            )
            executeEncryptedRequest<PrivacyNoticeRequest, PrivacyNoticeResponse>(request, "/public/api/v3/pn/display") { envelope ->
                api!!.getPrivacyNotice(envelope)
            }
        } catch (e: Exception) {
            Log.e(TAG, "getPrivacyNotice error", e)
            null
        }
    }

    suspend fun getPlainJsonToDisplayConsent(url: String): ConsentFormResponse.ConsentFormData? {
        return try {
            val response = api?.getPlainJsonToDisplayConsent(url)
            if (response?.isSuccessful == true) {
                response.body()
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getPlainJsonToDisplayConsent error", e)
            null
        }
    }

    suspend fun getDigiLockerResponse(sourceId: String): DigiLockerResponse? {
        return try {
            val consentUrl = "$baseUrl/public/consent-form?source_id=$sourceId"
            val response = api?.getDigiLockerResponse(consentUrl)
            if (response?.isSuccessful == true) {
                response.body()
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getDigiLockerResponse error", e)
            null
        }
    }

    suspend fun getCallbackApiResponse(code: String, state: String): CallBackResponse? {
        return try {
            val response = api?.getCallbackApiResponse(code, state)
            if (response?.isSuccessful == true) {
                val body = response.body()

                // Extract public token
                body?.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }

                body
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getCallbackApiResponse error", e)
            null
        }
    }

    suspend fun fetchImageUrl(iconUrl: String?): ImageDownloadUrlResponse? {
        return try {
            val payload = mapOf("objectKey" to iconUrl)
            val response = api?.fetchImageUrl(payload)
            if(response?.isSuccessful == true){
                val body = response.body()
                body
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchImageUrl error", e)
            null
        }
    }

}
