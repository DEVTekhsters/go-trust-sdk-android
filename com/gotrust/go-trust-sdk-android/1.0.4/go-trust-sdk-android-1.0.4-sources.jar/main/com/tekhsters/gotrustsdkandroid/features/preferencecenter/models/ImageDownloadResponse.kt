package com.tekhsters.gotrustsdkandroid.features.preferencecenter.models

import com.google.gson.annotations.SerializedName

data class ImageDownloadResponse(
    val success: Boolean?,
    @SerializedName("status_code") val statusCode: Int?,
    val message: String?,
    val result: Result?,
    val time: Long?
) {
    data class Result(
        val downloadUrl: String?
    )
}
