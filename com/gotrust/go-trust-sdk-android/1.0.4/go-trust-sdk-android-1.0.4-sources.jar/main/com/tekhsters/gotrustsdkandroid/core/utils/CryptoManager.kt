package com.tekhsters.gotrustsdkandroid.core.utils

import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.interfaces.RSAPublicKey
import java.security.spec.MGF1ParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec

sealed class CryptoException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class InvalidBase64Url(cause: Throwable? = null) : CryptoException("Invalid Base64URL input", cause)
    class InvalidPublicKey(cause: Throwable) : CryptoException("Invalid or undersized RSA public key", cause)
    class RsaFailure(cause: Throwable) : CryptoException("RSA operation failed", cause)
    class AesAuthFailure(cause: Throwable) : CryptoException("AES-GCM authentication failed (bad tag/ciphertext)", cause)
    class AesFailure(cause: Throwable) : CryptoException("AES-GCM operation failed", cause)
}

object CryptoManager {

    const val REQUEST_NONCE_PREFIX: Byte = 0
    const val RESPONSE_NONCE_PREFIX: Byte = 1

    private const val AES_KEY_SIZE_BYTES = 32
    private const val GCM_IV_SIZE_BYTES = 12
    private const val GCM_TAG_SIZE_BYTES = 16
    private const val GCM_TAG_SIZE_BITS = GCM_TAG_SIZE_BYTES * 8
    private const val MIN_RSA_KEY_SIZE_BITS = 2048

    private val secureRandom = SecureRandom()

    object Base64Url {
        fun encode(bytes: ByteArray): String {
            return android.util.Base64.encodeToString(
                bytes,
                android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING
            )
        }

        fun decode(s: String): ByteArray {
            return try {
                android.util.Base64.decode(s, android.util.Base64.URL_SAFE)
            } catch (e: Exception) {
                throw CryptoException.InvalidBase64Url(e)
            }
        }
    }

    @Volatile
    private var rsaKeyPair: KeyPair? = null

    /**
     * Process-lifetime RSA keypair for the session-key exchange. The same keypair must be
     * reused for every exchange, including the rotated key returned in a response envelope,
     * since the backend wraps those to the public key sent during the handshake.
     *
     * Not AndroidKeyStore-backed: a keystore key cannot authorize an MGF1-SHA256 digest
     * below API 35 (KeyGenParameterSpec.Builder#setMgf1Digests), so OAEP-SHA256/MGF1-SHA256
     * decryption fails there with INCOMPATIBLE_MGF_DIGEST. The private key lives only in memory.
     */
    @Synchronized
    fun getOrCreateRsaKeyPair(): KeyPair {
        rsaKeyPair?.let { return it }
        return try {
            KeyPairGenerator.getInstance("RSA")
                .apply { initialize(MIN_RSA_KEY_SIZE_BITS) }
                .generateKeyPair()
                .also { rsaKeyPair = it }
        } catch (e: Exception) {
            throw CryptoException.RsaFailure(e)
        }
    }

    fun exportPublicKeyToPem(publicKey: PublicKey): String {
        val encoded = android.util.Base64.encodeToString(
            publicKey.encoded,
            android.util.Base64.NO_WRAP
        )
        return "-----BEGIN PUBLIC KEY-----\n$encoded\n-----END PUBLIC KEY-----\n"
    }


    fun generateIv(): ByteArray = ByteArray(GCM_IV_SIZE_BYTES).also { secureRandom.nextBytes(it) }

    fun generateRequestIv(): ByteArray = generateIv().also { it[0] = REQUEST_NONCE_PREFIX }

    fun generateResponseIv(): ByteArray = generateIv().also { it[0] = RESPONSE_NONCE_PREFIX }

    fun buildAad(
        version: Int = 1,
        sessionId: String,
        timestamp: Long,
        httpMethod: String,
        backendPath: String,
        direction: String,
        requestTag: String = ""
    ): ByteArray {
        require(direction == "request" || direction == "response") {
            "direction must be \"request\" or \"response\", got \"$direction\""
        }
        val escapedSessionId = escapeJsonString(sessionId)
        val escapedPath = escapeJsonString(backendPath)
        val escapedRequestTag = escapeJsonString(requestTag)
        val method = httpMethod.uppercase()
        val json = "[$version,\"$escapedSessionId\",$timestamp,\"$method\",\"$escapedPath\",\"$direction\",\"$escapedRequestTag\"]"
        return json.toByteArray(Charsets.UTF_8)
    }

    private fun escapeJsonString(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            when (c) {
                '\\' -> sb.append("\\\\")
                '"' -> sb.append("\\\"")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c.code < 0x20) {
                    sb.append("\\u%04x".format(c.code))
                } else {
                    sb.append(c)
                }
            }
        }
        return sb.toString()
    }


    fun decryptRsaOaep256(privateKey: PrivateKey, encryptedBytes: ByteArray): ByteArray {
        return try {
            val cipher = try {
                Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
            } catch (e: Exception) {
                Cipher.getInstance("RSA/ECB/OAEPPadding")
            }
            val oaepSpec = OAEPParameterSpec(
                "SHA-256",
                "MGF1",
                MGF1ParameterSpec.SHA256,
                PSource.PSpecified.DEFAULT
            )
            cipher.init(Cipher.DECRYPT_MODE, privateKey, oaepSpec)
            cipher.doFinal(encryptedBytes)
        } catch (e: Exception) {
            throw CryptoException.RsaFailure(e)
        }
    }

    fun encryptAesGcm(aesKey: ByteArray, iv: ByteArray, aad: ByteArray, plainText: ByteArray): Pair<ByteArray, ByteArray> {
        require(aesKey.size == AES_KEY_SIZE_BYTES) { "AES key must be $AES_KEY_SIZE_BYTES bytes" }
        require(iv.size == GCM_IV_SIZE_BYTES) { "GCM IV must be $GCM_IV_SIZE_BYTES bytes" }
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val gcmSpec = GCMParameterSpec(GCM_TAG_SIZE_BITS, iv)
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(aesKey, "AES"), gcmSpec)
            cipher.updateAAD(aad)
            val encryptedWithTag = cipher.doFinal(plainText)
            val ciphertext = encryptedWithTag.copyOfRange(0, encryptedWithTag.size - GCM_TAG_SIZE_BYTES)
            val tag = encryptedWithTag.copyOfRange(encryptedWithTag.size - GCM_TAG_SIZE_BYTES, encryptedWithTag.size)
            Pair(ciphertext, tag)
        } catch (e: Exception) {
            throw CryptoException.AesFailure(e)
        }
    }

    fun decryptAesGcm(aesKey: ByteArray, iv: ByteArray, aad: ByteArray, ciphertext: ByteArray, tag: ByteArray): ByteArray {
        require(aesKey.size == AES_KEY_SIZE_BYTES) { "AES key must be $AES_KEY_SIZE_BYTES bytes" }
        require(iv.size == GCM_IV_SIZE_BYTES) { "GCM IV must be $GCM_IV_SIZE_BYTES bytes" }
        require(tag.size == GCM_TAG_SIZE_BYTES) { "GCM tag must be $GCM_TAG_SIZE_BYTES bytes" }
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val gcmSpec = GCMParameterSpec(GCM_TAG_SIZE_BITS, iv)
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(aesKey, "AES"), gcmSpec)
            cipher.updateAAD(aad)
            cipher.doFinal(ciphertext + tag)
        } catch (e: AEADBadTagException) {
            throw CryptoException.AesAuthFailure(e)
        } catch (e: Exception) {
            throw CryptoException.AesFailure(e)
        }
    }
}
