package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.core.ui.ShowImage
import com.tekhsters.gotrustsdkandroid.core.utils.HtmlText
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.core.utils.getButtonShape
import com.tekhsters.gotrustsdkandroid.core.utils.looksLikeHtml
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse
import kotlinx.coroutines.launch

// ============================================================================
// 1. BRANDING & THEME CONSTANTS
// ============================================================================
object IobTheme {
    // [DYNAMIC_STRING_FROM_API: formConfiguration.form.colorScheme] or Your theme colours
    val primaryBlue = Color(0xFF0B2545)
    val accentGold = Color(0xFFE5A823)
    val alertRed = Color(0xFFC81D25)
    val surfaceBg = Color(0xFFF8F9FA)
    val cardBg = Color(0xFFFFFFFF)
    val textDark = Color(0xFF1E293B)
    val textMuted = Color(0xFF64748B)
    val borderSubtle = Color(0xFFCBD5E1)

    val headerStyle = TextStyle(
        fontSize = 17.sp,
        fontWeight = FontWeight.W700,
        color = textDark
    )

    val subHeaderStyle = TextStyle(
        fontSize = 14.sp,
        fontWeight = FontWeight.W600,
        color = textDark
    )

    val bodyStyle = TextStyle(
        fontSize = 13.sp,
        fontWeight = FontWeight.W400,
        color = textMuted,
        lineHeight = 18.2.sp
    )
}

// ============================================================================
// 2. DATA MODELS (FOR STANDALONE CLIENT USAGE)
// ============================================================================
// ============================================================================
// 2. DATA MODELS (FOR STANDALONE CLIENT USAGE)
// ============================================================================
data class StaticPrivacySection(
    val id: Int,
    val version: String,
    val title: String,
    val contentHtml: String
)

// ============================================================================
// 3. DYNAMIC SDK SCREEN (WIRED TO ConsentFormViewModel)
// ============================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IobConsentFormScreen(
    viewModel: ConsentFormViewModel,
    onClose: () -> Unit
) {
    val formState by viewModel.consentForm.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val checkAllStatus by viewModel.checkAllStatus.collectAsState()
    val consentRevision by viewModel.consentRevision.collectAsState()
    val isSubmitting by viewModel.isSubmitting.collectAsState()
    val submitSuccess by viewModel.submitSuccess.collectAsState()
    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
    val privacyData by viewModel.privacyData.collectAsState()
    val invalidPiiKeys by viewModel.invalidPiiKeys.collectAsState()

    var showPrivacyNoticeScreen by remember { mutableStateOf(false) }
    var showSuccessDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeSnackbar()
        }
    }

    LaunchedEffect(submitSuccess) {
        if (submitSuccess != null) {
            showSuccessDialog = true
        }
    }

    if (showPrivacyNoticeScreen) {
        IobPrivacyNoticeScreen(
            initialLanguage = selectedLanguage,
            // [DYNAMIC_STRING_FROM_API: GET /api/v1/consent-form/languages -> List<Language>.name / .code]
            availableLanguages = languages.map { mapOf("code" to (it.code ?: ""), "name" to (it.name ?: "")) },
            showCrossButton = true,
            viaConsentScreen = true,
            onAgreeAndContinue = {
                val first = privacyData.firstOrNull()
                if (first != null) {
                    viewModel.onPrivacyNoticeAgreed(selectedLanguage, first.id ?: 0, first.version ?: 1.0)
                }
                showPrivacyNoticeScreen = false
            },
            onClose = {
                showPrivacyNoticeScreen = false
            }
        )
        return
    }

    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = {
                showSuccessDialog = false
                onClose()
            },
            shape = RoundedCornerShape(12.dp),
            containerColor = IobTheme.cardBg,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = Color(0xFF2E7D32)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    // [DYNAMIC_STRING_FROM_API: Localization resource / Save API response.message]
                    Text(
                        text = submitSuccess?.message ?: "Consent Submitted",
                        style = TextStyle(
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = IobTheme.primaryBlue
                        )
                    )
                }
            },
            text = {
                // [DYNAMIC_STRING_FROM_API: Save API response.message: e.g., 'Consent form submitted successfully!']
                Text(
                    text = "Your consent preferences have been recorded successfully.",
                    style = IobTheme.bodyStyle
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        onClose()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IobTheme.primaryBlue)
                ) {
                    // [DYNAMIC_STRING_FROM_API: Localization resource: 'OK' / 'Close']
                    Text("OK", color = Color.White)
                }
            }
        )
    }

    val fc = formState?.formConfiguration
    val dataPrincipalPii = formState?.piiList?.dataPrincipalPiiList ?: emptyList()
    val consentActorPii = formState?.piiList?.consentActorPiiList ?: emptyList()
    val isMinorForm = consentActorPii.isNotEmpty()

    val dataPrincipalCategories = (formState?.categoryList?.dataPrincipalCategoryList ?: emptyList())
        .filter { it.visible != false }
    val consentActorCategories = (formState?.categoryList?.consentActorCategoryList ?: emptyList())
        .filter { it.visible != false }

    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = IobTheme.alertRed,
                    contentColor = Color.White
                )
            }
        },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = IobTheme.primaryBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                ),
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // [DYNAMIC_STRING_FROM_API: formConfiguration.form.logo.logoText or Organization Short Code]
                        val logo = fc?.form?.logo
                        if (logo?.showLogo == true && !logo.logoUrl.isNullOrEmpty()) {
                            ShowImage(
                                iconObjectKey = logo.logoUrl,
                                iconWidth = logo.width,
                                iconHeight = logo.height,
                                getImageUrl = viewModel::getImageUrl
                            )
                        } else {
                            Surface(
                                color = IobTheme.accentGold,
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.padding(vertical = 3.dp)
                            ) {
                                Text(
                                    text = "IOB",
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.W900,
                                        color = IobTheme.primaryBlue
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        // [DYNAMIC_STRING_FROM_API: formConfiguration.form.heading.text]
                        val headingText = fc?.form?.heading?.text ?: "Consent Collection"
                        if (looksLikeHtml(headingText)) {
                            HtmlText(html = headingText, colorHex = "#FFFFFF")
                        } else {
                            Text(
                                text = headingText,
                                style = TextStyle(
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                    }
                },
                actions = {
                    if (fc?.form?.showLanguage == true && languages.isNotEmpty()) {
                        // [DYNAMIC_STRING_FROM_API: GET /api/v1/consent-form/languages -> List<Language>.name / .code]
                        LanguageSelectorDropdown(
                            languages = languages.map { mapOf("code" to (it.code ?: ""), "name" to (it.name ?: "")) },
                            selectedCode = selectedLanguage,
                            onLanguageSelected = { viewModel.onLanguageChanged(it) }
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                }
            )
        },
        containerColor = IobTheme.surfaceBg,
        bottomBar = {
            IobSubmitActionSection(
                viewModel = viewModel,
                fc = fc,
                isSubmitting = isSubmitting,
                onPrivacyPolicyClick = {
                    viewModel.showPrivacyNotice()
                    showPrivacyNoticeScreen = true
                },
                onClose = onClose
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Banner Card
            Card(
                colors = CardDefaults.cardColors(containerColor = IobTheme.cardBg),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, IobTheme.borderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = IobTheme.primaryBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        // [DYNAMIC_STRING_FROM_API: formConfiguration.form.heading.text]
                        val bannerHeading = fc?.form?.heading?.text ?: "Data Principal Consent Collection"
                        if (looksLikeHtml(bannerHeading)) {
                            HtmlText(html = bannerHeading, colorHex = "#0B2545")
                        } else {
                            Text(
                                text = bannerHeading,
                                style = IobTheme.headerStyle.copy(fontSize = 15.sp)
                            )
                        }
                    }
                    // [DYNAMIC_STRING_FROM_API: formConfiguration.form.description.text]
                    val bannerDesc = fc?.form?.description?.text ?: "Under DPDP Act 2023 and RBI guidelines, your explicit consent is required for processing."
                    if (bannerDesc.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        if (looksLikeHtml(bannerDesc)) {
                            HtmlText(html = bannerDesc)
                        } else {
                            Text(
                                text = bannerDesc,
                                style = IobTheme.bodyStyle
                            )
                        }
                    }
                }
            }

            // PII Section
            if (fc?.piiSection?.showPiiSection == true && (dataPrincipalPii.isNotEmpty() || consentActorPii.isNotEmpty())) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = IobTheme.cardBg),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, IobTheme.borderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        val mandatoryPiiIds = remember(formState) { viewModel.getMandatoryPiiIds() }
                        // [DYNAMIC_STRING_FROM_API: formConfiguration.piiSection.dataPrincipalHeading.text]
                        IobPiiFieldsGroup(
                            piiList = dataPrincipalPii,
                            headingText = if (isMinorForm) fc.piiSection.dataPrincipalHeading?.text else null,
                            mandatoryPiiIds = mandatoryPiiIds,
                            invalidPiiKeys = invalidPiiKeys,
                            viewModel = viewModel
                        )
                        // [DYNAMIC_STRING_FROM_API: formConfiguration.piiSection.consentActorHeading.text]
                        IobPiiFieldsGroup(
                            piiList = consentActorPii,
                            headingText = if (isMinorForm) fc.piiSection.consentActorHeading?.text else null,
                            mandatoryPiiIds = mandatoryPiiIds,
                            invalidPiiKeys = invalidPiiKeys,
                            viewModel = viewModel
                        )
                    }
                }
            }

            // Consent Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // [DYNAMIC_STRING_FROM_API: basicInfo.preferenceInputHeading]
                    Text(
                        text = formState?.basicInfo?.preferenceInputHeading ?: "Processing Purposes",
                        style = IobTheme.headerStyle.copy(fontSize = 15.sp)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = checkAllStatus,
                            onCheckedChange = { viewModel.toggleCheckAll(it) },
                            colors = CheckboxDefaults.colors(checkedColor = IobTheme.primaryBlue)
                        )
                        // [DYNAMIC_STRING_FROM_API: formConfiguration.consentCollectionSection.allCheckboxText]
                        Text(
                            text = fc?.consentCollectionSection?.allCheckboxText ?: "Check All",
                            style = TextStyle(
                                fontSize = 13.sp,
                                fontWeight = FontWeight.W600,
                                color = IobTheme.primaryBlue
                            )
                        )
                    }
                }

                // [DYNAMIC_STRING_FROM_API: formConfiguration.piiSection.dataPrincipalHeading.text]
                IobCategoryGroup(
                    categories = dataPrincipalCategories,
                    headingText = if (isMinorForm) fc?.piiSection?.dataPrincipalHeading?.text else null,
                    consentRevision = consentRevision,
                    showBadges = fc?.piiSection?.showBadges == true,
                    viewModel = viewModel
                )
                // [DYNAMIC_STRING_FROM_API: formConfiguration.piiSection.consentActorHeading.text]
                IobCategoryGroup(
                    categories = consentActorCategories,
                    headingText = if (isMinorForm) fc?.piiSection?.consentActorHeading?.text else null,
                    consentRevision = consentRevision,
                    showBadges = fc?.piiSection?.showBadges == true,
                    viewModel = viewModel
                )
            }

            // Footer with Privacy Policy Link
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // [DYNAMIC_STRING_FROM_API: formConfiguration.formFooter.description.text]
                fc?.formFooter?.description?.text?.let { footerText ->
                    if (looksLikeHtml(footerText)) {
                        HtmlText(html = footerText, modifier = Modifier.fillMaxWidth())
                    } else {
                        Text(
                            text = footerText,
                            style = IobTheme.bodyStyle,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IobPiiFieldsGroup(
    piiList: List<ConsentFormResponse.PiiLabel>,
    headingText: String?,
    mandatoryPiiIds: Set<String>,
    invalidPiiKeys: Set<String>,
    viewModel: ConsentFormViewModel
) {
    if (piiList.isEmpty()) return

    if (!headingText.isNullOrBlank()) {
        Text(
            text = headingText,
            style = IobTheme.headerStyle.copy(fontSize = 15.sp)
        )
        Spacer(modifier = Modifier.height(12.dp))
    }

    piiList.forEach { pii ->
        val piiId = Utils.safeId(pii.id) ?: return@forEach
        val piiName = pii.name ?: ""
        val piiContext = pii.principalContext ?: "DATA_PRINCIPAL"
        val piiKey = "${piiContext}_$piiId"
        val value = viewModel.piiValues[piiKey] ?: ""
        val isMandatory = mandatoryPiiIds.contains(piiId.toString())
        val isPhone = piiName.lowercase().contains("phone") || piiName.lowercase().contains("mobile")
        val isInvalid = piiKey in invalidPiiKeys

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            if (isPhone) {
                Box(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .background(IobTheme.surfaceBg, RoundedCornerShape(6.dp))
                        .border(1.dp, IobTheme.borderSubtle, RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 14.dp)
                ) {
                    // [DYNAMIC_STRING_FROM_API: Country dial code / International prefix format]
                    Text(
                        text = "+91",
                        style = TextStyle(
                            fontWeight = FontWeight.Bold,
                            color = IobTheme.primaryBlue,
                            fontSize = 14.sp
                        )
                    )
                }
            }

            OutlinedTextField(
                value = value,
                onValueChange = { viewModel.onPiiValueChanged(piiKey, it) },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    // [DYNAMIC_STRING_FROM_API: pii.name + (isSubjectIdentity ? ' *' : '')]
                    Text(
                        text = if (isMandatory) "$piiName *" else piiName,
                        style = TextStyle(color = IobTheme.textMuted, fontSize = 13.sp)
                    )
                },
                textStyle = TextStyle(
                    fontSize = 14.sp,
                    color = IobTheme.textDark,
                    fontWeight = FontWeight.W500
                ),
                shape = RoundedCornerShape(6.dp),
                isError = isInvalid,
                supportingText = if (isInvalid) {
                    { Text("This field is required", color = IobTheme.alertRed, fontSize = 12.sp) }
                } else null,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IobTheme.primaryBlue,
                    unfocusedBorderColor = IobTheme.borderSubtle
                ),
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (isPhone) KeyboardType.Phone else KeyboardType.Text
                ),
                singleLine = true
            )
        }
    }
}

@Composable
fun IobCategoryGroup(
    categories: List<ConsentFormResponse.Category>,
    headingText: String?,
    consentRevision: Int,
    showBadges: Boolean,
    viewModel: ConsentFormViewModel
) {
    if (categories.isEmpty()) return

    if (!headingText.isNullOrBlank()) {
        Text(
            text = headingText,
            style = IobTheme.headerStyle.copy(fontSize = 15.sp),
            modifier = Modifier.padding(vertical = 8.dp)
        )
    }

    categories.forEach { cat ->
        var isExpanded by remember { mutableStateOf(true) }

        Card(
            colors = CardDefaults.cardColors(containerColor = IobTheme.cardBg),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, IobTheme.borderSubtle),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 4.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isExpanded = !isExpanded }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // [DYNAMIC_STRING_FROM_API: categoryList.dataPrincipalCategoryList[].processingPurposeCategoryName]
                    Text(
                        text = cat.processingPurposeCategoryName ?: "",
                        style = IobTheme.subHeaderStyle.copy(color = IobTheme.primaryBlue)
                    )
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = IobTheme.primaryBlue
                    )
                }

                AnimatedVisibility(visible = isExpanded) {
                    Column {
                        cat.purposeList?.forEach purposeLoop@{ purpose ->
                            if (purpose.visible == false) return@purposeLoop
                            purpose.buckets?.forEach bucketLoop@{ bucket ->
                                if (bucket.visible == false) return@bucketLoop
                                HorizontalDivider(color = IobTheme.borderSubtle, thickness = 1.dp)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    val status = remember(consentRevision, bucket) { bucket.ctcpList?.firstOrNull()?.consentStatus == true }
                                    Checkbox(
                                        checked = status,
                                        onCheckedChange = { checked ->
                                            bucket.ctcpList?.forEach { it.consentStatus = checked }
                                            viewModel.syncCheckAllStatus()
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = IobTheme.primaryBlue)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            // compulsory_consent can be true on any entry of ct_cp_map_bucket
                                            // (one per pii label/process/vendor), not just the first
                                            if (bucket.ctcpList?.any { it.compulsoryConsent == true } == true) {
                                                Text(
                                                    text = "* ",
                                                    style = TextStyle(
                                                        color = IobTheme.alertRed,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                )
                                            }
                                            // [DYNAMIC_STRING_FROM_API: categoryList...buckets[].consentPurposeName]
                                            val purposeName = bucket.consentPurposeName ?: ""
                                            if (looksLikeHtml(purposeName)) {
                                                HtmlText(html = purposeName)
                                            } else {
                                                Text(
                                                    text = purposeName,
                                                    style = IobTheme.subHeaderStyle
                                                )
                                            }
                                        }
                                        // [DYNAMIC_STRING_FROM_API: categoryList...buckets[].consentPurposeDescription]
                                        val purposeDesc = bucket.consentPurposeDescription ?: ""
                                        if (purposeDesc.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            if (looksLikeHtml(purposeDesc)) {
                                                HtmlText(html = purposeDesc)
                                            } else {
                                                Text(
                                                    text = purposeDesc,
                                                    style = IobTheme.bodyStyle
                                                )
                                            }
                                        }
                                        // [DYNAMIC_STRING_FROM_API: categoryList...buckets[].piiLabels[]]
                                        val piiLabels = bucket.piiLabels ?: emptyList()
                                        if (showBadges && piiLabels.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                piiLabels.forEach { tag ->
                                                    Box(
                                                        modifier = Modifier
                                                            .background(IobTheme.surfaceBg, RoundedCornerShape(4.dp))
                                                            .border(
                                                                1.dp,
                                                                IobTheme.accentGold.copy(alpha = 0.6f),
                                                                RoundedCornerShape(4.dp)
                                                            )
                                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = tag,
                                                            style = TextStyle(
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.W600,
                                                                color = IobTheme.textDark
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        // [DYNAMIC_STRING_FROM_API: categoryList...buckets[].processes[]]
                                        val processes = bucket.processes ?: emptyList()
                                        if (processes.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                processes.forEach { tag ->
                                                    Box(
                                                        modifier = Modifier
                                                            .background(IobTheme.surfaceBg, RoundedCornerShape(4.dp))
                                                            .border(
                                                                1.dp,
                                                                IobTheme.primaryBlue.copy(alpha = 0.4f),
                                                                RoundedCornerShape(4.dp)
                                                            )
                                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = tag,
                                                            style = TextStyle(
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.W600,
                                                                color = IobTheme.textDark
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IobSubmitActionSection(
    viewModel: ConsentFormViewModel,
    fc: ConsentFormResponse.FormConfiguration?,
    isSubmitting: Boolean,
    onPrivacyPolicyClick: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val useDynamicButtons = shouldShowDynamicButtons(fc)
    val actionButtons = if (useDynamicButtons) fc?.actionButtons?.filter { it.enabled != false } else null
    var showExitDialog by remember { mutableStateOf(false) }
    val cm = fc?.confirmationModal

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            shape = RoundedCornerShape(12.dp),
            containerColor = IobTheme.cardBg,
            title = { Text(text = cm?.headingText ?: "", style = IobTheme.headerStyle) },
            text = { Text(text = cm?.bodyText ?: "", style = IobTheme.bodyStyle) },
            confirmButton = {
                TextButton(onClick = onClose) {
                    Text(
                        cm?.cancelSignupButton?.text ?: "Cancel",
                        color = Utils.hexToColor(cm?.cancelSignupButton?.textColor ?: "#C81D25")
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitDialog = false }) {
                    Text(
                        cm?.goBackButton?.text ?: "Go Back",
                        color = IobTheme.primaryBlue
                    )
                }
            }
        )
    }

    Surface(
        color = IobTheme.cardBg,
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            if (actionButtons.isNullOrEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    // [DYNAMIC_STRING_FROM_API: formConfiguration.form.showPrivacyPolicyUrl]
                    if (fc?.form?.showPrivacyPolicyUrl != false) {
                        OutlinedButton(
                            onClick = onPrivacyPolicyClick,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, IobTheme.primaryBlue),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            // [DYNAMIC_STRING_FROM_API: formConfiguration.form.privacyPolicyUrlText]
                            Text(
                                text = fc?.form?.privacyPolicyUrlText ?: "Privacy Notice",
                                style = TextStyle(
                                    color = IobTheme.primaryBlue,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            )
                        }
                    }

                    Button(
                        onClick = { viewModel.submit(context) },
                        enabled = !isSubmitting,
                        modifier = Modifier
                            .weight(2f)
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = IobTheme.primaryBlue),
                        shape = RoundedCornerShape(6.dp),
                        elevation = ButtonDefaults.buttonElevation(0.dp)
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            // [DYNAMIC_STRING_FROM_API: formConfiguration.submitButton.text]
                            Text(
                                text = fc?.submitButton?.text ?: "Accept & Submit",
                                style = TextStyle(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            )
                        }
                    }
                }
            } else {
                val hasPartialSelection by viewModel.hasPartialSelection.collectAsState()
                val visibleButtons = actionButtons.filter { action ->
                    action.handler?.lowercase() != "submit_current_selection" || hasPartialSelection
                }

                @Composable
                fun dynamicButton(action: ConsentFormResponse.ActionButton, modifier: Modifier) {
                    val handler = action.handler?.lowercase()
                    val onClick: () -> Unit = {
                        if (action.actsAsExitButton == true) {
                            showExitDialog = true
                        } else {
                            when (handler) {
                                "accept_all" -> viewModel.acceptAllAndSubmit(context)
                                "accept_all_mandatory" -> viewModel.acceptRequiredAndSubmit(context)
                                "nothing" -> viewModel.doNothing(context)
                                else -> viewModel.submit(context)
                            }
                        }
                    }
                    Button(
                        onClick = onClick,
                        enabled = !isSubmitting,
                        modifier = modifier.height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = action.color?.let { Utils.hexToColor(it) } ?: IobTheme.primaryBlue,
                            contentColor = action.textColor?.let { Utils.hexToColor(it) } ?: Color.White
                        ),
                        shape = getButtonShape(action.shape, action.borderRadius)
                    ) {
                        Text(action.text ?: action.handler ?: "Submit", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                if ((fc?.buttonOrientation ?: "horizontal").lowercase() == "vertical") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        visibleButtons.forEach { action -> dynamicButton(action, Modifier.fillMaxWidth()) }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        visibleButtons.forEach { action -> dynamicButton(action, Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@Composable
fun LanguageSelectorDropdown(
    languages: List<Map<String, String>>,
    selectedCode: String,
    onLanguageSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { expanded = true }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Language",
                    tint = Color.White,
                    modifier = Modifier.size(19.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = languages.firstOrNull { it["code"] == selectedCode }?.get("name") ?: "English",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.W500
                )
            }
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(IobTheme.primaryBlue)
        ) {
            languages.forEach { l ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = l["name"] ?: "",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.W500
                        )
                    },
                    onClick = {
                        l["code"]?.let { onLanguageSelected(it) }
                        expanded = false
                    }
                )
            }
        }
    }
}

// ============================================================================
// 4. SCREEN B: PRIVACY NOTICE SCREEN
// ============================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IobPrivacyNoticeScreen(
    initialLanguage: String = "en",
    availableLanguages: List<Map<String, String>> = listOf(
        mapOf("code" to "en", "name" to "English"),
        mapOf("code" to "hi", "name" to "हिंदी"),
        mapOf("code" to "ta", "name" to "தமிழ்")
    ),
    showCrossButton: Boolean = true,
    viaConsentScreen: Boolean = false,
    onAgreeAndContinue: ((Map<String, Any?>) -> Unit)? = null,
    onClose: (() -> Unit)? = null
) {
    var lang by remember { mutableStateOf(initialLanguage) }
    var enableAgreeButton by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf("") }

    // [DYNAMIC_STRING_FROM_API: GET /api/v1/privacy-notice/... -> response.result.data[0].content[]]
    val sections = remember {
        listOf(
            StaticPrivacySection(
                id = 9901,
                version = "v2026.1",
                // [DYNAMIC_STRING_FROM_API: privacyData.content[0].title]
                title = "1. Regulatory Commitment",
                // [DYNAMIC_STRING_FROM_API: privacyData.content[0].content]
                contentHtml = "<p>Indian Overseas Bank (IOB) protects your personal and financial information per DPDP Act 2023 and RBI guidelines.</p>"
            ),
            StaticPrivacySection(
                id = 9901,
                version = "v2026.1",
                // [DYNAMIC_STRING_FROM_API: privacyData.content[1].title]
                title = "2. Personal & Financial Information Collected",
                // [DYNAMIC_STRING_FROM_API: privacyData.content[1].content]
                contentHtml = "<p>We collect identity parameters including Full Name, PAN, contact parameters, and geolocation attributes.</p>"
            ),
            StaticPrivacySection(
                id = 9901,
                version = "v2026.1",
                // [DYNAMIC_STRING_FROM_API: privacyData.content[2].title]
                title = "3. Purposes of Data Processing",
                // [DYNAMIC_STRING_FROM_API: privacyData.content[2].content]
                contentHtml = "<p>Your personal information is strictly processed for financial transactions, fraud monitoring, and statutory compliance.</p>"
            )
        )
    }

    val listState = rememberLazyListState()

    LaunchedEffect(listState) {
        snapshotFlow { listState.layoutInfo }
            .collect { info ->
                if (info.totalItemsCount > 0 && !listState.canScrollForward) {
                    enableAgreeButton = true
                    errorText = ""
                }
            }
    }

    fun handleAgreeAndContinue() {
        val result = mapOf(
            "language_consented_to" to lang,
            "consented_privacy_notice_id" to (sections.firstOrNull()?.id ?: 9901),
            "consented_privacy_notice_version" to (sections.firstOrNull()?.version ?: "v2026.1"),
            "reviewed_privacy_notice" to true
        )
        onAgreeAndContinue?.invoke(result)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = IobTheme.primaryBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                ),
                navigationIcon = {
                    if (showCrossButton) {
                        IconButton(onClick = { onClose?.invoke() }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // [DYNAMIC_STRING_FROM_API: formConfiguration.form.logo.logoText or Organization Short Code]
                        Surface(
                            color = IobTheme.accentGold,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(vertical = 3.dp)
                        ) {
                            Text(
                                text = "IOB",
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.W900,
                                    color = IobTheme.primaryBlue
                                )
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        // [DYNAMIC_STRING_FROM_API: formConfiguration.form.privacyPolicyUrlText or "Privacy Notice"]
                        Text(
                            text = "Privacy Notice",
                            style = TextStyle(
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                },
                actions = {
                    LanguageSelectorDropdown(
                        languages = availableLanguages,
                        selectedCode = lang,
                        onLanguageSelected = { lang = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
            )
        },
        containerColor = IobTheme.surfaceBg,
        bottomBar = {
            Surface(
                color = IobTheme.cardBg,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(
                        onClick = {
                            if (enableAgreeButton) {
                                handleAgreeAndContinue()
                            } else {
                                // [DYNAMIC_STRING_FROM_API: Localization/Validation error text]
                                errorText = "Please scroll to the bottom to finish reading the complete privacy notice."
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (enableAgreeButton) IobTheme.primaryBlue else IobTheme.primaryBlue.copy(alpha = 0.35f)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        elevation = ButtonDefaults.buttonElevation(0.dp)
                    ) {
                        // [DYNAMIC_STRING_FROM_API: Localization resource: 'Agree & Continue']
                        Text(
                            text = "Agree & Continue",
                            style = TextStyle(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        )
                    }

                    if (errorText.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorText,
                            style = TextStyle(
                                color = IobTheme.alertRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.W500
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(sections) { sec ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = IobTheme.cardBg),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, IobTheme.borderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // [DYNAMIC_STRING_FROM_API: privacyData.content[index].title]
                        Text(
                            text = sec.title,
                            style = IobTheme.headerStyle.copy(
                                fontSize = 15.sp,
                                color = IobTheme.primaryBlue
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        // [DYNAMIC_STRING_FROM_API: privacyData.content[index].content]
                        HtmlText(html = sec.contentHtml)
                    }
                }
            }
        }
    }
}
