package com.tekhsters.gotrustsdkandroid.features.preferencecenter.services

import com.google.gson.annotations.SerializedName
import com.tekhsters.gotrustsdkandroid.features.consentform.models.CallBackResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.DigiLockerResponse
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.EncryptedRequestEnvelope
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ImageDownloadResponse
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.LoginConfigRequest
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.PublicKeyRequest
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.PublicKeyResponse
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface PreferenceCenterApi {

    @POST("universal/public/api/v4/translator/language-codes")
    suspend fun fetchLanguages(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("universal/public/api/v2/pc/identity/ask")
    suspend fun fetchLoginConfig(
        @Body envelope: EncryptedRequestEnvelope,
    ): Response<ResponseBody>

    @POST("universal/public/api/v5/pc/otp/send")
    suspend fun sendOtp(
        @Body envelope:EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("universal/public/api/v5/pc/otp/verify")
    suspend fun verifyOtp(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("universal/public/api/v7/pc/display")
    @Headers("Content-Type: application/json")
    suspend fun fetchDashboardData(
        @Body envelope:EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("universal/public/api/v4/data-collector/pc-records")
    suspend fun saveDashboardPreferences(
        @Header("x-consent-evidence-token") evidenceToken: String?,
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("backend/api/public/download")
    suspend fun fetchImageUrl(
        @Body payload: @JvmSuppressWildcards Map<String, Any?>
    ): Response<ImageDownloadResponse>

    @POST("universal/public/api/v3/security/entrypoint")
    suspend fun getCustomerAndPreferenceId(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @POST("universal/public/api/v4/digilocker/login")
    suspend fun getDigiLockerResponse(
        @Body envelope: EncryptedRequestEnvelope,
    ): Response<ResponseBody>

    @POST("universal/public/api/v4/digilocker/callback")
    suspend fun getCallbackApiResponse(
        @Body envelope: EncryptedRequestEnvelope,
    ): Response<ResponseBody>

    @Headers("Content-Type: application/json")
    @POST("universal/public/api/v5/subject-consent-manager/consent-info/graph")
    suspend fun getConsentFlow(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>

    @Headers("accept: application/json")
    @POST("universal/public/api/v1/security/auth/public-key")
    suspend fun getPublicKey(
        @Body request: PublicKeyRequest
    ): Response<PublicKeyResponse>

    @POST("universal/public/api/v5/subject-consent-manager/consent-info/per-principals")
    suspend fun fetchConsentAuditLogs(
        @Body envelope: EncryptedRequestEnvelope
    ): Response<ResponseBody>
}

data class LanguageRequestBody(
    @SerializedName("mode") val mode: String = "preference_center",
    @SerializedName("customer_id") val customerId: Any,
    @SerializedName("preference_center_id") val preferenceCenterId: Any
)

data class DigiLockerLoginRequest(
    @SerializedName("redirect_uri") val redirectUri: String
)

data class DigiLockerCallbackRequest(
    @SerializedName("code") val code: String,
    @SerializedName("state") val state: String
)

data class ConsentAuditLogsRequest(
    @SerializedName("customer_id") val customerId: Any ,
    @SerializedName("data_principal_ids") val dataPrincipalId: String,
    @SerializedName("detailed") val detailed: Boolean = true,
    @SerializedName("unified_person_enabled") val unifiedPersonEnabled: Boolean = true,
    @SerializedName("page_number") val pageNumber: Int,
    @SerializedName("page_size") val pageSize: Int = 10
)
