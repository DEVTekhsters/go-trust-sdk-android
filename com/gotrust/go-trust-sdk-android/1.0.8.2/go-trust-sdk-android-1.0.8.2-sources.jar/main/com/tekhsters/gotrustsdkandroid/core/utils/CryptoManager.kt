package com.tekhsters.gotrustsdkandroid.core.utils

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.annotation.RequiresApi
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.UnrecoverableKeyException
import java.security.spec.MGF1ParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec

sealed class CryptoException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class InvalidBase64Url(cause: Throwable? = null) : CryptoException("Invalid Base64URL input", cause)
    class InvalidPublicKey(cause: Throwable) : CryptoException("Invalid or undersized RSA public key", cause)
    class RsaFailure(cause: Throwable) : CryptoException("RSA operation failed", cause)
    class AesAuthFailure(cause: Throwable) : CryptoException("AES-GCM authentication failed (bad tag/ciphertext)", cause)
    class AesFailure(cause: Throwable) : CryptoException("AES-GCM operation failed", cause)
}

object CryptoManager {

    const val REQUEST_NONCE_PREFIX: Byte = 0
    const val RESPONSE_NONCE_PREFIX: Byte = 1

    private const val AES_KEY_SIZE_BYTES = 32
    private const val GCM_IV_SIZE_BYTES = 12
    private const val GCM_TAG_SIZE_BYTES = 16
    private const val GCM_TAG_SIZE_BITS = GCM_TAG_SIZE_BYTES * 8
    private const val MIN_RSA_KEY_SIZE_BITS = 2048
    private const val ANDROID_KEYSTORE_PROVIDER = "AndroidKeyStore"

    private const val RSA_KEY_ALIAS = "gotrust_rsa_key_v2"

    private const val AES_WRAP_KEY_ALIAS = "gotrust_aes_wrap_key_v2"
    private const val PREFS_NAME = "gotrust_crypto_prefs"
    private const val PREF_PUBLIC_KEY = "rsa_pub"
    private const val PREF_PRIVATE_KEY_CIPHERTEXT = "rsa_priv_ct"
    private const val PREF_PRIVATE_KEY_IV = "rsa_priv_iv"

    private val secureRandom = SecureRandom()
    private val rsaKeyLock = Any()

    @Volatile
    private var softwareKeyPair: KeyPair? = null

    object Base64Url {
        fun encode(bytes: ByteArray): String {
            return android.util.Base64.encodeToString(
                bytes,
                android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING
            )
        }

        fun decode(s: String): ByteArray {
            return try {
                android.util.Base64.decode(s, android.util.Base64.URL_SAFE)
            } catch (e: Exception) {
                throw CryptoException.InvalidBase64Url(e)
            }
        }
    }

    /**
     * Pass `context` to ensure keys on Android 14 and below persist across app restarts securely.
     */
    @JvmOverloads
    fun getOrCreateRsaKeyPair(context: Context? = null): KeyPair = synchronized(rsaKeyLock) {
        try {
            // 1. Android 15+ (API 35+): Hardware Keystore natively supports MGF1-SHA256
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
                try {
                    val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE_PROVIDER).apply { load(null) }
                    val pair = loadExistingKeyPair(keyStore) ?: generateKeystoreKeyPair()
                    if (isHardwareMgf1Sha256Supported(pair.private)) {
                        return@synchronized pair
                    } else {
                        if (keyStore.containsAlias(RSA_KEY_ALIAS)) {
                            keyStore.deleteEntry(RSA_KEY_ALIAS)
                        }
                    }
                } catch (e: Exception) {
                    // Fallback to software wrapper on unexpected hardware fault
                }
            }

            // 2. Fallback for Android 14 (API 34) and below
            // Hardware Keystore ONLY supports MGF1-SHA1 before API 35.
            softwareKeyPair?.let { return@synchronized it }

            if (context != null) {
                loadOrGenerateWrappedSoftwareKeyPair(context.applicationContext).also {
                    softwareKeyPair = it
                }
            } else {
                generatePureSoftwareKeyPair().also {
                    softwareKeyPair = it
                }
            }
        } catch (e: CryptoException) {
            throw e
        } catch (e: Exception) {
            throw CryptoException.RsaFailure(e)
        }
    }

    @RequiresApi(Build.VERSION_CODES.VANILLA_ICE_CREAM)
    private fun generateKeystoreKeyPair(): KeyPair {
        val spec = KeyGenParameterSpec.Builder(
            RSA_KEY_ALIAS,
            KeyProperties.PURPOSE_DECRYPT or KeyProperties.PURPOSE_ENCRYPT
        )
            .setKeySize(MIN_RSA_KEY_SIZE_BITS)
            .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA1)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
            .setMgf1Digests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA1)
            .build()

        val kpg = KeyPairGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_RSA,
            ANDROID_KEYSTORE_PROVIDER
        )
        kpg.initialize(spec)
        return kpg.generateKeyPair()
    }

    private fun isHardwareMgf1Sha256Supported(privateKey: PrivateKey): Boolean {
        return try {
            val cipher = Cipher.getInstance("RSA/ECB/OAEPPadding")
            val spec = OAEPParameterSpec(
                "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT
            )
            cipher.init(Cipher.DECRYPT_MODE, privateKey, spec)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun generatePureSoftwareKeyPair(): KeyPair {
        return KeyPairGenerator.getInstance("RSA")
            .apply { initialize(MIN_RSA_KEY_SIZE_BITS, secureRandom) }
            .generateKeyPair()
    }

    private fun loadExistingKeyPair(keyStore: KeyStore): KeyPair? {
        if (!keyStore.containsAlias(RSA_KEY_ALIAS)) return null
        return try {
            val privateKey = keyStore.getKey(RSA_KEY_ALIAS, null) as? PrivateKey
            val publicKey = keyStore.getCertificate(RSA_KEY_ALIAS)?.publicKey
            if (privateKey != null && publicKey != null) {
                KeyPair(publicKey, privateKey)
            } else {
                keyStore.deleteEntry(RSA_KEY_ALIAS)
                null
            }
        } catch (e: UnrecoverableKeyException) {
            keyStore.deleteEntry(RSA_KEY_ALIAS)
            null
        }
    }

    private fun loadOrGenerateWrappedSoftwareKeyPair(context: Context): KeyPair {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val pubB64 = prefs.getString(PREF_PUBLIC_KEY, null)
        val privCtB64 = prefs.getString(PREF_PRIVATE_KEY_CIPHERTEXT, null)
        val privIvB64 = prefs.getString(PREF_PRIVATE_KEY_IV, null)

        val aesWrapKey = getOrCreateHardwareAesWrapKey()

        if (pubB64 != null && privCtB64 != null && privIvB64 != null) {
            try {
                val pubBytes = Base64Url.decode(pubB64)
                val privCt = Base64Url.decode(privCtB64)
                val privIv = Base64Url.decode(privIvB64)

                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, aesWrapKey, GCMParameterSpec(GCM_TAG_SIZE_BITS, privIv))
                val pkcs8Bytes = cipher.doFinal(privCt)

                val kf = KeyFactory.getInstance("RSA")
                val publicKey = kf.generatePublic(X509EncodedKeySpec(pubBytes))
                val privateKey = kf.generatePrivate(PKCS8EncodedKeySpec(pkcs8Bytes))
                return KeyPair(publicKey, privateKey)
            } catch (_: Exception) {
                prefs.edit().clear().apply()
            }
        }

        val newKeyPair = generatePureSoftwareKeyPair()
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, aesWrapKey)
            val wrappedPrivBytes = cipher.doFinal(newKeyPair.private.encoded)
            val iv = cipher.iv

            prefs.edit()
                .putString(PREF_PUBLIC_KEY, Base64Url.encode(newKeyPair.public.encoded))
                .putString(PREF_PRIVATE_KEY_CIPHERTEXT, Base64Url.encode(wrappedPrivBytes))
                .putString(PREF_PRIVATE_KEY_IV, Base64Url.encode(iv))
                .apply()
        } catch (_: Exception) {
        }

        return newKeyPair
    }

    private fun getOrCreateHardwareAesWrapKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE_PROVIDER).apply { load(null) }
        (keyStore.getKey(AES_WRAP_KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val spec = KeyGenParameterSpec.Builder(
            AES_WRAP_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setKeySize(256)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build()

        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE_PROVIDER)
        kg.init(spec)
        return kg.generateKey()
    }

    @JvmOverloads
    fun resetRsaKeyPairInKeystore(context: Context? = null) = synchronized(rsaKeyLock) {
        softwareKeyPair = null
        try {
            context?.applicationContext
                ?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                ?.edit()
                ?.clear()
                ?.apply()
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE_PROVIDER).apply { load(null) }
            if (keyStore.containsAlias(RSA_KEY_ALIAS)) keyStore.deleteEntry(RSA_KEY_ALIAS)
            if (keyStore.containsAlias(AES_WRAP_KEY_ALIAS)) keyStore.deleteEntry(AES_WRAP_KEY_ALIAS)
        } catch (_: Exception) {
        }
    }

    fun decryptRsaOaep256(privateKey: PrivateKey, encryptedBytes: ByteArray): ByteArray {
        return try {
            val cipher = Cipher.getInstance("RSA/ECB/OAEPPadding")
            val spec = OAEPParameterSpec(
                "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT
            )
            cipher.init(Cipher.DECRYPT_MODE, privateKey, spec)
            cipher.doFinal(encryptedBytes)
        } catch (e: Exception) {
            throw CryptoException.RsaFailure(e)
        }
    }

    fun exportPublicKeyToPem(publicKey: PublicKey): String {
        val encoded = android.util.Base64.encodeToString(
            publicKey.encoded,
            android.util.Base64.NO_WRAP
        )
        return "-----BEGIN PUBLIC KEY-----\n$encoded\n-----END PUBLIC KEY-----\n"
    }

    fun generateIv(): ByteArray = ByteArray(GCM_IV_SIZE_BYTES).also { secureRandom.nextBytes(it) }

    fun generateRequestIv(): ByteArray = generateIv().also { it[0] = REQUEST_NONCE_PREFIX }

    fun generateResponseIv(): ByteArray = generateIv().also { it[0] = RESPONSE_NONCE_PREFIX }

    fun buildAad(
        version: Int = 1,
        sessionId: String,
        timestamp: Long,
        httpMethod: String,
        backendPath: String,
        direction: String,
        requestTag: String = ""
    ): ByteArray {
        require(direction == "request" || direction == "response") {
            "direction must be \"request\" or \"response\", got \"$direction\""
        }
        val escapedSessionId = escapeJsonString(sessionId)
        val escapedPath = escapeJsonString(backendPath)
        val escapedRequestTag = escapeJsonString(requestTag)
        val method = httpMethod.uppercase()
        val json = "[$version,\"$escapedSessionId\",$timestamp,\"$method\",\"$escapedPath\",\"$direction\",\"$escapedRequestTag\"]"
        return json.toByteArray(Charsets.UTF_8)
    }

    private fun escapeJsonString(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            when (c) {
                '\\' -> sb.append("\\\\")
                '"' -> sb.append("\\\"")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c.code < 0x20) {
                    sb.append("\\u%04x".format(c.code))
                } else {
                    sb.append(c)
                }
            }
        }
        return sb.toString()
    }

    fun encryptAesGcm(aesKey: ByteArray, iv: ByteArray, aad: ByteArray, plainText: ByteArray): Pair<ByteArray, ByteArray> {
        require(aesKey.size == AES_KEY_SIZE_BYTES) { "AES key must be $AES_KEY_SIZE_BYTES bytes" }
        require(iv.size == GCM_IV_SIZE_BYTES) { "GCM IV must be $GCM_IV_SIZE_BYTES bytes" }
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val gcmSpec = GCMParameterSpec(GCM_TAG_SIZE_BITS, iv)
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(aesKey, "AES"), gcmSpec)
            cipher.updateAAD(aad)
            val encryptedWithTag = cipher.doFinal(plainText)
            val ciphertext = encryptedWithTag.copyOfRange(0, encryptedWithTag.size - GCM_TAG_SIZE_BYTES)
            val tag = encryptedWithTag.copyOfRange(encryptedWithTag.size - GCM_TAG_SIZE_BYTES, encryptedWithTag.size)
            Pair(ciphertext, tag)
        } catch (e: Exception) {
            throw CryptoException.AesFailure(e)
        }
    }

    fun decryptAesGcm(aesKey: ByteArray, iv: ByteArray, aad: ByteArray, ciphertext: ByteArray, tag: ByteArray): ByteArray {
        require(aesKey.size == AES_KEY_SIZE_BYTES) { "AES key must be $AES_KEY_SIZE_BYTES bytes" }
        require(iv.size == GCM_IV_SIZE_BYTES) { "GCM IV must be $GCM_IV_SIZE_BYTES bytes" }
        require(tag.size == GCM_TAG_SIZE_BYTES) { "GCM tag must be $GCM_TAG_SIZE_BYTES bytes" }
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val gcmSpec = GCMParameterSpec(GCM_TAG_SIZE_BITS, iv)
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(aesKey, "AES"), gcmSpec)
            cipher.updateAAD(aad)
            cipher.doFinal(ciphertext + tag)
        } catch (e: AEADBadTagException) {
            throw CryptoException.AesAuthFailure(e)
        } catch (e: Exception) {
            throw CryptoException.AesFailure(e)
        }
    }
}