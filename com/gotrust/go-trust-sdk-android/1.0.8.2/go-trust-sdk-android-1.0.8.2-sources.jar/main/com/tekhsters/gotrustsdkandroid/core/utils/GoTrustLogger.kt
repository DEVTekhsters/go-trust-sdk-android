package com.tekhsters.gotrustsdkandroid.core.utils

import android.content.Context
import android.content.pm.ApplicationInfo
import android.util.Log

/**
 * SDK-wide logger. Silent unless the host app is debuggable, so release builds of the host
 * print nothing (a library's own BuildConfig.DEBUG can't tell, it is fixed at AAR build time).
 */
object GoTrustLogger {
    @Volatile
    private var enabled = false

    fun init(context: Context) {
        enabled = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }

    fun d(tag: String, msg: String) { if (enabled) Log.d(tag, msg) }
    fun i(tag: String, msg: String) { if (enabled) Log.i(tag, msg) }
    fun v(tag: String, msg: String) { if (enabled) Log.v(tag, msg) }
    fun w(tag: String, msg: String, tr: Throwable? = null) { if (enabled) Log.w(tag, msg, tr) }
    fun e(tag: String, msg: String, tr: Throwable? = null) { if (enabled) Log.e(tag, msg, tr) }
}
