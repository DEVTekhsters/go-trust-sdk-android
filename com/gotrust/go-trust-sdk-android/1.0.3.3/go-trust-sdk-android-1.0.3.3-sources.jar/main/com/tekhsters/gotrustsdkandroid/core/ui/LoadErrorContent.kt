package com.tekhsters.gotrustsdkandroid.core.ui


import android.graphics.Typeface
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.ButtonTheme
import com.tekhsters.gotrustsdkandroid.ErrorTheme
import com.tekhsters.gotrustsdkandroid.Orientation
import com.tekhsters.gotrustsdkandroid.TextAlignment
import com.tekhsters.gotrustsdkandroid.TextTheme
import com.tekhsters.gotrustsdkandroid.VerticalAlignment
import com.tekhsters.gotrustsdkandroid.toColorOrDefault


fun String?.toComposeColor(default: String): Color =
    Color(this.toColorOrDefault(default))

/** Centered, padded error state shared by the consent form and preference center. */
@Composable
fun LoadErrorContent(
    onRetry: () -> Unit,
    onClose: () -> Unit,
//    message: String? = null,
    errorTheme: ErrorTheme = ErrorTheme(),
) {
    val backgroundColor = errorTheme.backgroundColor.toComposeColor("#FEF7FF")

    val verticalAlignmentSpec = when (errorTheme.verticalAlignment) {
        VerticalAlignment.TOP -> Alignment.Top
        VerticalAlignment.CENTER -> Alignment.CenterVertically
        VerticalAlignment.BOTTOM -> Alignment.Bottom
    }

    val columnHorizontalAlignment = when (errorTheme.title.alignment) {
        TextAlignment.START -> Alignment.Start
        TextAlignment.CENTER -> Alignment.CenterHorizontally
        TextAlignment.END -> Alignment.End
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(
                horizontal = errorTheme.horizontalPadding.dp,
                vertical = errorTheme.verticalPadding.dp
            ),
        horizontalAlignment = columnHorizontalAlignment,
        verticalArrangement = Arrangement.spacedBy(
            space = errorTheme.itemSpacing.dp,
            alignment = verticalAlignmentSpec
        ),
    ) {
        val icon = errorTheme.icon
        if (icon.visible) {
            val iconModifier = Modifier.size(icon.size.dp)
            val tintFilter = icon.tintColor?.let {
                ColorFilter.tint(it.toComposeColor("#000000"))
            }

            if (icon.resId != null) {
                Image(
                    painter = painterResource(id = icon.resId),
                    contentDescription = "Error Icon",
                    modifier = iconModifier,
                    colorFilter = tintFilter
                )
            } else if (!icon.url.isNullOrEmpty()) {
                AsyncImage(
                    model = icon.url,
                    contentDescription = "Error Icon",
                    modifier = iconModifier,
                    colorFilter = tintFilter
                )
            }
        }

        val titleText = errorTheme.title.text ?: ""
        if (titleText.isNotBlank()) {
            DynamicText(
                textTheme = errorTheme.title,
                defaultText = titleText,
                defaultColor = "#1D1B20"
            )
        }

        val descText = errorTheme.description.text ?:""
        if (descText.isNotBlank()) {
            DynamicText(
                textTheme = errorTheme.description,
                defaultText = descText,
                defaultColor = "#49454F"
            )
        }

        val showPrimary = errorTheme.showRetry && errorTheme.primaryButton.visible
        val showSecondary = errorTheme.showGoBack && errorTheme.secondaryButton.visible

        if (showPrimary || showSecondary) {
            val buttonsAlignment = when (errorTheme.buttonsAlignment) {
                TextAlignment.START -> Alignment.Start
                TextAlignment.CENTER -> Alignment.CenterHorizontally
                TextAlignment.END -> Alignment.End
            }

            if (errorTheme.buttonsOrientation == Orientation.VERTICAL) {
                Column(
                    modifier = if (errorTheme.buttonsFillWidth) Modifier.fillMaxWidth() else Modifier.wrapContentWidth(),
                    horizontalAlignment = buttonsAlignment,
                    verticalArrangement = Arrangement.spacedBy(errorTheme.buttonSpacing.dp)
                ) {
                    if (showPrimary) {
                        DynamicButton(
                            buttonTheme = errorTheme.primaryButton,
                            onClick = onRetry,
                            fillWidth = errorTheme.buttonsFillWidth
                        )
                    }
                    if (showSecondary) {
                        DynamicButton(
                            buttonTheme = errorTheme.secondaryButton,
                            onClick = onClose,
                            fillWidth = errorTheme.buttonsFillWidth
                        )
                    }
                }
            } else {
                val rowHorizontalAlignment = when (errorTheme.buttonsAlignment) {
                    TextAlignment.START -> Alignment.Start
                    TextAlignment.CENTER -> Alignment.CenterHorizontally
                    TextAlignment.END -> Alignment.End
                }

                Row(
                    modifier = if (errorTheme.buttonsFillWidth) Modifier.fillMaxWidth() else Modifier.wrapContentWidth(),
                    horizontalArrangement = Arrangement.spacedBy(
                        space = errorTheme.buttonSpacing.dp,
                        alignment = rowHorizontalAlignment
                    ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (showPrimary) {
                        DynamicButton(
                            buttonTheme = errorTheme.primaryButton,
                            onClick = onRetry,
                            fillWidth = errorTheme.buttonsFillWidth,
                            modifier = if (errorTheme.buttonsFillWidth && showSecondary) Modifier.weight(1f) else Modifier
                        )
                    }
                    if (showSecondary) {
                        DynamicButton(
                            buttonTheme = errorTheme.secondaryButton,
                            onClick = onClose,
                            fillWidth = errorTheme.buttonsFillWidth,
                            modifier = if (errorTheme.buttonsFillWidth && showPrimary) Modifier.weight(1f) else Modifier
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DynamicText(
    textTheme: TextTheme,
    defaultText: String,
    defaultColor: String
) {
    val textToDisplay = textTheme.text.takeIf { !it.isNullOrBlank() } ?: defaultText
    if (textToDisplay.isBlank()) return

    val textAlign = when (textTheme.alignment) {
        TextAlignment.START -> TextAlign.Start
        TextAlignment.CENTER -> TextAlign.Center
        TextAlignment.END -> TextAlign.End
    }

    val fontFamily = textTheme.fontFamily?.let {
        FontFamily(Typeface.create(it, Typeface.NORMAL))
    } ?: FontFamily.Default

    val fontWeight = FontWeight(textTheme.fontWeight.coerceIn(100, 900))
    val fontStyle = if (textTheme.italic) FontStyle.Italic else FontStyle.Normal

    Text(
        text = textToDisplay,
        color = textTheme.color.toComposeColor(defaultColor),
        fontSize = textTheme.fontSize.sp,
        fontWeight = fontWeight,
        fontStyle = fontStyle,
        fontFamily = fontFamily,
        textAlign = textAlign,
        letterSpacing = textTheme.letterSpacing.em,
        lineHeight = textTheme.lineHeight?.sp ?: TextUnit.Unspecified,
        maxLines = textTheme.maxLines ?: Int.MAX_VALUE,
        overflow = if (textTheme.maxLines != null) TextOverflow.Ellipsis else TextOverflow.Clip,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun DynamicButton(
    buttonTheme: ButtonTheme,
    onClick: () -> Unit,
    fillWidth: Boolean,
    modifier: Modifier = Modifier
) {
    val backgroundColor = buttonTheme.backgroundColor.toComposeColor("#6750A4")
    val textColor = buttonTheme.textColor.toComposeColor("#FFFFFF")
    val shape = RoundedCornerShape(buttonTheme.cornerRadius.dp)

    val hasBorder = !buttonTheme.borderColor.isNullOrEmpty() && (buttonTheme.borderWidth > 0f)
    val border = if (hasBorder) {
        BorderStroke(
            width = buttonTheme.borderWidth.dp,
            color = buttonTheme.borderColor.toComposeColor("#6750A4")
        )
    } else null

    val fontFamily = buttonTheme.fontFamily?.let {
        FontFamily(Typeface.create(it, Typeface.NORMAL))
    } ?: FontFamily.Default

    val fontWeight = FontWeight(buttonTheme.fontWeight.coerceIn(100, 900))

    val baseModifier = if (fillWidth) Modifier.fillMaxWidth() else Modifier.wrapContentWidth()
    val finalModifier = modifier
        .then(baseModifier)
        .heightIn(min = buttonTheme.height.dp)

    Button(
        onClick = onClick,
        modifier = finalModifier,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor,
            contentColor = textColor
        ),
        border = border,
        elevation = ButtonDefaults.buttonElevation(defaultElevation = buttonTheme.elevation.dp),
        contentPadding = PaddingValues(
            horizontal = buttonTheme.horizontalPadding.dp,
            vertical = 8.dp
        )
    ) {
        Text(
            text = buttonTheme.text,
            color = textColor,
            fontSize = buttonTheme.fontSize.sp,
            fontWeight = fontWeight,
            fontFamily = fontFamily,
            textAlign = TextAlign.Center
        )
    }
}
