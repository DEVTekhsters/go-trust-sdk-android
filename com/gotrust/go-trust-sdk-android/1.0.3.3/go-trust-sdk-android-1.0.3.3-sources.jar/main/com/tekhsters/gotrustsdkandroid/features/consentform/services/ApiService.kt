package com.tekhsters.gotrustsdkandroid.features.consentform.services

import android.util.Log
import com.tekhsters.gotrustsdkandroid.FallbackConfig
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.features.consentform.models.*
import okhttp3.Headers
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class ApiService private constructor() {

    private var baseUrl: String = ""
    private var publicToken: String? = null
    // Host-supplied bearer token (ConsentFormConfig.authToken). Read by the interceptor at
    // request time rather than captured, so setting it after setBaseUrl() still takes effect —
    // setBaseUrl() early-returns for an unchanged url and would not rebuild the client.
    private var authToken: String? = null
    private var resolvedSourceId: Any? = null
    private var consentEvidenceToken: String? = null

    var verifyUseFallback = false


    var sendSubjectIdentityTypes = false

    var verifySuccess = true
    private var api: ConsentFormApi? = null

    // Host-provided proxy this session falls back to once GoTrust's primary display/submit APIs
    // start failing. Once _useFallback flips true it stays true for the rest of this ApiService
    // session — set again (and reset) on every setFallback() call, i.e. every new consent form.
    private var fallback: FallbackConfig? = null
    private val fallbackHeaders = mutableMapOf<String, String>()
    // Tracked alongside fallbackHeaders[csrfHeaderName] rather than read from it, so the two
    // can never drift: this is the token as the SDK last received it from refreshCsrfToken(),
    // fallbackHeaders holds what actually goes out on the wire.
    private var fallbackCsrfToken: String? = null
    private var useFallback = false
    val isFallbackActive: Boolean get() = useFallback

    private val fallbackHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY })
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    companion object {
        private const val TAG = "ApiService"
        // A 401/403 on a fallback call triggers a refresh + retry; if the freshly refreshed
        // token is rejected too, refresh again up to this many times before giving up.
        private const val MAX_CSRF_REFRESH_ATTEMPTS = 2
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        val instance: ApiService by lazy { ApiService() }
    }

    /** Host-supplied bearer token; `null` or empty clears it for this session. */
    fun setAuthToken(token: String?) {
        authToken = token
    }

    fun setFallback(fallback: FallbackConfig?) {
        this.fallback = fallback
        fallbackHeaders.clear()
        fallbackHeaders.putAll(fallback?.headers ?: emptyMap())
        fallbackCsrfToken = null
        useFallback = false
    }

    private data class FallbackHttpResult(val statusCode: Int?, val body: String?, val headers: Headers?)

    private fun updateCookieHeaderValue(cookieHeader: String?, cookieName: String, newValue: String): String {
        val pairs = (cookieHeader ?: "").split(";").map { it.trim() }.filter { it.isNotEmpty() }
        var found = false
        val updated = pairs.map { pair ->
            val eq = pair.indexOf('=')
            val key = (if (eq == -1) pair else pair.substring(0, eq)).trim()
            if (key == cookieName) {
                found = true
                "$cookieName=$newValue"
            } else pair
        }.toMutableList()
        if (!found) updated.add("$cookieName=$newValue")
        return updated.joinToString("; ")
    }

    private fun doFallbackPost(url: String, bodyJson: String): FallbackHttpResult {
        return try {
            Log.d("Fallback", "doFallbackPost: sending POST to $url")
            Log.d("Fallback", "Request headers = ${fallbackHeaders.keys}")
            val requestBuilder = Request.Builder().url(url).header("Content-Type", "application/json")
            fallbackHeaders.forEach { (k, v) -> requestBuilder.header(k, v) }
            val request = requestBuilder.post(bodyJson.toRequestBody(JSON_MEDIA_TYPE)).build()
            fallbackHttpClient.newCall(request).execute().use { response ->
                Log.d("Fallback", "doFallbackPost: $url returned status = ${response.code}")
                FallbackHttpResult(response.code, response.body?.string(), response.headers)
            }
        } catch (e: Exception) {
            Log.e("Fallback", "doFallbackPost to $url failed: ${e.message}", e)
            FallbackHttpResult(null, null, null)
        }
    }

    private suspend fun fallbackPostWithRetry(url: String, payload: Map<String, Any?>): FallbackHttpResult =
        withContext(Dispatchers.IO) {
            val bodyJson = GsonProvider.gson.toJson(payload)
            Log.d("Fallback", "fallbackPostWithRetry: starting POST to $url")
            var result = doFallbackPost(url, bodyJson)
            var refreshAttempts = 0
            while ((result.statusCode == 401 || result.statusCode == 403) &&
                fallback != null &&
                refreshAttempts < MAX_CSRF_REFRESH_ATTEMPTS
            ) {
                refreshAttempts++
                val fb = fallback!!
                Log.d("Fallback", "Fallback received HTTP ${result.statusCode}. Refreshing CSRF token (attempt #$refreshAttempts)")
                val newToken = fb.refreshCsrfToken()
                if (newToken.isNullOrEmpty()) {
                    Log.d("Fallback", "refreshCsrfToken returned empty token on attempt $refreshAttempts, aborting retries")
                    break
                }
                Log.d("Fallback", "CSRF token refreshed successfully on attempt $refreshAttempts")
                fallbackCsrfToken = newToken
                fallbackHeaders[fb.csrfHeaderName] = newToken
                val cookieName = fb.csrfCookieName
                if (!cookieName.isNullOrEmpty()) {
                    fallbackHeaders["Cookie"] =
                        updateCookieHeaderValue(fallbackHeaders["Cookie"], cookieName, newToken)
                }
                result = doFallbackPost(url, bodyJson)
                Log.d("Fallback", "fallbackPostWithRetry retry #$refreshAttempts: $url -> ${result.statusCode}")
            }
            result
        }

    /**
     * Host-provided: tenants that serve the logo as a static asset off [baseUrl] rather than as an
     * object key the download api can resolve. Kept here beside [baseUrl] because resolution needs
     * both, which saves threading it down through every screen that renders a logo.
     */
    private var logoShownThroughBaseUrl = false

    fun setLogoShownThroughBaseUrl(enabled: Boolean) {
        logoShownThroughBaseUrl = enabled
    }

    /**
     * A url the image loader can actually fetch for [objectKey]. With
     * [logoShownThroughBaseUrl] on, the configured value is a path under [baseUrl] and is
     * concatenated; otherwise it is an object key and goes to the download api as before.
     */
    suspend fun resolveImageUrl(objectKey: String): String? =
        if (objectKey.startsWith("http://") || objectKey.startsWith("https://")) {
            objectKey
        } else if (logoShownThroughBaseUrl) {
            baseUrl.trimEnd('/') + "/" + objectKey.trimStart('/')
        } else {
            fetchImageUrl(objectKey)?.result?.downloadUrl
        }

    fun setBaseUrl(url: String) {
        if (baseUrl == url && api != null) return
        baseUrl = url
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val authInterceptor = Interceptor { chain ->
            val original = chain.request()
            val requestBuilder = original.newBuilder()
            publicToken?.let {
                if (it.isNotEmpty()) {
                    Log.d(TAG, "Adding x-public-token: $it")
                    requestBuilder.header("x-public-token", it)
                }
            }
            authToken?.takeIf { it.isNotEmpty() }?.let {
                requestBuilder.header("Authorization", "Bearer $it")
            }
            chain.proceed(requestBuilder.build())
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .addInterceptor(authInterceptor)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(GsonProvider.gson))
            .build()

        api = retrofit.create(ConsentFormApi::class.java)
    }
    suspend fun fetchLanguages(customerId: String, formId: String): List<Language>? {
        return try {
            val request = LanguageRequest(
                mode = "form",
                customerId = customerId,
                formId = formId)
            val response = api?.fetchLanguages(request)
            if (response?.isSuccessful == true) {
                Log.d(TAG, "fetchLanguages API succeeded (status=${response.code()})")
                val list = response.body()?.result?.data?.toMutableList() ?: mutableListOf()
                if (list.none { it.code == "en" }) {
                    list.add(0, Language(code = "en", name = "English"))
                }
                list
            } else {
                Log.w(TAG, "fetchLanguages API failed (status=${response?.code()} ${response?.message()})")
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchLanguages API error: ${e.message}", e)
            emptyList()
        }
    }

    suspend fun checkConsentStatus(
        sourceId: String,
        subjectIdentityValues: Map<String, Any?>,
        token: String? = null,
        dynamicConsent: Boolean? = null,
        touchpointId: String? = null
    ): CheckConsentResponse? {
        val decrypterResponse = getConsentFormId(sourceId, token)
        val resolvedSourceId = Utils.safeId(decrypterResponse?.result?.data?.sourceId)?.toString() ?: return null

        // In token flow, identities come from the decryptor; otherwise they are host-supplied.
        val identities = if (!token.isNullOrEmpty()) {
            (decrypterResponse?.result?.data?.subjectIdentityValues ?: emptyList())
                .associate { Utils.safeId(it.piiLabelId).toString() to it.piiValue }
        } else subjectIdentityValues

        return verifyConsent(resolvedSourceId, identities, dynamicConsent, touchpointId)
    }

    /**
     * Internal-ish helper that avoids re-hitting the decryptor when the response is already known.
     */
    suspend fun verifyConsent(
        resolvedSourceId: String,
        subjectIdentityValues: Map<String, Any?>,
        dynamicConsent: Boolean? = null,
        touchpointId: String? = null
    ): CheckConsentResponse? {
        return try {
            val subjectIdentityValuesList = subjectIdentityValues.entries.map {
                mapOf(
                    "pii_label_id" to it.key.toInt(),
                    "pii_value" to PhoneIdentity.forUnknownLabel(it.value?.toString())
                )
            }

            val payload = mapOf(
                "source_id" to resolvedSourceId.toString(),
                "dynamic_consent" to dynamicConsent,
                "touchpoint_id" to touchpointId,
                "subject_identity_values" to subjectIdentityValuesList
            )

            Log.d(TAG, "verifyConsent: calling primary checkConsentStatus API for sourceId=$resolvedSourceId")
            val response = api?.checkConsentStatus(payload)
            if (response?.isSuccessful == true) {
                Log.d(TAG, "verifyConsent: checkConsentStatus API succeeded (status=${response.code()})")
                verifySuccess = true
                sendSubjectIdentityTypes = true
                response.body()

            } else {
                Log.w(TAG, "verifyConsent: checkConsentStatus API failed (status=${response?.code()} ${response?.message()})")
                if (fallback != null) {
                    verifySuccess = false
                    verifyUseFallback = true
                    Log.d("Fallback", "Verify consent API failed (status=${response?.code()}), triggering fallback mode for this session")
                    Log.d(TAG, "verifyConsent: verify API failed, switching to fallback for this session")
                }
                verifySuccess = false
                null
            }
        } catch (e: Exception) {
            verifySuccess = false
            Log.e(TAG, "checkConsentStatus API error: ${e.message}", e)
            if (fallback != null) {
                verifyUseFallback = true
                Log.d("Fallback", "Verify consent API exception (${e.message}), triggering fallback mode for this session")
            }
            null
        }
    }

    suspend fun getConsentFormData(payload: Map<String, Any?>, sourceId: String?): ConsentFormResponse.ConsentFormData? {
        consentEvidenceToken = null

        var body: ConsentFormResponse? = null
        var evidenceToken: String? = null
        var headerPublicToken: String? = null

        if (!useFallback && !verifyUseFallback) {
            try {
                Log.d(TAG, "getConsentFormData: calling primary API")
                val response = api?.getConsentFormData(payload)
                if (response?.isSuccessful == true) {
                    Log.d(TAG, "getConsentFormData: primary API succeeded (status=${response.code()})")
                    body = response.body()
                    evidenceToken = response.headers()["x-consent-evidence-token"]
                    headerPublicToken = response.headers()["x-public-token"]
                } else {
                    Log.w(TAG, "getConsentFormData: primary API failed (status=${response?.code()} ${response?.message()})")
                    if ((response == null || response.code() >= 500) && fallback != null) {
                        Log.d("Fallback", "Primary display API failed (status=${response?.code()}), triggering fallback mode for this session")
                        Log.d(TAG, "getConsentFormData: primary display failed " +
                                "(status=${response?.code()}), switching to fallback for this session")
                        useFallback = true
                    } else if (response == null) {
                        return null
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "getConsentFormData primary call failed: ${e.message}", e)
                if (fallback != null) {
                    Log.d("Fallback", "Primary display API exception (${e.message}), triggering fallback mode for this session")
                    useFallback = true
                } else return null
            }
        }

        if (useFallback || verifyUseFallback) {
            val fb = fallback ?: return null
            Log.d("Fallback", "Fallback display API started")
            Log.d("Fallback", "Display URL = ${fb.displayUrl}")
            Log.d("Fallback", "Display request headers = ${fallbackHeaders.keys}")
            Log.d(TAG, "getConsentFormData: executing fallback display POST to ${fb.displayUrl}")
            val fallbackPayload: Map<String, Any?> = mapOf("source_id" to sourceId)
            val result = fallbackPostWithRetry(fb.displayUrl, fallbackPayload)
            Log.d("Fallback", "Fallback display API response received")
            Log.d("Fallback", "Response status = ${result.statusCode}")
            if (result.statusCode == 200 && result.body != null) {
                Log.d(TAG, "getConsentFormData: fallback display succeeded (status=200)")
                body = try {
                    GsonProvider.gson.fromJson(result.body, ConsentFormResponse::class.java)
                } catch (e: Exception) {
                    Log.e(TAG, "getConsentFormData: unparseable fallback body", e)
                    null
                }
                evidenceToken = result.headers?.get("x-consent-evidence-token")
                headerPublicToken = result.headers?.get("x-public-token")
            } else {
                Log.e(TAG, "getConsentFormData: fallback display failed (status=${result.statusCode})")
                return null
            }
        }

        if (body == null) return null

        if (!evidenceToken.isNullOrEmpty()) {
            Log.d(TAG, "Adding x-evidence-token: $evidenceToken")
            consentEvidenceToken = evidenceToken
        }

        if (!headerPublicToken.isNullOrEmpty()) {
            publicToken = headerPublicToken
        }
        body.token?.let { if (it.isNotEmpty()) publicToken = it }
        body.result?.token?.let { if (it.isNotEmpty()) publicToken = it }
        body.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }

        return if (body.result?.data?.formTemplate != null) {
            body.result.data.formTemplate
        } else if (!body.result?.data?.formAccessUrl.isNullOrEmpty()) {
            getPlainJsonToDisplayConsent(body.result!!.data!!.formAccessUrl!!)
        } else null
    }

    suspend fun saveConsentFormData(payload: MutableMap<String, Any?>): SaveConsentResponse? = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build()
            
            // 1) get public IP
            val ipRequest = okhttp3.Request.Builder().url("https://api.ipify.org?format=json").build()
            var ip = "127.0.0.1"
            try {
                client.newCall(ipRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        val json = GsonProvider.gson.fromJson(body, Map::class.java)
                        ip = json["ip"] as? String ?: "127.0.0.1"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get IP", e)
            }

            // 2) look up country & continent
            var countryCode = "IN"
            var continent = "ASIA"
            val geoRequest = okhttp3.Request.Builder().url("https://ipapi.co/$ip/json").build()
            try {
                client.newCall(geoRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        val json = GsonProvider.gson.fromJson(body, Map::class.java)
                        countryCode = json["country"] as? String ?: "IN"
                        continent = json["continent_code"] as? String ?: "ASIA"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get Geo", e)
            }

            val geolocation = "$ip($countryCode)"
            payload["geolocation"] = geolocation
            payload["continent"] = continent

            // Once a session has fallen back (triggered by a primary display failure in
            // getConsentFormData), submissions stay on the fallback submit API for the rest of
            // that session too.
            val fb = fallback
            if ((useFallback|| verifyUseFallback) && fb != null) {
                Log.d("Fallback", "Fallback submit API started")
                Log.d("Fallback", "Submit URL = ${fb.submitUrl}")
                Log.d("Fallback", "Submit request headers = ${fallbackHeaders.keys}")
                Log.d(TAG, "saveConsentFormData: submitting consent via fallback POST to ${fb.submitUrl}")
                val result = fallbackPostWithRetry(fb.submitUrl, payload)
                Log.d("Fallback", "Fallback submit API response received")
                Log.d("Fallback", "Response status = ${result.statusCode}")
                val statusCode = result.statusCode
                val isHttpSuccess = statusCode == 200 || statusCode == 202
                if (isHttpSuccess) {
                    Log.d(TAG, "saveConsentFormData: fallback POST succeeded (status=$statusCode)")
                } else {
                    Log.w(TAG, "saveConsentFormData: fallback POST failed (status=$statusCode)")
                }
                // 202 Accepted responses (the fallback submit API's success status) commonly
                // come back with an empty body, which Gson would throw on, so parse only when
                // there is something to parse.
                val parsed = result.body?.takeIf { it.isNotBlank() }?.let {
                    try {
                        GsonProvider.gson.fromJson(it, SaveConsentResponse::class.java)
                    } catch (e: Exception) {
                        Log.e(TAG, "saveConsentFormData: unparseable fallback body", e)
                        null
                    }
                }
                SaveConsentResponse(
                    success = parsed?.success ?: isHttpSuccess,
                    statusCode = parsed?.statusCode ?: statusCode,
                    message = parsed?.message,
                    result = parsed?.result,
                )
            } else {
                Log.d(TAG, "saveConsentFormData: submitting consent via primary API")
                val response = api?.saveConsentFormData(consentEvidenceToken, payload)
                when {
                    response == null -> {
                        Log.e(TAG, "saveConsentFormData failed: Consent form service is not initialised")
                        saveFailure(null, "Consent form service is not initialised")
                    }
                    response.isSuccessful -> {
                        Log.d(TAG, "saveConsentFormData: primary API succeeded (status=${response.code()})")
                        response.body()
                    }
                    // A rejected submission carries the reason in the error body, which `body()` is
                    // always null for. Without this the host's onError only ever sees `null`.
                    else -> {
                        Log.w(TAG, "saveConsentFormData: primary API failed (status=${response.code()})")
                        parseSaveError(response)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "saveConsentFormData error: ${e.message}", e)
            saveFailure(null, e.message ?: e::class.java.simpleName)
        }
    }


    private fun parseSaveError(response: retrofit2.Response<SaveConsentResponse>): SaveConsentResponse {
        val raw = try {
            response.errorBody()?.string()
        } catch (e: Exception) {
            Log.e(TAG, "saveConsentFormData: unreadable error body", e)
            null
        }
        val parsed = raw?.takeIf { it.isNotBlank() }?.let {
            try {
                GsonProvider.gson.fromJson(it, SaveConsentResponse::class.java)
            } catch (e: Exception) {
                Log.e(TAG, "saveConsentFormData: unparseable error body", e)
                null
            }
        }
        return saveFailure(
            statusCode = parsed?.statusCode ?: response.code(),
            message = parsed?.message?.takeIf { it.isNotBlank() }
                ?: raw?.takeIf { it.isNotBlank() }
                ?: "HTTP ${response.code()} ${response.message()}".trim(),
        )
    }

    private fun saveFailure(statusCode: Int?, message: String) =
        SaveConsentResponse(success = false, statusCode = statusCode, message = message, result = null)

    suspend fun getConsentFormId(decryptedSourceId: String?, token: String? = null): DecrypterApiResponse? {
        return try {
            // Token wins over source_id when both are supplied: it replaces raw PII entirely, so
            // the decryptor is never asked to resolve both an identifier and a token at once.
            val data = if (!token.isNullOrEmpty()) {
                mapOf("token" to token)
            } else {
                mapOf("source_id" to decryptedSourceId)
            }
            val payload = mapOf("data" to data)
            Log.d(TAG, "getConsentFormId: calling decrypter API")
            val response = api?.getConsentFormId(payload)
            if (response?.isSuccessful == true) {
                Log.d(TAG, "getConsentFormId: decrypter API succeeded (status=${response.code()})")
                val body = response.body()
                val headerToken = response.headers()["x-public-token"]

                if(!headerToken.isNullOrEmpty()) {
                   publicToken = headerToken
                } else {
                    body?.result?.data?.token?.let { token ->
                        if (token.isNotEmpty()) {
                            publicToken = token
                        }
                    }
                }

                resolvedSourceId = Utils.safeId(body?.result?.data?.sourceId)
                body
            } else {
                Log.w(TAG, "getConsentFormId: decrypter API failed (status=${response?.code()} ${response?.message()})")
                if ((response == null || response.code() >= 500) && fallback != null) {
                    Log.d("Fallback", "Decrypter API failed (status=${response?.code()}), triggering fallback mode for this session")
                    Log.d(TAG, "getConsentFormId: decryptor failed " +
                            "(status=${response?.code()}), switching to fallback for this session")
                    useFallback = true
                }
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getConsentFormId API error: ${e.message}", e)
            if (fallback != null) {
                Log.d("Fallback", "Decrypter API exception (${e.message}), triggering fallback mode for this session")
                useFallback = true
            }
            null
        }
    }

    suspend fun getPrivacyNotice(customerId: String, privacyNoticeId: String, languageCode: String): PrivacyNoticeResponse? {
        return try {
            val request = PrivacyNoticeRequest(
                customerId = customerId,
                sourceId = resolvedSourceId,
                languageCode = languageCode
            )
            Log.d(TAG, "getPrivacyNotice: calling privacy notice API")
            val response = api?.getPrivacyNotice(request)
            if (response?.isSuccessful == true) {
                Log.d(TAG, "getPrivacyNotice: privacy API succeeded (status=${response.code()})")
                response.body()
            } else {
                Log.w(TAG, "getPrivacyNotice: privacy API failed (status=${response?.code()} ${response?.message()})")
                if (fallback != null) {
                    Log.d("Fallback", "Privacy notice API failed (status=${response?.code()}), triggering fallback mode for this session")
                    Log.d(TAG, "privacyStatus: privacy API failed " +
                            "(status=${response?.code()}), switching to fallback for this session")
                    useFallback = true
                }
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getPrivacyNotice API error: ${e.message}", e)
            if (fallback != null) {
                Log.d("Fallback", "Privacy notice API exception (${e.message}), triggering fallback mode for this session")
                useFallback = true
            }
            null
        }
    }

    suspend fun getPlainJsonToDisplayConsent(url: String): ConsentFormResponse.ConsentFormData? {
        return try {
            Log.d(TAG, "getPlainJsonToDisplayConsent: fetching consent template from $url")
            val response = api?.getPlainJsonToDisplayConsent(url)
            if (response?.isSuccessful == true) {
                Log.d(TAG, "getPlainJsonToDisplayConsent: succeeded (status=${response.code()})")
                response.body()
            } else {
                Log.w(TAG, "getPlainJsonToDisplayConsent: failed (status=${response?.code()} ${response?.message()})")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getPlainJsonToDisplayConsent API error: ${e.message}", e)
            null
        }
    }

    suspend fun getDigiLockerResponse(sourceId: String): DigiLockerResponse? {
        return try {
            Log.d(TAG, "getDigiLockerResponse: calling DigiLocker authorization API")
            val consentUrl = "$baseUrl/public/consent-form?source_id=$sourceId"
            val response = api?.getDigiLockerResponse(consentUrl)
            if (response?.isSuccessful == true) {
                Log.d(TAG, "getDigiLockerResponse: API succeeded (status=${response.code()})")
                response.body()
            } else {
                Log.w(TAG, "getDigiLockerResponse: API failed (status=${response?.code()} ${response?.message()})")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getDigiLockerResponse API error: ${e.message}", e)
            null
        }
    }

    suspend fun getCallbackApiResponse(code: String, state: String): CallBackResponse? {
        return try {
            Log.d(TAG, "getCallbackApiResponse: calling callback API")
            val response = api?.getCallbackApiResponse(code, state)
            if (response?.isSuccessful == true) {
                Log.d(TAG, "getCallbackApiResponse: API succeeded (status=${response.code()})")
                val body = response.body()
                
                // Extract public token
                body?.result?.data?.token?.let { if (it.isNotEmpty()) publicToken = it }
                
                body
            } else {
                Log.w(TAG, "getCallbackApiResponse: API failed (status=${response?.code()} ${response?.message()})")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getCallbackApiResponse API error: ${e.message}", e)
            null
        }
    }

    suspend fun fetchImageUrl(iconUrl: String?): ImageDownloadUrlResponse? {
        return try {
            Log.d(TAG, "fetchImageUrl: resolving download url")
            val payload = mapOf("objectKey" to iconUrl)
            val response = api?.fetchImageUrl(payload)
            if (response?.isSuccessful == true) {
                Log.d(TAG, "fetchImageUrl: API succeeded (status=${response.code()})")
                val body = response.body()
                body
            } else {
                Log.w(TAG, "fetchImageUrl: API failed (status=${response?.code()} ${response?.message()})")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchImageUrl API error: ${e.message}", e)
            null
        }
    }

}
