package com.tekhsters.gotrustsdkandroid

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.annotation.DrawableRes

/**
 * Host-provided proxy the consent form falls back to for the rest of a session once GoTrust's
 * primary display/submit APIs start failing (5xx or unreachable). [refreshCsrfToken] is called
 * whenever a fallback call comes back 401/403; its result replaces [csrfHeaderName] (and, if
 * [csrfCookieName] is set, the matching cookie in the `Cookie` header) before one retry.
 */
data class FallbackConfig(
    val displayUrl: String,
    val submitUrl: String,
    val headers: Map<String, String> = emptyMap(),
    val csrfHeaderName: String = "X-CSRF-Token",
    val csrfCookieName: String? = null,
    val refreshCsrfToken: suspend () -> String?,
)


enum class TextAlignment { START, CENTER, END }
enum class VerticalAlignment { TOP, CENTER, BOTTOM }
enum class Orientation { HORIZONTAL, VERTICAL }

data class TextTheme(
    val text: String? = null,
    val color: String = "#1D1B20",
    val fontSize: Float = 20f,            // sp
    val fontWeight: Int = 500,            // 100..900
    val fontFamily: String? = null,       // registered font name
    val italic: Boolean = false,
    val alignment: TextAlignment = TextAlignment.CENTER,
    val letterSpacing: Float = 0f,        // em
    val lineHeight: Float? = null,        // sp
    val maxLines: Int? = null
)

data class ButtonTheme(
    val text: String = "Retry",
    val textColor: String = "#FFFFFF",
    val backgroundColor: String = "#6750A4",
    val borderColor: String? = null,
    val borderWidth: Float = 0f,          // dp
    val cornerRadius: Float = 24f,        // dp
    val fontSize: Float = 16f,
    val fontWeight: Int = 500,
    val fontFamily: String? = null,
    val height: Float = 48f,              // dp
    val horizontalPadding: Float = 24f,   // dp
    val elevation: Float = 0f,            // dp
    val visible: Boolean = true
)

data class IconTheme(
    val visible: Boolean = true,
    @DrawableRes val resId: Int? = null,
    val url: String? = null,
    val tintColor: String? = null,
    val size: Float = 64f
)


data class ErrorTheme(
    val backgroundColor: String = "#FEF7FF",
    val verticalAlignment: VerticalAlignment = VerticalAlignment.CENTER,
    val horizontalPadding: Float = 24f,
    val verticalPadding: Float = 24f,
    val itemSpacing: Float = 16f,
    val icon: IconTheme = IconTheme(),
    val title: TextTheme = TextTheme(text = "Unable to load preference center"),
    val description: TextTheme = TextTheme(color = "#49454F", fontSize = 14f, fontWeight = 400),
    val primaryButton: ButtonTheme = ButtonTheme(text = "Retry"),
    val secondaryButton: ButtonTheme = ButtonTheme(
        text = "Go Back", textColor = "#6750A4",
        backgroundColor = "#00000000", borderColor = "#6750A4", borderWidth = 1f
    ),
    val buttonsOrientation: Orientation = Orientation.HORIZONTAL,
    val buttonSpacing: Float = 12f,
    val buttonsAlignment: TextAlignment = TextAlignment.CENTER,
    val buttonsFillWidth: Boolean = false,
    val loaderColor: String = "#6750A4",
    val showRetry: Boolean = true,
    val showGoBack: Boolean = true
)

fun String?.toColorOrDefault(default: String): Int =
    try { Color.parseColor(this?.trim()) } catch (e: Exception) { Color.parseColor(default) }

fun Typeface.withWeight(weight: Int, italic: Boolean): Typeface =
    if (Build.VERSION.SDK_INT >= 28) Typeface.create(this, weight, italic)
    else Typeface.create(this, when {
        weight >= 600 && italic -> Typeface.BOLD_ITALIC
        weight >= 600 -> Typeface.BOLD
        italic -> Typeface.ITALIC
        else -> Typeface.NORMAL
    })

fun TextView.applyTheme(t: TextTheme, defaultColor: String) {
    setTextColor(t.color.toColorOrDefault(defaultColor))
    textSize = t.fontSize
    val base = t.fontFamily?.let { Typeface.create(it, Typeface.NORMAL) } ?: Typeface.DEFAULT
    typeface = base.withWeight(t.fontWeight, t.italic)
    letterSpacing = t.letterSpacing
    t.lineHeight?.let {
        if (Build.VERSION.SDK_INT >= 28)
            lineHeight = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, it, resources.displayMetrics).toInt()
    }
    t.maxLines?.let { maxLines = it; ellipsize = TextUtils.TruncateAt.END }
    textAlignment = when (t.alignment) {
        TextAlignment.START -> View.TEXT_ALIGNMENT_VIEW_START
        TextAlignment.CENTER -> View.TEXT_ALIGNMENT_CENTER
        TextAlignment.END -> View.TEXT_ALIGNMENT_VIEW_END
    }
}

fun Button.applyTheme(b: ButtonTheme) {
    text = b.text
    setTextColor(b.textColor.toColorOrDefault("#FFFFFF"))
    textSize = b.fontSize
    val base = b.fontFamily?.let { Typeface.create(it, Typeface.NORMAL) } ?: Typeface.DEFAULT
    typeface = base.withWeight(b.fontWeight, false)
    isAllCaps = false
    val d = resources.displayMetrics.density
    background = GradientDrawable().apply {
        setColor(b.backgroundColor.toColorOrDefault("#6750A4"))
        cornerRadius = b.cornerRadius * d
        b.borderColor?.let { setStroke((b.borderWidth * d).toInt(), it.toColorOrDefault("#6750A4")) }
    }
    elevation = b.elevation * d
    setPadding((b.horizontalPadding * d).toInt(), 0, (b.horizontalPadding * d).toInt(), 0)
    minHeight = (b.height * d).toInt()
    visibility = if (b.visible) View.VISIBLE else View.GONE
}

/**
 * Everything the consent form needs to launch. Defaults match what the activity assumed when an
 * extra was absent, so an existing integration translates field-for-field.
 */
data class ConsentFormConfig(
    val baseUrl: String,
    /**
     * True when the tenant serves its logo as a static asset off [baseUrl] — the configured
     * `logo_url` is then a path (e.g. `/assets/svg/logo.svg`) that is appended to [baseUrl] and
     * rendered directly. Left false, `logo_url` is treated as an object key and resolved through
     * the download api, which is what every existing integration gets.
     */
    val logoShownThroughBaseUrl: Boolean = false,
    /**
     * Absolute url of a logo the host wants in the header instead of the one the form config
     * carries. When set it wins outright — including over `show_logo: false` — and is rendered
     * directly, with no download-api call. Null leaves the configured logo in charge.
     */
    val headerLogo: String? = null,
    val sourceId: String? = null,
    val subjectIdentityValues: Map<String, Any> = emptyMap(),
    val additionalParams: Map<String, Any> = emptyMap(),
    val showCrossButton: Boolean = true,
    val initialLanguage: String = "en",
    val enableCaptcha: Boolean = true,
    val fallback: FallbackConfig? = null,
    val errorTheme: ErrorTheme? = null,
    val dynamicConsent : Boolean = false,
    val touchpointId : String? = null,
    /**
     * Opaque decryptor token in place of raw PII. When set, it replaces [sourceId] for identity
     * resolution and the decryptor's own identity/PII becomes the effective identity — [subjectIdentityValues]
     * and [additionalParams] are ignored for that call. [sourceId] is optional in this case and, if
     * present, is still sent as a fallback routing id.
     */
    val token: String? = null,
    /**
     * Bearer token from your backend's `authorize/token` call. Forwarded as
     * `Authorization: Bearer <authToken>` on every request the SDK makes, in the standard flow
     * as well as in [token] flow. It is a service-account credential: fetch it from your own
     * backend at runtime rather than hard-coding it, and hand over a fresh one once it expires.
     */
    val authToken: String? = null,
)

/** Everything the preference center needs to launch. See [ConsentFormConfig]. */
data class PreferenceCenterConfig(
    val baseUrl: String,
    /** See [ConsentFormConfig.logoShownThroughBaseUrl]. */
    val logoShownThroughBaseUrl: Boolean = false,
    /** See [ConsentFormConfig.headerLogo]. */
    val headerLogo: String? = null,
    val pfToken: String? = null,
    val consentId: String? = null,
    val customerId: String? = null,
    val preferenceFormId: String? = null,
    val initialSubjectValues: Map<String, Any> = emptyMap(),
    val additionalParams: Map<String, Any> = emptyMap(),
    val initialLanguage: String = "en",
    val enableCaptcha: Boolean = true,
    /**
     * Opaque decryptor token in place of raw PII. Wins over [pfToken] when both are supplied, and
     * over [customerId]/[preferenceFormId] for identity resolution — see [ConsentFormConfig.token].
     */
    val token: String? = null,
    /** See [ConsentFormConfig.authToken]. */
    val authToken: String? = null,
    val errorTheme: ErrorTheme? = null,
)
