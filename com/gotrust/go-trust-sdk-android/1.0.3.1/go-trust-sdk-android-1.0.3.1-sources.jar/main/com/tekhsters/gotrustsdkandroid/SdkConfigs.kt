package com.tekhsters.gotrustsdkandroid

/**
 * Host-provided proxy the consent form falls back to for the rest of a session once GoTrust's
 * primary display/submit APIs start failing (5xx or unreachable). [refreshCsrfToken] is called
 * whenever a fallback call comes back 401/403; its result replaces [csrfHeaderName] (and, if
 * [csrfCookieName] is set, the matching cookie in the `Cookie` header) before one retry.
 */
data class FallbackConfig(
    val displayUrl: String,
    val submitUrl: String,
    val headers: Map<String, String> = emptyMap(),
    val csrfHeaderName: String = "X-CSRF-Token",
    val csrfCookieName: String? = null,
    val refreshCsrfToken: suspend () -> String?,
)

/**
 * Everything the consent form needs to launch. Defaults match what the activity assumed when an
 * extra was absent, so an existing integration translates field-for-field.
 */
data class ConsentFormConfig(
    val baseUrl: String,
    val sourceId: String? = null,
    val subjectIdentityValues: Map<String, Any> = emptyMap(),
    val additionalParams: Map<String, Any> = emptyMap(),
    val showCrossButton: Boolean = true,
    val initialLanguage: String = "en",
    val enableCaptcha: Boolean = true,
    val fallback: FallbackConfig? = null,
    val dynamicConsent : Boolean = false,
    /**
     * Opaque decryptor token in place of raw PII. When set, it replaces [sourceId] for identity
     * resolution and the decryptor's own identity/PII becomes the effective identity — [subjectIdentityValues]
     * and [additionalParams] are ignored for that call. [sourceId] is optional in this case and, if
     * present, is still sent as a fallback routing id.
     */
    val token: String? = null,
    /**
     * Bearer token from your backend's `authorize/token` call. Forwarded as
     * `Authorization: Bearer <authToken>` on every request the SDK makes, in the standard flow
     * as well as in [token] flow. It is a service-account credential: fetch it from your own
     * backend at runtime rather than hard-coding it, and hand over a fresh one once it expires.
     */
    val authToken: String? = null,
)

/** Everything the preference center needs to launch. See [ConsentFormConfig]. */
data class PreferenceCenterConfig(
    val baseUrl: String,
    val pfToken: String? = null,
    val consentId: String? = null,
    val customerId: String? = null,
    val preferenceFormId: String? = null,
    val initialSubjectValues: Map<String, Any> = emptyMap(),
    val additionalParams: Map<String, Any> = emptyMap(),
    val initialLanguage: String = "en",
    val enableCaptcha: Boolean = true,
    /**
     * Opaque decryptor token in place of raw PII. Wins over [pfToken] when both are supplied, and
     * over [customerId]/[preferenceFormId] for identity resolution — see [ConsentFormConfig.token].
     */
    val token: String? = null,
    /** See [ConsentFormConfig.authToken]. */
    val authToken: String? = null,
)
