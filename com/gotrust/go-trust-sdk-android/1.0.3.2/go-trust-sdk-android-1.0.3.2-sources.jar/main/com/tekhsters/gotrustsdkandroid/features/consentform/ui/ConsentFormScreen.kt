package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.core.ui.ShowImage
import com.tekhsters.gotrustsdkandroid.core.utils.*
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language
import com.tekhsters.gotrustsdkandroid.features.consentform.services.ApiService
import java.util.Calendar

//import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.px-string

/** Mirrors Flutter's `_getAlignment`: left/right/center -> Box alignment, defaulting to start. */
fun boxAlignment(key: String?, fallback: Alignment = Alignment.CenterStart): Alignment =
    when (key?.lowercase()) {
        "left" -> Alignment.CenterStart
        "right" -> Alignment.CenterEnd
        "center" -> Alignment.Center
        else -> fallback
    }

fun textAlignFor(key: String?, fallback: TextAlign = TextAlign.Left): TextAlign =
    when (key?.lowercase()) {
        "left" -> TextAlign.Left
        "right" -> TextAlign.Right
        "center" -> TextAlign.Center
        else -> fallback
    }

/**
 * Mirrors Flutter's `_buildConsentInputControl`: renders a Switch when
 * consent_input_type == "toggle", else a checkbox whose shape follows
 * checkbox_border_radius (so a large/percent radius yields a circular control).
 * When [interactive] is false the control is purely visual (Flutter wraps the
 * bucket-level control in IgnorePointer since the whole row already handles taps).
 */
@Composable
fun ConsentInputControl(
    fc: ConsentFormResponse.FormConfiguration?,
    value: Boolean,
    disabled: Boolean,
    interactive: Boolean = true,
    onChanged: (Boolean) -> Unit
) {
    val inputType = (fc?.consentCollectionSection?.consentInputType ?: "checkbox").lowercase()
    val activeColor = Utils.hexToColor(fc?.form?.colorScheme ?: "#000000")

    if (inputType == "toggle") {
        Switch(
            checked = value,
            onCheckedChange = if (disabled || !interactive) null else onChanged,
            colors = SwitchDefaults.colors(
                checkedTrackColor = activeColor,
                checkedThumbColor = Color.White
            ),
            modifier = Modifier.scale(0.8f)
        )
    } else {
        val radiusDp =
            parseBorderRadius(fc?.consentCollectionSection?.checkboxBorderRadius, size = 20f).dp
        val shape = RoundedCornerShape(radiusDp)
        val bgColor =
            if (value) activeColor.copy(alpha = if (disabled) 0.7f else 1f) else Color.Transparent
        val borderColor = if (value) activeColor else Color(0xFFBDBDBD)
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(shape)
                .background(bgColor, shape)
                .border(1.5.dp, borderColor, shape)
                .let {
                    if (interactive && !disabled) it.clickable { onChanged(!value) } else it
                },
            contentAlignment = Alignment.Center
        ) {
            if (value) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsentFormScreen(
    viewModel: ConsentFormViewModel,
    onClose: () -> Unit,
    showCrossButton: Boolean = true
) {
    val form by viewModel.consentForm.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val checkAllStatus by viewModel.checkAllStatus.collectAsState()
    val consentRevision by viewModel.consentRevision.collectAsState()
    val invalidPiiKeys by viewModel.invalidPiiKeys.collectAsState()
    val piiValues = viewModel.piiValues
    val mandatoryPiiIds = remember(form) { viewModel.getMandatoryPiiIds() }
    val getImageUrl = viewModel::getImageUrl

    val isMinorForm = !form?.piiList?.consentActorPiiList.isNullOrEmpty()

    val fc = form?.formConfiguration
    val bi = form?.basicInfo

    val headingLayoutConfig = fc?.form?.headingLayoutConfig
    Scaffold(

        topBar = {
            TopAppBar(
                title = {
                    if (headingLayoutConfig?.headingLayout?.lowercase() != "body") {
                        DynamicTextWidget(
                            text = fc?.form?.heading?.text ?: "",
                            colorHex = fc?.form?.heading?.color ?: "#000000",
                        )
                    }
                },
                navigationIcon = {
                    val logo = fc?.form?.logo
                    // A host-supplied headerLogo wins outright, including over show_logo = false.
                    if (!viewModel.headerLogo.isNullOrEmpty() || logo?.showLogo == true) {
                        ShowImage(
                            iconObjectKey = viewModel.headerLogo ?: logo?.logoUrl,
                            iconWidth = logo?.width ?: "140",
                            iconHeight = logo?.height ?: "48",
                            getImageUrl = getImageUrl,
                            modifier = if (headingLayoutConfig?.headingLayout?.lowercase() == "body") Modifier.fillMaxWidth() else Modifier,
                            alignment = boxAlignment(
                                headingLayoutConfig?.logoPosition,
                                fallback = Alignment.CenterStart
                            )
                        )
                    }
                },


                actions = {
                    if (fc?.form?.showLanguage == true) {
                        LanguageSelector(
                            languages = languages,
                            selectedCode = selectedLanguage,
                            onChanged = { viewModel.onLanguageChanged(it) },
                            colorHex = fc.form.languageDropDown?.backgroundColor,
                            textColor = fc.form.languageDropDown?.textColor
                        )
                    }
                    if (showCrossButton) {
                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                },

                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    scrolledContainerColor = Color.White
                )
            )
        },
        containerColor = /*Utils.hexToColor(fc?.form?.formBackgroundColor),*/ Color.White,
        bottomBar = {
            SubmitActionSection(
                viewModel = viewModel,
                fc = fc,
                onPrivacyPolicyClick = { viewModel.showPrivacyNotice() },
                onClose = onClose,
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            fc?.form?.illustrationImage?.let { img ->
                if (img.showIllustrationImage == true && img.illustrationImageUrl != null) {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = boxAlignment(
                            fc.sectionAlignments?.illustration,
                            fallback = Alignment.Center
                        )
                    ) {
                        val configuredWidth = parsePxToDpOrNull(img.width)
                        ShowImage(
                            iconObjectKey = img.illustrationImageUrl,
                            getImageUrl = getImageUrl,
                            modifier = Modifier
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .let { if (configuredWidth != null) it.width(configuredWidth) else it.fillMaxWidth() }
                                .height(parsePxToDp(img.height, fallback = 200f)),

                            )
                    }
                }
            }

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = boxAlignment(fc?.sectionAlignments?.banner)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    if (headingLayoutConfig?.headingLayout?.lowercase() == "body" && fc?.form?.heading?.text != null && fc.form?.heading?.text != "") {
                        DynamicTextWidget(
                            text = fc?.form?.heading?.text ?: "",
                            colorHex = fc?.form?.heading?.color ?: "#000000",
                            fontWeight = getFontWeight(fc?.form?.heading?.fontWeight)
                        )
                    }
                    if (fc?.form?.description?.text != null && fc.form?.description?.text != "") {
                        DynamicTextWidget(
                            text = fc?.form?.description?.text ?: "",
                            colorHex = fc?.form?.description?.color,
                            fontWeight = getFontWeight(fc?.form?.description?.fontWeight),
                            fontSize = fc?.form?.description?.size?.replace("px", "")
                                ?.toDoubleOrNull()
                        )
                    }
                    if (fc?.piiSection?.heading?.text != null && fc.piiSection?.heading?.text != "") {
                        DynamicTextWidget(
                            text = fc?.piiSection?.heading?.text ?: "",
                            colorHex = fc?.piiSection?.heading?.color,
                            fontWeight = getFontWeight(fc?.piiSection?.heading?.fontWeight),
                            fontSize = fc?.piiSection?.heading?.size?.replace("px", "")
                                ?.toDoubleOrNull()
                        )
                    }
                    if (fc?.piiSection?.description?.text != null && fc.piiSection?.description?.text != "") {
                        DynamicTextWidget(
                            text = fc?.piiSection?.description?.text ?: "",
                            colorHex = fc?.piiSection?.description?.color,
                            fontWeight = getFontWeight(fc?.piiSection?.description?.fontWeight)
                        )
                    }
                }
            }

            // PII Section
            if (fc?.piiSection?.showPiiSection == true) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = boxAlignment(fc.sectionAlignments?.piiSection)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        PiiGroup(
                            piiList = form?.piiList?.dataPrincipalPiiList,
                            heading = if (isMinorForm) fc.piiSection.dataPrincipalHeading else null,
                            values = piiValues,
                            invalidKeys = invalidPiiKeys,
                            showPiiFields = fc.piiSection.showPiiFields,
                            mandatoryIds = mandatoryPiiIds,
                            colorScheme = fc.form?.colorScheme,
                            onValueChange = { key, value ->
                                viewModel.onPiiValueChanged(
                                    key,
                                    value
                                )
                            }
                        )
                        PiiGroup(
                            piiList = form?.piiList?.consentActorPiiList,
                            heading = if (isMinorForm) fc.piiSection.consentActorHeading else null,
                            values = piiValues,
                            invalidKeys = invalidPiiKeys,
                            showPiiFields = fc.piiSection.showPiiFields,
                            mandatoryIds = mandatoryPiiIds,
                            colorScheme = fc.form?.colorScheme,
                            onValueChange = { key, value ->
                                viewModel.onPiiValueChanged(
                                    key,
                                    value
                                )
                            }
                        )
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            }

            // Consent Section
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = boxAlignment(fc?.sectionAlignments?.consentSection)
            ) {
                ConsentSection(
                    viewModel = viewModel,
                    getImageUrl = viewModel::getImageUrl,
                    form = form,
                    fc = fc,
                    checkAllStatus = checkAllStatus,
                    consentRevision = consentRevision,
                    isMinorForm = isMinorForm,
                    onCheckAllChange = { viewModel.toggleCheckAll(it) },
                    onSync = { viewModel.syncCheckAllStatus() }
                )
            }

            // Footer
            fc?.formFooter?.description?.text?.let { footerText ->
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = boxAlignment(fc.sectionAlignments?.footer)
                ) {
                    HtmlText(
                        html = footerText,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            // Privacy Notice link, shown here only in the dynamic-action-buttons layout — the
            // single-Submit layout keeps it as a button beside Submit instead.
            if (shouldShowDynamicButtons(fc) && fc?.form?.showPrivacyPolicyUrl != false) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = fc?.form?.privacyPolicyUrlText ?: "Privacy Notice",
                    color = Color.Blue,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .padding(horizontal = 18.dp)
                        .clickable { viewModel.showPrivacyNotice() }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun PiiGroup(
    piiList: List<ConsentFormResponse.PiiLabel>?,
    heading: ConsentFormResponse.Heading?,
    values: MutableMap<String, String>,
    invalidKeys: Set<String>,
    showPiiFields: Map<String, Boolean>?,
    mandatoryIds: Set<String>,
    colorScheme: String?,
    onValueChange: (key: String, value: String) -> Unit
) {
    val visiblePiiList = piiList.orEmpty().filter { pii ->
        showPiiFields?.get(Utils.safeIdString(pii.id)) ?: true
    }
    if (visiblePiiList.isEmpty()) return
    val context = LocalContext.current

    Column(modifier = Modifier.padding(16.dp)) {
        heading?.text?.let {
            if (looksLikeHtml(it)) {
                HtmlText(html = it, colorHex = heading.color, fontWeight = FontWeight.SemiBold)
            } else {
                Text(it, style = TextStyleHelper.title, color = Utils.hexToColor(heading.color))
            }
        }

        visiblePiiList.forEach { pii ->
            val key = "${pii.principalContext ?: ""}_${pii.id}"
            val isInvalid = key in invalidKeys
            val isPhone = PhoneIdentity.isPhoneLabel(pii.name, pii.regEx)
            val isMandatory = mandatoryIds.contains(Utils.safeIdString(pii.id))
            val isDob = pii.name?.trim()?.equals("Date of Birth", ignoreCase = true) == true

            val showDatePicker = {
                val cal = Calendar.getInstance()
                val currentValue = values[key]
                if (!currentValue.isNullOrBlank()) {
                    try {
                        val parts = currentValue.split("/", "-")
                        if (parts.size == 3) {
                            if (parts[0].length == 4) {
                                cal.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt())
                            } else {
                                cal.set(parts[2].toInt(), parts[1].toInt() - 1, parts[0].toInt())
                            }
                        }
                    } catch (_: Exception) {
                    }
                }
                val dialog = android.app.DatePickerDialog(
                    context,
                    { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                        val formattedDate = String.format(
                            java.util.Locale.US,
                            "%02d/%02d/%04d",
                            selectedDayOfMonth,
                            selectedMonth + 1,
                            selectedYear
                        )
                        onValueChange(key, formattedDate)
                    },
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH)
                )
                val minCal = Calendar.getInstance()
                minCal.add(Calendar.YEAR, -125)
                dialog.datePicker.minDate = minCal.timeInMillis

                dialog.datePicker.maxDate = System.currentTimeMillis()
                dialog.show()
            }

            val textField = @Composable {
                OutlinedTextField(
                    value = values[key] ?: "",
                    onValueChange = {
                        if (!isDob) onValueChange(
                            key,
                            if (isPhone) PhoneIdentity.strip(it) else it
                        )
                    },
                    label = {
                        Row {
                            Text(pii.name ?: "")
                            if (isMandatory) {
                                Text(" *", color = Color.Red)
                            }
                        }
                    },
                    prefix = if (isPhone) {
                        { Text(PhoneIdentity.COUNTRY_CODE) }
                    } else null,
                    trailingIcon = if (isDob) {
                        {
                            IconButton(onClick = { showDatePicker() }) {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = "Select Date"
                                )
                            }
                        }
                    } else null,
                    keyboardOptions = if (isPhone) {
                        KeyboardOptions(keyboardType = KeyboardType.Phone)
                    } else {
                        KeyboardOptions.Default
                    },
                    singleLine = true,
                    isError = isInvalid,
                    supportingText = if (isInvalid) {
                        { Text("This field is required") }
                    } else null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Utils.hexToColor(colorScheme),
                        focusedLabelColor = Utils.hexToColor(colorScheme)
                    )
                )
            }

            if (isDob) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    textField()
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .clickable { showDatePicker() }
                    )
                }
            } else {
                textField()
            }
        }
    }
}

/** Not private: reused by the TV SDK to keep category/purpose ordering identical across both. */
fun parseOrderInt(value: Any?): Int? = when (value) {
    is Int -> value
    is Double -> value.toInt()
    is String -> value.toIntOrNull()
    else -> null
}

fun extractOrderIds(value: Any?): List<Int> {
    if (value !is List<*>) return emptyList()
    return value.mapNotNull { parseOrderInt(it) }
}

/** Not private: reused by the TV SDK to keep category/purpose ordering identical across both. */
fun getOrderedCategories(
    categories: List<ConsentFormResponse.Category>,
    fc: ConsentFormResponse.FormConfiguration?
): List<ConsentFormResponse.Category> {
    val section = fc?.consentCollectionSection
    if (section?.enableCategoryLevelConsent != true) return categories
    val order = section.categoryOrder
    if (order.isNullOrEmpty()) return categories
    val orderIndex = order.withIndex().associate { (i, id) -> id to i }
    return categories.sortedWith(compareBy(nullsLast()) {
        parseOrderInt(it.processingPurposeCategoryId)?.let(
            orderIndex::get
        )
    })
}

/** Not private: reused by the TV SDK to keep category/purpose ordering identical across both. */
fun getOrderedPurposes(
    category: ConsentFormResponse.Category,
    fc: ConsentFormResponse.FormConfiguration?
): List<ConsentFormResponse.ProcessingPurpose> {
    val purposes = category.purposeList ?: return emptyList()
    if (purposes.isEmpty()) return purposes
    val section = fc?.consentCollectionSection

    var orderIds: List<Int> = emptyList()
    if (section?.enableCategoryLevelConsent == true) {
        val categoryId = parseOrderInt(category.processingPurposeCategoryId)
        val map = section.categoryPurposeOrder
        if (categoryId != null && map != null) {
            for ((key, value) in map) {
                if (parseOrderInt(key) == categoryId) {
                    orderIds = extractOrderIds(value)
                    break
                }
            }
        }
    }
    if (orderIds.isEmpty()) {
        orderIds = section?.processingPurposeOrder ?: emptyList()
        if (orderIds.isEmpty()) return purposes
    }
    val orderIndex = orderIds.withIndex().associate { (i, id) -> id to i }

    fun sortId(purpose: ConsentFormResponse.ProcessingPurpose): Int? {
        val consentPurposeId =
            purpose.buckets?.firstOrNull()?.let { parseOrderInt(it.consentPurposeId) }
        return if (section?.enableCategoryLevelConsent == true && consentPurposeId != null) {
            consentPurposeId
        } else {
            parseOrderInt(purpose.id)
        }
    }

    return purposes.sortedWith(compareBy(nullsLast()) { sortId(it)?.let(orderIndex::get) })
}

@Composable
fun ConsentSection(
    viewModel: ConsentFormViewModel,
    getImageUrl: suspend (String?) -> String?,
    form: ConsentFormResponse.ConsentFormData?,
    fc: ConsentFormResponse.FormConfiguration?,
    checkAllStatus: Boolean,
    consentRevision: Int,
    isMinorForm: Boolean,
    onCheckAllChange: (Boolean) -> Unit,
    onSync: () -> Unit
) {
    val dataPrincipalCategories =
        getOrderedCategories(form?.categoryList?.dataPrincipalCategoryList ?: emptyList(), fc)
    val consentActorCategories =
        getOrderedCategories(form?.categoryList?.consentActorCategoryList ?: emptyList(), fc)
    val categories = dataPrincipalCategories + consentActorCategories

    val enableCategoryLevel = fc?.consentCollectionSection?.enableCategoryLevelConsent == true

    Column(modifier = Modifier
        .padding(16.dp)
        .background(Color.White)) {
        // Preference Input Heading Parity
        form?.basicInfo?.preferenceInputHeading?.let { heading ->
            if (heading.isNotEmpty()) {
                Text(
                    text = heading,
                    style = TextStyleHelper.title,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }
        }

        if (fc?.consentCollectionSection?.showCheckAllCheckbox == true) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ConsentInputControl(
                    fc = fc,
                    value = checkAllStatus,
                    disabled = false,
                    onChanged = onCheckAllChange
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    fc.consentCollectionSection.allCheckboxText ?: "Check All",
                    style = TextStyleHelper.smallHeading
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        if (categories.isEmpty()) {
            // Debug indicator
            Text(
                "No categories available",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        val consentTextAlign = textAlignFor(fc?.sectionAlignments?.consentSection)

        @Composable
        fun renderCategoryGroup(
            groupCategories: List<ConsentFormResponse.Category>,
            heading: ConsentFormResponse.Heading?
        ) {
            val visibleCategories = groupCategories.filter { it.visible != false }
            if (visibleCategories.isEmpty()) return

            if (isMinorForm && !heading?.text.isNullOrEmpty()) {
                val headingText = heading?.text ?: ""
                if (looksLikeHtml(headingText)) {
                    HtmlText(
                        html = headingText,
                        colorHex = heading?.color,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Text(
                        text = headingText,
                        style = TextStyleHelper.title,
                        color = Utils.hexToColor(heading?.color),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }

            visibleCategories.forEach { category ->
                if (enableCategoryLevel) {
                    CategoryItem(category, fc, viewModel, getImageUrl, consentRevision, onSync)
                } else {
                    // Flattened view
                    getOrderedPurposes(category, fc).forEach { purpose ->
                        if (purpose.visible != false) {
                            purpose.buckets?.forEach { bucket ->
                                if (bucket.visible != false) {
                                    BucketItem(
                                        bucket,
                                        fc,
                                        getImageUrl,
                                        consentRevision,
                                        onSync,
                                        consentTextAlign
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        renderCategoryGroup(dataPrincipalCategories, fc?.piiSection?.dataPrincipalHeading)
        renderCategoryGroup(consentActorCategories, fc?.piiSection?.consentActorHeading)
    }
}


@Composable
fun CategoryItem(
    category: ConsentFormResponse.Category,
    fc: ConsentFormResponse.FormConfiguration?,
    viewModel: ConsentFormViewModel,
    getImageUrl: suspend (String?) -> String?,
    consentRevision: Int,
    onSync: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    // Keyed on the revision counter: consentStatus is not Compose-observable, so without this
    // the category control keeps showing a stale value after a child bucket is toggled.
    val isSelected = remember(consentRevision, category) { viewModel.isCategorySelected(category) }

    val section = fc?.consentCollectionSection
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"
    val showCategoryControl = section?.showConsentInput != false &&
            section?.showCategoryConsentInput != false &&
            (section?.showCheckAllCheckbox != true || section.showIndividualChecks == true)
    val textAlign = textAlignFor(fc?.sectionAlignments?.consentSection)

    val categoryIdStr = parseOrderInt(category.processingPurposeCategoryId)?.toString()
    val config = section?.categoryConfig?.get(categoryIdStr)

    OutlinedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showCategoryControl && !inputOnRight) {
                    ConsentInputControl(
                        fc = fc,
                        value = isSelected,
                        disabled = false,
                        onChanged = { viewModel.toggleCategoryConsent(category, it) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))


                    if (!categoryIdStr.isNullOrEmpty()) {
                        ShowImage(
                            iconObjectKey = config?.iconUrl,
                            iconWidth = config?.iconWidth,
                            iconHeight = config?.iconHeight,
                            getImageUrl = getImageUrl
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                Text(
                    text = category.processingPurposeCategoryName ?: "",
                    style = TextStyleHelper.title,
                    textAlign = textAlign,
                    modifier = Modifier.weight(1f)
                )
                if (showCategoryControl && inputOnRight) {
                    if (!categoryIdStr.isNullOrEmpty()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        ShowImage(
                            iconObjectKey = config?.iconUrl,
                            iconWidth = config?.iconWidth,
                            iconHeight = config?.iconHeight,
                            getImageUrl = getImageUrl,

                            )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    ConsentInputControl(
                        fc = fc,
                        value = isSelected,
                        disabled = false,
                        onChanged = { viewModel.toggleCategoryConsent(category, it) }
                    )


                }
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = if (expanded) "Collapse" else "Expand"
                )
            }
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                getOrderedPurposes(category, fc).forEach { purpose ->
                    if (purpose.visible != false) {
                        purpose.buckets?.forEach { bucket ->
                            if (bucket.visible != false) {
                                BucketItem(
                                    bucket,
                                    fc,
                                    getImageUrl,
                                    consentRevision,
                                    onSync,
                                    textAlign
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// FlowRow is still an experimental layout in Compose Foundation 1.7.x.
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BucketItem(
    bucket: ConsentFormResponse.ConsentBucket,
    fc: ConsentFormResponse.FormConfiguration?,
    getImageUrl: suspend (String?) -> String?,
    consentRevision: Int,
    onSync: () -> Unit,
    textAlign: TextAlign = TextAlign.Left
) {
    val ct = bucket.ctcpList?.firstOrNull() ?: return

    val status = remember(consentRevision, ct) { ct.consentStatus ?: false }

    val section = fc?.consentCollectionSection
    val showIndividualInput = section?.showCheckAllCheckbox == false ||
            (section?.showIndividualChecks == true && section.enableCategoryLevelConsent == true)
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"

    val consentPurposeIdStr = parseOrderInt(bucket.consentPurposeId)?.toString()
    val config = section?.purposeConfig?.get(consentPurposeIdStr)

    val toggle: () -> Unit = {
        // A bucket's checkbox represents every ct_cp_map entry it holds (one per pii
        // label/process/vendor) — validateCompulsoryConsents() requires all of them set, so
        // toggling only the first left the others unset and blocked submission.
        val newStatus = !status
        bucket.ctcpList?.forEach { it.consentStatus = newStatus }
        onSync()
    }

    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { toggle() }
    ) {
        if (showIndividualInput && !inputOnRight) {
            // Matches the Column's own top padding below so the checkbox lines up with the
            // heading's first line instead of floating above it.
            Box(modifier = Modifier.padding(top = 12.dp)) {
                ConsentInputControl(
                    fc = fc,
                    value = status,
                    disabled = false,
                    interactive = false,
                    onChanged = {})
            }
            Spacer(modifier = Modifier.width(8.dp))
            if (!consentPurposeIdStr.isNullOrEmpty()) {
                ShowImage(
                    iconObjectKey = config?.iconUrl,
                    iconWidth = config?.iconWidth,
                    iconHeight = config?.iconHeight,
                    getImageUrl = getImageUrl,
                    modifier = Modifier.padding(top = 12.dp, end = 8.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }
        Column(
            modifier = Modifier
                .padding(top = 12.dp)
                .weight(1f),
            horizontalAlignment = when (textAlign) {
                TextAlign.Center -> Alignment.CenterHorizontally
                TextAlign.Right -> Alignment.End
                else -> Alignment.Start
            }
        ) {
            // compulsory_consent can be true on any entry of ct_cp_map_bucket (one per
            // pii label/process/vendor), not just the first
            val isCompulsory = bucket.ctcpList?.any { it.compulsoryConsent == true } == true
            Text(
                text = if (isCompulsory) {
                    buildAnnotatedString {
                        append(bucket.consentPurposeName ?: "")
                        withStyle(SpanStyle(color = Color.Red)) { append(" *") }
                    }
                } else {
                    buildAnnotatedString { append(bucket.consentPurposeName ?: "") }
                },
                style = TextStyleHelper.smallHeading,
                textAlign = textAlign
            )
            Log.d("consent description", "${bucket.consentPurposeDescription}")
            bucket.consentPurposeDescription?.let {
                ConsentHtmlContent(
                    html = it,
                    headerBgColor = section?.tableStyling?.headerBgColor,
                    headerTextColor = section?.tableStyling?.headerTextColor,
                )
            }

            // Badges Parity
            if (fc?.piiSection?.showBadges == true && !bucket.piiLabels.isNullOrEmpty()) {
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("PII: ", style = TextStyleHelper.smallHeading.copy(fontSize = 12.sp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        bucket.piiLabels.forEach { label ->
                            Badge(containerColor = Utils.hexToColor(fc.form?.colorScheme)) {
                                Text(
                                    label,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (!bucket.processes.isNullOrEmpty()) {
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Process: ", style = TextStyleHelper.smallHeading.copy(fontSize = 12.sp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        bucket.processes.forEach { p ->
                            Badge(containerColor = Utils.hexToColor(fc?.form?.colorScheme)) {
                                Text(
                                    p,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
        if (showIndividualInput && inputOnRight) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(modifier = Modifier.padding(top = 12.dp)) {
                ConsentInputControl(
                    fc = fc,
                    value = status,
                    disabled = false,
                    interactive = false,
                    onChanged = {})
            }
        }
    }
}

/** Parses a px-string dimension (e.g. "200", "200px") into Dp, falling back when absent/invalid. */
fun parsePxToDp(value: String?, fallback: Float): Dp {
    val parsed = value?.trim()?.replace("px", "")?.toFloatOrNull()
    return (parsed ?: fallback).dp
}


fun parsePxToDpOrNull(value: String?): Dp? =
    value?.trim()?.replace("px", "")?.toFloatOrNull()?.dp


/** Not private: reused by the TV SDK to keep the dynamic-vs-single-submit-button decision identical across both. */
fun shouldShowDynamicButtons(fc: ConsentFormResponse.FormConfiguration?): Boolean {
    val actionButtons = fc?.actionButtons
    if (actionButtons.isNullOrEmpty()) return false
    if (actionButtons.count { it.enabled != false } <= 1) return false
    val secondaryEnabled =
        actionButtons.firstOrNull { it.handler?.lowercase() == "submit_current_selection" }?.enabled
            ?: false
    val tertiaryEnabled =
        actionButtons.firstOrNull { it.handler?.lowercase() == "accept_all_mandatory" }?.enabled
            ?: false
    val rejectEnabled =
        actionButtons.firstOrNull { it.handler?.lowercase() == "nothing" }?.enabled ?: false
    return secondaryEnabled || tertiaryEnabled || rejectEnabled
}

@Composable
fun SubmitActionSection(
    viewModel: ConsentFormViewModel,
    fc: ConsentFormResponse.FormConfiguration?,
    onPrivacyPolicyClick: () -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val useDynamicButtons = shouldShowDynamicButtons(fc)
    val actionButtons =
        if (useDynamicButtons) fc?.actionButtons?.filter { it.enabled != false } else null
    val isSubmitting by viewModel.isSubmitting.collectAsState()
    var showExitDialog by remember { mutableStateOf(false) }
    val cm = fc?.confirmationModal
//    print('')
    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = {},
            title = {
                Text(
                    text = cm?.headingText ?: ""
                )
            },
            text = {
                Text(
                    text = cm?.bodyText ?: ""
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Utils.hexToColor(cm?.cancelSignupButton?.color ?: "00000"),
                    )
                ) {
                    Text(
                        cm?.cancelSignupButton?.text ?: "Cancel",
                        color = Utils.hexToColor(cm?.cancelSignupButton?.textColor ?: "#FFFFFF")
                    )
                }
            },
            dismissButton = {

                TextButton(
                    onClick = { showExitDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Utils.hexToColor(cm?.goBackButton?.color ?: "#BDBDBD"),
                    )
                ) {
                    Text(
                        cm?.goBackButton?.text ?: "Go Back",
                        color = Utils.hexToColor(cm?.goBackButton?.textColor ?: "#FFFFFF")
                    )
                }
            }
        )
    }

    Surface(color = Color.White, shadowElevation = 8.dp) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = boxAlignment(fc?.sectionAlignments?.banner)
        ) {
            val hasMandatoryConsentsSelected by viewModel.hasMandatoryConsentsSelected.collectAsState()
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(16.dp)
            ) {
                if (actionButtons.isNullOrEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (fc?.form?.showPrivacyPolicyUrl != false) {
                            OutlinedButton(
                                modifier = Modifier.weight(1f),
                                onClick = onPrivacyPolicyClick,
                                shape = getButtonShape(
                                    fc?.submitButton?.shape,
                                    fc?.submitButton?.borderRadius?.toString()
                                ),
                                border = BorderStroke(1.dp, Utils.hexToColor(fc?.form?.colorScheme))
                            ) {
                                Text(
                                    fc?.form?.privacyPolicyUrlText ?: "Privacy Policy",
                                    color = Utils.hexToColor(fc?.form?.colorScheme)
                                )
                            }
                        }
                        Button(
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.submit(context) },
                            enabled = !isSubmitting && hasMandatoryConsentsSelected,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasMandatoryConsentsSelected) {
                                    Utils.hexToColor(fc?.form?.colorScheme)
                                } else {
                                    Color.Gray
                                },
                                disabledContainerColor = if (!hasMandatoryConsentsSelected) {
                                    Color.Gray
                                } else {
                                    Utils.hexToColor(fc?.form?.colorScheme)
                                },
                                disabledContentColor = Color.White
                            ),

                            shape = getButtonShape(
                                fc?.submitButton?.shape,
                                fc?.submitButton?.borderRadius?.toString()
                            )
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = LocalContentColor.current
                                )
                            } else {
                                Text(fc?.submitButton?.text ?: "Submit")
                            }
                        }
                    }
                } else {

                    @Composable
                    fun dynamicButton(
                        action: ConsentFormResponse.ActionButton,
                        modifier: Modifier
                    ) {
                        val id = action.handler?.lowercase()
                        val isExitButton = action.actsAsExitButton == true
                        val isSubmitCurrent = id == "submit_current_selection" && !isExitButton
                        val onClick: () -> Unit = {
                            if (isExitButton) {
                                showExitDialog = true
                            } else {
                                when (id) {
                                    "accept_all" -> viewModel.acceptAllAndSubmit(context)
                                    "accept_all_mandatory" -> viewModel.acceptRequiredAndSubmit(
                                        context
                                    )

                                    "nothing" -> viewModel.doNothing(context)
                                    "submit_current_selection" -> viewModel.submit(context)
                                    else -> viewModel.submit(context)
                                }
                            }
                        }
                        val containerColor = if (isSubmitCurrent && !hasMandatoryConsentsSelected) {
                            Color.Gray
                        } else {
                            Utils.hexToColor(action.color ?: fc?.form?.colorScheme)
                        }
                        val textColor = Utils.hexToColor(action.textColor ?: "#FFFFFF")
                        Button(
                            onClick = onClick,
                            enabled = !isSubmitting && (!isSubmitCurrent || hasMandatoryConsentsSelected),
                            modifier = modifier,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = containerColor,
                                contentColor = textColor,
                                disabledContainerColor = if (isSubmitCurrent && !hasMandatoryConsentsSelected) Color.Gray else containerColor,
                                disabledContentColor = textColor
                            ),
                            shape = getButtonShape(action.shape, action.borderRadius),
                            border = action.borderColor?.let {
                                BorderStroke(
                                    parsePxToDp(action.borderWidth, fallback = 1f),
                                    Utils.hexToColor(it)
                                )
                            }
                        ) {
                            Text(action.text ?: action.handler ?: "Submit")
//                            if (isSubmitting) {
//                                CircularProgressIndicator(
//                                    modifier = Modifier.size(18.dp),
//                                    strokeWidth = 2.dp,
//                                    color = textColor
//                                )
//                            } else {
//                                Text(action.text ?: action.id ?: "Submit")
//                            }
                        }
                    }
                    if ((fc?.buttonOrientation ?: "horizontal").lowercase() == "vertical") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            actionButtons.forEach { action ->
                                dynamicButton(action, Modifier.fillMaxWidth())
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            actionButtons.forEach { action ->
                                dynamicButton(action, Modifier)
                            }
                        }
                    }
                }
            }
        }
    }
}
