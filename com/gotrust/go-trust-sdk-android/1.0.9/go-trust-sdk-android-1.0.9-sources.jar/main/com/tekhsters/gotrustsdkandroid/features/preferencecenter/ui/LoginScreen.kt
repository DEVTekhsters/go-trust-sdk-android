package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.core.ui.ShowImage
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.core.utils.getFontWeight
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.LanguageSelector
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.parsePxToDp
import java.util.Calendar

private fun px(value: String?, fallback: Double = 0.0): Double {
    if (value.isNullOrEmpty()) return fallback
    return value.replace("px", "").trim().toDoubleOrNull() ?: fallback
}

@Composable
fun LoginScreen(viewModel: PreferenceCenterViewModel, onClose: () -> Unit, onErrorClose: () -> Unit) {
    val config by viewModel.loginConfig.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()
    val cfg = config?.configuration
    val userInfoCfg = cfg?.userInputConfiguration

    if (cfg == null || userInfoCfg == null) {
        Scaffold { padding ->
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(PREFERENCE_CENTER_LOAD_ERROR_MESSAGE)
                    Spacer(Modifier.height(8.dp))
                    Row {
                        Button(onClick = onErrorClose) { Text("Go Back") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { viewModel.loadLoginConfig() }) { Text("Retry") }
                    }
                }
            }
        }
        return
    }

    val logo = cfg.logoUrl
    val shouldShowLogo = (cfg.showLogo ?: true) && (userInfoCfg.logo?.showLogo ?: true)
    val bannerBg = userInfoCfg.banner?.backgroundColor ?: "#ffffff"
    val submitBg = userInfoCfg.submitButton?.backgroundColor ?: userInfoCfg.submitButton?.color ?: "#2b6bec"
    val submitTextColor = userInfoCfg.submitButton?.textColor ?: "#ffffff"
    val submitText = userInfoCfg.submitButton?.text ?: "Login"
    val submitHeight = userInfoCfg.submitButton?.height ?: 56.0
    val accentColor = userInfoCfg.submitButton?.color ?: "#2b6bec"
    val emailCfg = userInfoCfg.emailInput
    val universalFontFamily = userInfoCfg.fontFamily
    val submitRadius = userInfoCfg.submitButton?.borderRadius ?: px(userInfoCfg.borderRadius, 10.0)

    Scaffold(
        containerColor = Utils.hexToColor(bannerBg),
        topBar = {
            DynamicHeaderAppBar(
                closeIconPosition = userInfoCfg.headerLayout?.closeIconPosition,
                logoPosition = userInfoCfg.headerLayout?.logoPosition,
                dropdownPosition = userInfoCfg.headerLayout?.dropdownPosition,
                backgroundColor = userInfoCfg.banner?.backgroundColor ?: "#ffffff",
                onClose = onClose,
                logo = if (!viewModel.headerLogo.isNullOrEmpty() ||
                    (shouldShowLogo && !logo.isNullOrEmpty())) {
                    {
                        ShowImage(
                            iconObjectKey = viewModel.headerLogo ?: logo,
                            getImageUrl = viewModel::getImageUrl,
                            iconWidth = userInfoCfg?.logo?.width ?: "140",
                            iconHeight = userInfoCfg?.logo?.height ?: "48"
                        )
                    }
                } else null,
                dropdown = if (cfg.consentPurposeConfiguration?.form?.showLanguage == true) {
                    {
                        LanguageSelector(
                            languages = languages.ifEmpty {
                                listOf(com.tekhsters.gotrustsdkandroid.features.consentform.models.Language("en", "English"))
                            },
                            selectedCode = lang,
                            onChanged = { viewModel.onLanguageChanged(it) },
                            colorHex = userInfoCfg.languageDropdown?.backgroundColor ?: "#000000",
                            textColor = userInfoCfg.languageDropdown?.textColor ?: "#000000",
                        )
                    }
                } else null,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .background(Utils.hexToColor(bannerBg))
                .padding(horizontal = 20.dp, vertical = 16.dp),
        ) {
            if (!userInfoCfg.heading?.text.isNullOrEmpty()) {
                Text(
                    text = userInfoCfg.heading?.text ?: "",
                    color = Utils.hexToColor(userInfoCfg.heading?.color ?: "#000000"),
                    fontSize = px(userInfoCfg.heading?.size, 18.0).sp,
                    fontWeight = getFontWeight(userInfoCfg.heading?.fontWeight),
                )
                Spacer(Modifier.height(6.dp))
            }
            if (!userInfoCfg.description?.text.isNullOrEmpty()) {
                Text(
                    text = userInfoCfg.description?.text ?: "",
                    color = Utils.hexToColor(userInfoCfg.description?.color ?: "#000000"),
                    fontSize = px(userInfoCfg.description?.size, 14.0).sp,
                    fontWeight = getFontWeight(userInfoCfg.description?.fontWeight),
                )
            }
            Spacer(Modifier.height(18.dp))

            val context = androidx.compose.ui.platform.LocalContext.current
            config?.subjectIdentityTypes.orEmpty().forEach { si ->
                val id = si.id ?: return@forEach
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val isPhone = PhoneIdentity.isPhoneLabel(si.name)
                    val isDob = si.name?.trim()?.equals("Date of Birth", ignoreCase = true) == true || si.name?.trim()?.equals("dob", ignoreCase = true) == true

                    val showDatePicker = {
                        val cal = java.util.Calendar.getInstance()
                        val currentValue = viewModel.subjectIdentityInputs[id]
                        if (!currentValue.isNullOrBlank()) {
                            try {
                                val parts = currentValue.split("/", "-")
                                if (parts.size == 3) {
                                    if (parts[0].length == 4) {
                                        cal.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt())
                                    } else {
                                        cal.set(parts[2].toInt(), parts[1].toInt() - 1, parts[0].toInt())
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                        val dialog = android.app.DatePickerDialog(
                            context,
                            { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                                val formattedDate = String.format(java.util.Locale.US, "%02d/%02d/%04d", selectedDayOfMonth, selectedMonth + 1, selectedYear)
                                viewModel.onSubjectIdentityChanged(id, formattedDate)
                            },
                            cal.get(java.util.Calendar.YEAR),
                            cal.get(java.util.Calendar.MONTH),
                            cal.get(java.util.Calendar.DAY_OF_MONTH)
                        )
                        val minCal = Calendar.getInstance()
                        minCal.add(Calendar.YEAR, -125)
                        dialog.datePicker.minDate = minCal.timeInMillis
                        dialog.datePicker.maxDate = System.currentTimeMillis()
                        dialog.show()
                    }

                    val textField = @Composable {
                        OutlinedTextField(
                            value = viewModel.subjectIdentityInputs[id] ?: "",
                            onValueChange = { if (!isDob) viewModel.onSubjectIdentityChanged(id, it) },
                            enabled = viewModel.isEditingSubjectIdentity(id),
                            label = { Text(si.name ?: "Identity") },
                            placeholder = if (isDob) { { Text("Select Date") } } else null,
                            // Static, non-editable dialling code. It is part of the value submitted to
                            // the API but never part of what the user can edit.
                            prefix = if (isPhone) {
                                { Text(PhoneIdentity.COUNTRY_CODE) }
                            } else null,
                            trailingIcon = if (isDob) {
                                {
                                    IconButton(onClick = { if (viewModel.isEditingSubjectIdentity(id)) showDatePicker() }) {
                                        Icon(
                                            imageVector = Icons.Default.DateRange,
                                            contentDescription = "Select Date"
                                        )
                                    }
                                }
                            } else null,
                            keyboardOptions = if (isPhone) {
                                KeyboardOptions(keyboardType = KeyboardType.Phone)
                            } else {
                                KeyboardOptions.Default
                            },
                            singleLine = true,
                            shape = RoundedCornerShape((emailCfg?.borderRadius ?: 8.0).dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Utils.hexToColor(emailCfg?.backgroundColor ?: "#ffffff"),
                                unfocusedContainerColor = Utils.hexToColor(emailCfg?.backgroundColor ?: "#ffffff"),
                                focusedBorderColor = Utils.hexToColor(emailCfg?.borderColor ?: "#C0CDE0"),
                                unfocusedBorderColor = Utils.hexToColor(emailCfg?.borderColor ?: "#C0CDE0"),
                                focusedTextColor = Utils.hexToColor(emailCfg?.textColor ?: "#000000"),
                                unfocusedTextColor = Utils.hexToColor(emailCfg?.textColor ?: "#000000"),
                            ),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }

                    if (isDob) {
                        Box(modifier = Modifier.weight(1f)) {
                            textField()
                            if (viewModel.isEditingSubjectIdentity(id)) {
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .clickable { showDatePicker() }
                                )
                            }
                        }
                    } else {
                        Box(modifier = Modifier.weight(1f)) {
                            textField()
                        }
                    }

                    // Every identity gets its own toggle — with more than one configured, a single
                    // button read as though only the first row could be changed.
                    IconButton(onClick = { viewModel.toggleEditingSubjectIdentity(id) }) {
                        Icon(
                            if (viewModel.isEditingSubjectIdentity(id)) Icons.Default.Check else Icons.Default.Edit,
                            contentDescription = if (viewModel.isEditingSubjectIdentity(id)) {
                                "Done editing ${si.name ?: "identity"}"
                            } else {
                                "Edit ${si.name ?: "identity"}"
                            },
                            tint = Utils.hexToColor(accentColor),
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { viewModel.submitLogin() },
                enabled = !isBusy,
                shape = RoundedCornerShape(submitRadius.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Utils.hexToColor(submitBg)),
                modifier = Modifier.fillMaxWidth().height(submitHeight.dp),
            ) {
                if (isBusy) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.height(20.dp))
                } else {
                    Text(
                        text = submitText,
                        color = Utils.hexToColor(submitTextColor),
                        fontSize = px(userInfoCfg.submitButton?.size, 16.0).sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}
