package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import android.content.Context
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.core.ui.ShowImage
import com.tekhsters.gotrustsdkandroid.core.ui.TvShowImage
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.core.utils.getButtonShape
import com.tekhsters.gotrustsdkandroid.core.utils.getFontWeight
import com.tekhsters.gotrustsdkandroid.core.utils.stripHtmlTv
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse
import com.tekhsters.gotrustsdkandroid.core.ui.TvButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvCheckbox
import com.tekhsters.gotrustsdkandroid.core.ui.TvFocusableCard
import com.tekhsters.gotrustsdkandroid.core.ui.TvIconButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvSwitch
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.ui.TvTextEntryField
import com.tekhsters.gotrustsdkandroid.core.utils.DynamicTextWidget
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import com.tekhsters.gotrustsdkandroid.core.utils.Utils
import com.tekhsters.gotrustsdkandroid.core.utils.accentOrDefault

/**
 * TV counterpart of the mobile SDK's `ConsentFormScreen`: same [ConsentFormViewModel], same CMS
 * config surface (dynamic action buttons, category/purpose ordering, badges, check-all, minor-form
 * PII grouping, consent input type/position) — [getOrderedCategories]/[getOrderedPurposes]/
 * [shouldShowDynamicButtons] are the exact functions mobile's `ConsentFormScreen.kt` uses, reused
 * unchanged so both surfaces order/branch identically. Only per-field alignment/spacing config
 * (`section_alignments`, `spacing`) is intentionally not replicated — a D-pad-only remote has no
 * pointer/hover model for that kind of pixel-level layout, so this presentation layer stays a
 * single focus-traversable column instead.
 */
@Composable
fun ConsentFormTvScreen(
    viewModel: ConsentFormViewModel,
    onClose: () -> Unit,
    showCrossButton: Boolean,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val form by viewModel.consentForm.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val checkAllStatus by viewModel.checkAllStatus.collectAsState()
    val invalidPiiKeys by viewModel.invalidPiiKeys.collectAsState()
    val piiValues = viewModel.piiValues
    viewModel.consentRevision.collectAsState().value // subscribe to in-place consentStatus mutations
    val isSubmitting by viewModel.isSubmitting.collectAsState()

    val fc = form?.formConfiguration
    val bi = form?.basicInfo
    val section = fc?.consentCollectionSection
    val accent = accentOrDefault(fc?.form?.colorScheme)
    val isMinorForm = !form?.piiList?.consentActorPiiList.isNullOrEmpty()

    val dataPrincipalPii = form?.piiList?.dataPrincipalPiiList.orEmpty()
    val consentActorPii = form?.piiList?.consentActorPiiList.orEmpty()
    val mandatoryPiiIds = remember(form) { viewModel.getMandatoryPiiIds() }

    val categories = getOrderedCategories(
        (form?.categoryList?.dataPrincipalCategoryList.orEmpty() + form?.categoryList?.consentActorCategoryList.orEmpty())
            .filter { it.visible != false },
        fc,
    )

    val enableCategoryLevel = section?.enableCategoryLevelConsent == true

    val listState = rememberLazyListState()
    val getImageUrl = viewModel::getImageUrl

    val headingLayoutConfig = fc?.form?.headingLayoutConfig
//
//    val iconObjectKey = fc?.form?.logo?.logoUrl
//    var imageUrl by remember(iconObjectKey) {
//        mutableStateOf<String?>(null)
//    }
//
//    LaunchedEffect(iconObjectKey) {
//        if (iconObjectKey != null) {
//            imageUrl = getImageUrl(iconObjectKey)
//        }
//    }
fun shouldShowDynamicButtons(fc: ConsentFormResponse.FormConfiguration?): Boolean {
    val actionButtons = fc?.actionButtons
    if (actionButtons.isNullOrEmpty()) return false
    if (actionButtons.count { it.enabled != false } <= 1) return false
    val secondaryEnabled = actionButtons.firstOrNull { it.handler?.lowercase() == "submit_current_selection" }?.enabled ?: false
    val tertiaryEnabled = actionButtons.firstOrNull { it.handler?.lowercase() == "accept_all_mandatory" }?.enabled ?: false
    val rejectEnabled = actionButtons.firstOrNull { it.handler?.lowercase() == "nothing" }?.enabled ?: false
    return secondaryEnabled || tertiaryEnabled || rejectEnabled
}

    val useDynamicButtons = shouldShowDynamicButtons(fc)

    Column(modifier = modifier.fillMaxSize().background(TvColors.background)) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 20.dp)
        ) {
            // Logo (left)
            Row(
                modifier = Modifier.align(Alignment.CenterStart),
                verticalAlignment = Alignment.CenterVertically
            ) {
                fc?.form?.logo?.let { logo ->
                    if (logo.showLogo == true && !logo.logoUrl.isNullOrEmpty()) {
                        TvShowImage(
                            iconObjectKey = logo.logoUrl,
                            iconWidth = logo.width ,
                            iconHeight = logo.height,
                            getImageUrl = getImageUrl,
                            modifier = if (headingLayoutConfig?.headingLayout?.lowercase() == "body") Modifier.fillMaxWidth() else Modifier,
                            alignment = boxAlignment(
                                headingLayoutConfig?.logoPosition ,
                                fallback = Alignment.CenterStart
                            )
                        )
                    }
                }
            }
            Log.d("show logo","${fc?.form?.logo?.showLogo}")

            // Text (center)
            Column(
                modifier = Modifier
                    .fillMaxWidth(1f),

                horizontalAlignment = if (fc?.form?.logo?.showLogo == true) {
                    Alignment.CenterHorizontally
                } else {
                    Alignment.Start
                }
            ) {
                if (headingLayoutConfig?.headingLayout?.lowercase() != "body"){
                TvText(
                    text = fc?.form?.heading?.text?.ifEmpty { null } ?: (bi?.title ?: "Consent"),
                    fontSize = 26.sp,
                    fontWeight =  getFontWeight(fc?.form?.heading?.fontWeight) ?:  FontWeight.Bold
                )
                }
            }

            // Language & Close (right)
            Row(
                modifier = Modifier.align(Alignment.CenterEnd),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (fc?.form?.showLanguage == true && languages.isNotEmpty()) {
                    LanguageSelectorTv(
                        languages = languages,
                        selectedCode = selectedLanguage,
                        onChanged = { viewModel.onLanguageChanged(it) },
                    )
                    Box(Modifier.size(16.dp))
                }
                if (showCrossButton) {
                    TvIconButton(onClick = onClose) {
                        Icon(Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TvColors.textPrimary
                        )
                    }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            fc?.form?.illustrationImage?.let { img ->
                if (img.showIllustrationImage == true && !img.illustrationImageUrl.isNullOrEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
//                            AsyncImage(
//                                model = img.illustrationImageUrl,
//                                contentDescription = "Illustration",
//                                modifier = Modifier.fillMaxWidth(0.6f).height(parsePxToDp(img.height, fallback = 200f)),
//                                contentScale = ContentScale.Fit,
//                            )

                            val configuredWidth = parsePxToDpOrNull(img.width)
                            ShowImage(
                                iconObjectKey = img.illustrationImageUrl,
                                getImageUrl = getImageUrl,
                                modifier = Modifier
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                                    .let { if (configuredWidth != null) it.width(configuredWidth) else it.fillMaxWidth() }
                                    .height(parsePxToDp(img.height, fallback = 200f)),

                                )
                        }
                    }
                }
            }

            if(headingLayoutConfig?.headingLayout?.lowercase() == "body" && fc?.form?.heading?.text != null){
             item {
                 TvText(
                     text = fc?.form?.heading?.text?.ifEmpty { null } ?: (bi?.title ?: "Consent"),
                     fontSize = 26.sp,
                     fontWeight = getFontWeight(fc?.form?.heading?.fontWeight)
                 )
//                 Log.e("description", "${bi?.description}")
//                 if (!bi?.description.isNullOrEmpty()) {
//                     Box(Modifier.size(4.dp))
//                     TvText(
//                         text = bi?.description ?: "",
//                         color = TvColors.textSecondary,
//                         fontSize = 14.sp
//                     )
//                 }
             }
            }


            if (!fc?.form?.description?.text.isNullOrEmpty()) {
                item {
                    TvText(
                        fc?.form?.description?.text ?: "",
                        fontSize = 16.sp,
                        fontWeight = getFontWeight(fc?.form?.description?.fontWeight),

                    )
                }
            }

            if (!fc?.piiSection?.heading?.text.isNullOrEmpty()) {
                item {
                    TvText(fc?.piiSection?.heading?.text ?: "",
                    fontSize = 20.sp,
                    fontWeight = getFontWeight(fc?.piiSection?.heading?.fontWeight),
                    ) }
            }

            if (!fc?.piiSection?.description?.text.isNullOrEmpty()) {
                item { TvText(fc?.piiSection?.description?.text ?: "", color = TvColors.textSecondary, fontSize = 14.sp) }
            }

            if (fc?.piiSection?.showPiiSection == true) {
                if (dataPrincipalPii.isNotEmpty()) {
                    val heading = if (isMinorForm) fc?.piiSection?.dataPrincipalHeading?.text else null
                    if (!heading.isNullOrEmpty()) item { TvText(heading, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                    items(dataPrincipalPii) { pii ->
                        PiiFieldTv(pii, piiValues, invalidPiiKeys, mandatoryPiiIds, onValueChange = { key, value -> viewModel.onPiiValueChanged(key, value) })
                    }
                }
                if (consentActorPii.isNotEmpty()) {
                    val heading = if (isMinorForm) fc?.piiSection?.consentActorHeading?.text else null
                    if (!heading.isNullOrEmpty()) item { TvText(heading, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                    items(consentActorPii) { pii ->
                        PiiFieldTv(pii, piiValues, invalidPiiKeys, mandatoryPiiIds, onValueChange = { key, value -> viewModel.onPiiValueChanged(key, value) })
                    }
                }
            }

//            if (!bi?.preferenceInputHeading.isNullOrEmpty()) {
//                item { TvText(bi?.preferenceInputHeading ?: "", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
//            }

            if (section?.showCheckAllCheckbox == true) {
                item {
                    val revision by viewModel.consentRevision.collectAsState()
                    val checked = revision.let { checkAllStatus }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        ConsentInputControlTv(
                            inputType = section.consentInputType,
                            checked = checked,
                            accent = accent,
                            onCheckedChange = { viewModel.toggleCheckAll(it) },
                        )
                        Box(Modifier.size(12.dp))
                        TvText(section.allCheckboxText ?: "Check All", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }
                }
            }

            if (categories.isEmpty()) {
                item { TvText("No categories available", color = TvColors.textSecondary, fontSize = 13.sp) }
            } else if (enableCategoryLevel) {
                items(categories) { category ->
                    ConsentCategoryTvCard(category, getImageUrl, viewModel, fc, section, accent)
                }
            } else {
                categories.forEach { category ->
                    getOrderedPurposes(category, fc).forEach { purpose ->
                        if (purpose.visible != false) {
                            purpose.buckets.orEmpty().filter { it.visible != false }.forEach { bucket ->
                                item { ConsentBucketTvRow(bucket, getImageUrl, viewModel, fc, section, accent) }
                            }
                        }
                    }
                }
            }

            if (!fc?.formFooter?.description?.text.isNullOrEmpty()) {
                item {
                    TvText(
                        stripHtmlTv(fc?.formFooter?.description?.text),
                        color = TvColors.textSecondary,
                        fontSize = 13.sp,
                    )
                }
            }


            // Mirrors mobile's ConsentFormScreen: the Privacy Notice link sits inside the scroll
            // content only in the dynamic-action-buttons layout — the single-Submit layout keeps
            // it as a button beside Submit in the footer instead.
            if (useDynamicButtons && fc?.form?.showPrivacyPolicyUrl != false) {
                item {
                    TvButton(
                        fc?.form?.privacyPolicyUrlText ?: "Privacy Notice",
                        onClick = { viewModel.showPrivacyNotice() },
                        primary = false,
                        borderColor = Color.Black,
                    )
                }
            }

            item { Box(Modifier.size(8.dp)) }
        }

        // Footer actions
        if (useDynamicButtons) {
            val actionButtons = if (useDynamicButtons) fc?.actionButtons?.filter { it.enabled != false } else null
            val hasPartialSelection by viewModel.hasPartialSelection.collectAsState()
            val visibleButtons = actionButtons?.filter { action ->
                action.handler?.lowercase() != "submit_current_selection" || hasPartialSelection
            }
            val vertical = (fc?.buttonOrientation ?: "horizontal").lowercase() == "vertical"
            if (vertical) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    visibleButtons?.forEach { action ->
                        TvDynamicActionButton(action, accent, isSubmitting, viewModel,fc, context, onClose =  onClose, modifier = Modifier.fillMaxWidth())
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    visibleButtons?.forEach { action ->
                        TvDynamicActionButton(action, accent, isSubmitting, viewModel, fc,context ,onClose ,Modifier.weight(1f))
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (fc?.form?.showPrivacyPolicyUrl != false) {
                    TvButton(
                        fc?.form?.privacyPolicyUrlText ?: "Privacy Policy",
                        onClick = { viewModel.showPrivacyNotice() },
                        primary = false,
                        modifier = Modifier.weight(1f),
                        borderColor = Color.Black,
                    )
                }
                TvButton(
                    if (isSubmitting) "Submitting…" else (fc?.submitButton?.text ?: "Submit"),
                    onClick = { viewModel.submit(context) },
                    enabled = !isSubmitting,
                    accent = accent,
                    shape = getButtonShape(fc?.submitButton?.shape, fc?.submitButton?.borderRadius),
                    modifier = Modifier.weight(1f),
                    borderColor = Color.Black,
                )
            }
        }
    }
}

@Composable
private fun ConsentInputControlTv(
    inputType: String?,
    checked: Boolean,
    accent: Color,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit,
) {
    if ((inputType ?: "checkbox").lowercase() == "toggle") {
        TvSwitch(checked = checked, onCheckedChange = onCheckedChange, accent = accent, enabled = enabled)
    } else {
        TvCheckbox(checked = checked, onCheckedChange = onCheckedChange, accent = accent, enabled = enabled)
    }
}

@Composable
private fun PiiFieldTv(
    pii: ConsentFormResponse.PiiLabel,
    piiValues: MutableMap<String, String>,
    invalidPiiKeys: Set<String>,
    mandatoryPiiIds: Set<String>,
    onValueChange: (key: String, value: String) -> Unit,
) {
    val key = "${pii.principalContext ?: ""}_${pii.id}"
    val isPhone = PhoneIdentity.isPhoneLabel(pii.name, pii.regEx)
    val isMandatory = mandatoryPiiIds.contains(Utils.safeIdString(pii.id))
    TvTextEntryField(
        label = pii.name ?: "Field",
        value = piiValues[key] ?: "",
        onValueChange = { onValueChange(key, it) },
        prefix = if (isPhone) PhoneIdentity.COUNTRY_CODE else null,
        numeric = isPhone,
        mandatory = isMandatory,
        isInvalid = key in invalidPiiKeys,
        maxLength = if (isPhone) 10 else null,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun ConsentCategoryTvCard(
    category: ConsentFormResponse.Category,
    getImageUrl: suspend (String?) -> String?,
    viewModel: ConsentFormViewModel,
    fc: ConsentFormResponse.FormConfiguration?,
    section: ConsentFormResponse.ConsentCollectionSection?,
    accent: Color,
) {
    val revision by viewModel.consentRevision.collectAsState()
    var expanded by remember { mutableStateOf(false) }
    val isSelected = revision.let { viewModel.isCategorySelected(category) }
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"
    val showCategoryControl = section?.showConsentInput != false &&
            section?.showCategoryConsentInput != false &&
            section?.showCheckAllCheckbox != true

    val categoryIdStr = parseOrderInt(category.processingPurposeCategoryId)?.toString()
    val config = section?.categoryConfig?.get(categoryIdStr)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TvColors.surface, RoundedCornerShape(12.dp))
            .focusGroup()
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {

            if (showCategoryControl && !inputOnRight) {
                ConsentInputControlTv(
                    inputType = section?.consentInputType,
                    checked = isSelected,
                    accent = accent,
                    onCheckedChange = { viewModel.toggleCategoryConsent(category, it) },
                )
                Box(Modifier.size(12.dp))
                if(! section?.categoryConfig.isNullOrEmpty()){
                   TvShowImage(
                   iconObjectKey = config?.iconUrl,
                   iconWidth = config?.iconWidth,
                   iconHeight = config?.iconHeight,
                   getImageUrl = getImageUrl
                  )
                }
                Box(Modifier.size(12.dp))
            }

            TvFocusableCard(
                onClick = { expanded = !expanded },
                modifier = Modifier.weight(1f),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TvText(category.processingPurposeCategoryName ?: "", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Box(Modifier.size(8.dp))
                    TvText(if (expanded) "▲" else "▼", color = TvColors.textSecondary)
                }
            }

            if (showCategoryControl && inputOnRight) {
                Box(Modifier.size(12.dp))
                if(! section?.categoryConfig.isNullOrEmpty()) {
                    TvShowImage(
                        iconObjectKey = config?.iconUrl,
                        iconWidth = config?.iconWidth,
                        iconHeight = config?.iconHeight,
                        getImageUrl = getImageUrl
                    )
                }

            Box(Modifier.size(12.dp))

                ConsentInputControlTv(
                    inputType = section?.consentInputType,
                    checked = isSelected,
                    accent = accent,
                    onCheckedChange = { viewModel.toggleCategoryConsent(category, it) },
                )
            }
        }
        if (expanded) {
            Box(Modifier.size(10.dp))
            Column(Modifier.padding(horizontal = 4.dp)) {
                getOrderedPurposes(category, fc).forEach { purpose ->
                    if (purpose.visible != false) {
                        purpose.buckets.orEmpty().filter { it.visible != false }.forEach { bucket ->
                            ConsentBucketTvRow(bucket, getImageUrl, viewModel, fc, section, accent)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ConsentBucketTvRow(
    bucket: ConsentFormResponse.ConsentBucket,
    getImageUrl: suspend (String?) -> String?,
    viewModel: ConsentFormViewModel,
    fc: ConsentFormResponse.FormConfiguration?,
    section: ConsentFormResponse.ConsentCollectionSection?,
    accent: Color,
) {
    val revision by viewModel.consentRevision.collectAsState()
    val ct = bucket.ctcpList?.firstOrNull() ?: return
    val checked = revision.let { ct.consentStatus == true }
    val isCompulsory = bucket.ctcpList.orEmpty().any { it.compulsoryConsent == true }

    val showIndividualInput = section?.showConsentInput != false && section?.showIndividualChecks != false
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"

    val consentPurposeId = parseOrderInt(bucket.consentPurposeId)?.toString()
    val config = section?.purposeConfig?.get(consentPurposeId)

//    val iconObjectKey = config?.iconUrl
//    var imageUrl by remember(iconObjectKey) {
//        mutableStateOf<String?>(null)
//    }

//    LaunchedEffect(iconObjectKey) {
//        if (iconObjectKey != null) {
//            imageUrl = getImageUrl(iconObjectKey)
//        }
//    }



    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (showIndividualInput && !inputOnRight) {
            ConsentInputControlTv(
                inputType = section?.consentInputType,
                checked = checked,
                accent = accent,
                enabled = true,
                onCheckedChange = {
                    ct.consentStatus = it
                    viewModel.syncCheckAllStatus()
                },
            )
            Box(Modifier.size(12.dp))
            if(! section?.purposeConfig.isNullOrEmpty()) {
                TvShowImage(
                    iconObjectKey = config?.iconUrl,
                    iconWidth = config?.iconWidth,
                    iconHeight = config?.iconHeight,
                    getImageUrl = getImageUrl,
                    modifier = Modifier.padding(top = 12.dp, end = 8.dp)
                )
            }

        Box(Modifier.size(12.dp))
        }
        Column(Modifier.weight(1f)) {
            TvText(
                text = if (isCompulsory) {
                    buildAnnotatedString {
                        append(bucket.consentPurposeName ?: "")
                        withStyle(SpanStyle(color = TvColors.error)) { append(" *") }
                    }
                } else {
                    buildAnnotatedString { append(bucket.consentPurposeName ?: "") }
                },
                fontSize = 14.sp,
            )
            val description = bucket.consentPurposeDescription
            if (!description.isNullOrEmpty()) {
                ConsentHtmlContentTv(
                    html = description,
                    headerTextColor = section?.tableStyling?.headerTextColor,
                    headerBgColor = section?.tableStyling?.headerBgColor
                )
            }
            if (fc?.piiSection?.showBadges == true && !bucket.piiLabels.isNullOrEmpty()) {
                Box(Modifier.size(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TvText("PII: ", color = TvColors.textSecondary, fontSize = 11.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        bucket.piiLabels.orEmpty().forEach { label -> TvBadge(label, accent) }
                    }
                }
            }
            if (!bucket.processes.isNullOrEmpty()) {
                Box(Modifier.size(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TvText("Process: ", color = TvColors.textSecondary, fontSize = 11.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        bucket.processes.orEmpty().forEach { process -> TvBadge(process, accent) }
                    }
                }
            }
        }
        if (showIndividualInput && inputOnRight) {
            Box(Modifier.size(12.dp))
            if(! section?.purposeConfig.isNullOrEmpty()) {
                TvShowImage(
                    iconObjectKey = config?.iconUrl,
                    iconWidth = config?.iconWidth,
                    iconHeight = config?.iconHeight,
                    getImageUrl = getImageUrl,
                    modifier = Modifier.padding(top = 12.dp, end = 8.dp)
                )
            }

        Box(Modifier.size(12.dp))
            ConsentInputControlTv(
                inputType = section?.consentInputType,
                checked = checked,
                accent = accent,
                enabled = true,
                onCheckedChange = {
                    ct.consentStatus = it
                    viewModel.syncCheckAllStatus()
                },
            )
        }
    }
}

@Composable
private fun TvBadge(text: String, accent: Color) {
    Box(
        modifier = Modifier
            .background(accent, RoundedCornerShape(50)),
    ) {
        TvText(text, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }
}

@Composable
private fun TvDynamicActionButton(
    action: ConsentFormResponse.ActionButton,
    fallbackAccent: Color,
    isSubmitting: Boolean,
    viewModel: ConsentFormViewModel,
    fc: ConsentFormResponse.FormConfiguration?,
    context: Context,
    onClose: () -> Unit,
    modifier: Modifier,
) {
    val cm = fc?.confirmationModal
    var showExitDialog by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    if (showExitDialog) {
        LaunchedEffect(Unit) {
            focusRequester.requestFocus()
        }
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = {
                Text(
                    text = cm?.headingText ?: ""
                )
            },
            text = {
                Text(
                    text = cm?.bodyText ?: ""
                )
            },
            confirmButton = {
                TvButton(
                    text = cm?.cancelSignupButton?.text ?: "Cancel",
                    onClick = onClose,
                    accent = Utils.hexToColor(cm?.cancelSignupButton?.color ?: "00000"),
                    textColor = Utils.hexToColor(cm?.cancelSignupButton?.textColor ?: "#FFFFFF"),
                    borderColor = Color.Black,
                    modifier = Modifier.focusRequester(focusRequester)
                )
            },
            dismissButton = {
                TvButton(
                    text = cm?.goBackButton?.text ?: "Go Back",
                    onClick = { showExitDialog = false },
                    accent = Utils.hexToColor(cm?.goBackButton?.color ?: "#BDBDBD"),
                    textColor = Utils.hexToColor(cm?.goBackButton?.textColor ?: "#FFFFFF"),
                    borderColor = Color.Black
                )
            }
        )
    }
    val id = action.handler?.lowercase()
    val onClick:  () -> Unit = {
        if (action.actsAsExitButton != null && action.actsAsExitButton == true) {
            showExitDialog = true
        } else {
            when (id) {
                "accept_all" -> viewModel.acceptAllAndSubmit(context)
                "accept_all_mandatory" -> viewModel.acceptRequiredAndSubmit(context)
                "nothing" -> viewModel.doNothing(context)
                else -> viewModel.submit(context)
            }
        }
    }
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val containerColor = Utils.hexToColor(action.color ?: fc?.form?.colorScheme)
    val textColor = Utils.hexToColor(action.textColor ?: "#FFFFFF")
    Button(
        onClick = onClick,
        enabled = !isSubmitting,
        modifier = modifier,
        interactionSource = interactionSource,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = textColor
        ),
        shape = getButtonShape(action.shape, action.borderRadius),
        border = if (isFocused) {
            BorderStroke(2.dp, Color.Black)
        } else {
            action.borderColor?.let {
                BorderStroke(
                    parsePxToDp(action.borderWidth, fallback = 1f),
                    Utils.hexToColor(it)
                )
            }
        }
    ) {
        Text(action.text ?: action.handler ?: "Submit")
    }
}
