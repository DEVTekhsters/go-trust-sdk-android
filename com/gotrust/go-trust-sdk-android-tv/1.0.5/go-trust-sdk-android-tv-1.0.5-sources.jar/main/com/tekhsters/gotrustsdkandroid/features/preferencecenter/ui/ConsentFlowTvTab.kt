package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentRecord
import com.tekhsters.gotrustsdkandroid.core.ui.TvLoadingScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvFocusableCard
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
//
///**
// * TV counterpart of the mobile SDK's `ConsentFlowTab`. That screen relies on pinch-to-zoom/pan
// * (`detectTransformGestures`) to navigate a node graph — a touch-only interaction a D-pad-only
// * remote cannot perform at all — so this is not a styling port but a genuine rebuild: each consent
// * record becomes one D-pad-focusable card listing the same fields the graph's nodes carried.
// */
//@Composable
//fun ConsentFlowTvTab(viewModel: PreferenceCenterViewModel, modifier: Modifier = Modifier) {
//    var loading by remember { mutableStateOf(true) }
//    var records by remember { mutableStateOf<List<ConsentRecord>>(emptyList()) }
//    var error by remember { mutableStateOf<String?>(null) }
//
//    LaunchedEffect(Unit) {
//        loading = true
//        try {
//            records = viewModel.getConsentFlow()
//        } catch (e: Exception) {
//            error = e.message
//        } finally {
//            loading = false
//        }
//    }
//
//    when {
//        loading -> TvLoadingScreen(modifier)
//        error != null -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
//            TvText("Error: $error", color = TvColors.error)
//        }
//        records.isEmpty() -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
//            TvText("No data", color = TvColors.textSecondary)
//        }
//        else -> LazyColumn(
//            modifier = modifier.fillMaxSize(),
//            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 4.dp),
//            verticalArrangement = Arrangement.spacedBy(12.dp),
//        ) {
//            items(records) { record -> ConsentFlowRecordCard(record) }
//        }
//    }
//}
//
//@Composable
//private fun ConsentFlowRecordCard(record: ConsentRecord) {
//    TvFocusableCard(onClick = null, modifier = Modifier.fillMaxWidth()) {
//        Column {
//            TvText(record.piiName.ifEmpty { "Consent record" }, fontSize = 15.sp, fontWeight = FontWeight.Bold)
//            Box(Modifier.size(8.dp))
//            FlowField("Source", record.source)
//            FlowField("Collection Template", record.collectionTemplate)
//            FlowField("Subject Identity", record.subjectIdentity)
//            FlowField("Unified Person", record.unifiedPerson)
//            FlowField("Processing Activities", record.processingActivities)
//            FlowField("Consent Preferences", record.consentPreferences)
//            FlowField("Consent Status", record.consentStatus)
//            FlowField("Consented At", record.consentedAt)
//            FlowField("Language", record.language)
//            FlowField("Expired Consent", record.expiredConsent)
//            FlowField("Data Retention Expired", record.dataRetentionExpired)
//            FlowField("Latest Consent", record.latestConsent)
//        }
//    }
//}
//
//@Composable
//private fun FlowField(label: String, value: String) {
//    androidx.compose.foundation.layout.Row(modifier = Modifier.fillMaxWidth()) {
//        TvText(label, color = TvColors.textSecondary, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(0.45f))
//        TvText(value.ifEmpty { "-" }, fontSize = 12.sp)
//    }
//}


// --- TV node-graph layout constants. Sized larger than the mobile canvas's node dimensions
// (File 2's NODE_WIDTH_DP/NODE_HEIGHT_DP) for 10-foot-UI legibility at TV viewing distance. ---
private const val TV_NODE_WIDTH_DP = 220
private const val TV_NODE_HEIGHT_DP = 88
private const val TV_H_GAP_DP = 48
private const val TV_V_GAP_DP = 20
private const val TV_COLUMN_COUNT = 13

/** One node in the merged flow graph: same (type, value) pair across records collapses to one node. */
private class TvFlowGNode(val title: String, val value: String, val column: Int) {
    var row: Int = 0
}

private class TvFlowGraphResult(val columns: List<List<TvFlowGNode>>, val edges: List<Pair<TvFlowGNode, TvFlowGNode>>)

/**
 * Builds the same merged, column-layered graph as the mobile canvas's `buildGraph` (File 2):
 * nodes are de-duplicated by (type, value) within a column, so records sharing a source/template/
 * subject/etc. converge onto the same node instead of drawing a separate chain per record. The
 * shared "tail" (consent status → ... → latest consent) always comes from the first record,
 * mirroring the same fields and edges File 2 uses — this is a presentation-layer duplicate, not a
 * change to how the data is derived from [ConsentRecord].
 */
private fun buildTvFlowGraph(records: List<ConsentRecord>): TvFlowGraphResult {
    val registry = LinkedHashMap<String, TvFlowGNode>()
    val columns = Array(TV_COLUMN_COUNT) { mutableListOf<TvFlowGNode>() }
    val edges = mutableListOf<Pair<TvFlowGNode, TvFlowGNode>>()

    fun nodeOf(type: String, value: String, title: String, column: Int): TvFlowGNode {
        val key = "$type::$value"
        return registry.getOrPut(key) {
            val node = TvFlowGNode(title, value, column)
            node.row = columns[column].size
            columns[column].add(node)
            node
        }
    }

    fun edge(a: TvFlowGNode, b: TvFlowGNode) {
        if (edges.none { it.first === a && it.second === b }) edges.add(a to b)
    }

    val first = records.first()
    val consentStatusNode = nodeOf("consent_status", first.consentStatus, "CONSENT STATUS", 7)
    val consentedAtNode = nodeOf("consented_at", first.consentedAt, "CONSENTED AT", 8)
    val languageNode = nodeOf("language", first.language, "LANGUAGE", 9)
    val expiredConsentNode = nodeOf("expired_consent", first.expiredConsent, "EXPIRED CONSENT", 10)
    val retentionExpiredNode = nodeOf("data_retention_expired", first.dataRetentionExpired, "DATA RETENTION EXPIRED", 11)
    val latestConsentNode = nodeOf("latest_consent", first.latestConsent, "LATEST CONSENT", 12)

    edge(consentStatusNode, consentedAtNode)
    edge(consentedAtNode, languageNode)
    edge(languageNode, expiredConsentNode)
    edge(expiredConsentNode, retentionExpiredNode)
    edge(retentionExpiredNode, latestConsentNode)

    for (r in records) {
        val sourceNode = nodeOf("source", r.source, "SOURCE", 0)
        val templateNode = nodeOf("collection_template", r.collectionTemplate, "COLLECTION TEMPLATE", 1)
        val subjectNode = nodeOf("subject_identity", r.subjectIdentity, "SUBJECT IDENTITY", 2)
        val unifiedNode = nodeOf("unified_person", r.unifiedPerson, "UNIFIED PERSON", 3)
        val processingNode = nodeOf("processing_activities", r.processingActivities, "PROCESSING ACTIVITIES", 4)
        val preferenceNode = nodeOf("consent_preferences", r.consentPreferences, "CONSENT PREFERENCES", 5)
        val piiNode = nodeOf("pii_name", r.piiName, "PII NAME", 6)

        edge(sourceNode, templateNode)
        edge(templateNode, subjectNode)
        edge(subjectNode, unifiedNode)
        edge(unifiedNode, processingNode)
        edge(processingNode, preferenceNode)
        edge(preferenceNode, piiNode)
        edge(piiNode, consentStatusNode)
    }

    return TvFlowGraphResult(columns.toList(), edges)
}

/**
 * TV counterpart of the mobile SDK's `ConsentFlowTab`. That screen relies on pinch-to-zoom/pan
 * (`detectTransformGestures`) to navigate a node graph — a touch-only interaction a D-pad-only
 * remote cannot perform at all — so instead of the canvas gesture surface, the same merged graph
 * (built by [buildTvFlowGraph], mirroring File 2's algorithm and fields exactly) is laid out with fixed
 * node positions inside a scrollable [Box]: each node is a D-pad-focusable [TvFocusableCard], and
 * focusing a card auto-scrolls it into view, giving the same pannable-graph experience without
 * requiring touch gestures.
 */
@Composable
fun ConsentFlowTvTab(viewModel: PreferenceCenterViewModel, modifier: Modifier = Modifier) {
    var loading by remember { mutableStateOf(true) }
    var records by remember { mutableStateOf<List<ConsentRecord>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        loading = true
        try {
            records = viewModel.getConsentFlow()
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    when {
        loading -> TvLoadingScreen(modifier)
        error != null -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            TvText("Error: $error", color = TvColors.error)
        }
        records.isEmpty() -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            TvText("No data", color = TvColors.textSecondary)
        }
        else -> ConsentFlowGraphTv(records, modifier)
    }
}

@Composable
private fun ConsentFlowGraphTv(records: List<ConsentRecord>, modifier: Modifier = Modifier) {
    val graph = remember(records) { buildTvFlowGraph(records) }

    val nodeWidth = TV_NODE_WIDTH_DP.dp
    val nodeHeight = TV_NODE_HEIGHT_DP.dp
    val colStride = (TV_NODE_WIDTH_DP + TV_H_GAP_DP).dp
    val rowStride = (TV_NODE_HEIGHT_DP + TV_V_GAP_DP).dp
    val maxRows = graph.columns.maxOf { it.size }.coerceAtLeast(1)
    val totalWidth = colStride * graph.columns.size
    val totalHeight = rowStride * maxRows

    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()

    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(graph) {
        if (graph.columns.isNotEmpty() && graph.columns[0].isNotEmpty()) {
            focusRequester.requestFocus()
        }
    }


    Box(
        modifier
            .fillMaxSize()
            .verticalScroll(vScroll)
            .padding(32.dp),
    ) {
        Box(Modifier.horizontalScroll(hScroll)) {
            Box(Modifier.size(totalWidth, totalHeight)) {
                Canvas(Modifier.fillMaxSize()) {
                    graph.edges.forEach { (from, to) ->
                        val fromX = from.column * colStride.toPx() + nodeWidth.toPx()
                        val fromY = from.row * rowStride.toPx() + nodeHeight.toPx() / 2
                        val toX = to.column * colStride.toPx()
                        val toY = to.row * rowStride.toPx() + nodeHeight.toPx() / 2
                        val midX = (fromX + toX) / 2
                        val path = Path().apply {
                            moveTo(fromX, fromY)
                            cubicTo(midX, fromY, midX, toY, toX, toY)
                        }
                        drawPath(path, color = TvColors.textSecondary, style = Stroke(width = 2f))
                    }
                }

                graph.columns.forEach { colNodes ->
                    colNodes.forEach { node ->
                        FlowNodeTvCard(
                            node = node,
                            modifier = Modifier
                                .offset(x = colStride * node.column, y = rowStride * node.row)
                                .then(if (node.column == 0 && node.row == 0) Modifier.focusRequester(focusRequester) else Modifier),
                            width = nodeWidth,
                            height = nodeHeight,
                        )
                    }
                }
            }
        }
    }
}
@Composable
private fun FlowNodeTvCard(node: TvFlowGNode, modifier: Modifier, width: Dp, height: Dp) {
    TvFocusableCard(onClick = null, modifier = modifier.width(width).height(height)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
            TvText(node.title, color = TvColors.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.size(4.dp))
            TvText(node.value.ifEmpty { "-" }, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}