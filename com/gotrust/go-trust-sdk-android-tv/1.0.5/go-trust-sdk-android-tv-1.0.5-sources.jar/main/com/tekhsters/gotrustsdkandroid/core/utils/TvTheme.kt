package com.tekhsters.gotrustsdkandroid.core.utils

import androidx.compose.ui.graphics.Color

/**
 * Fixed, dark-first TV palette (Android TV design guidelines favour dark surfaces for 10-foot
 * viewing) that every screen's base background/surface/text colors come from, regardless of CMS
 * config — a full per-field light/dark palette swap the way the mobile SDK does doesn't fit a
 * fixed 10-foot dark theme. CMS-driven color *does* still flow through on top of that base, the
 * same way it does on mobile: accent color, action-button colors/borders, and badge colors all
 * read the CMS config through [accentOrDefault]. What's intentionally not replicated is per-field
 * *layout* config (`section_alignments`, `spacing`) — a D-pad-only remote has no pointer/hover
 * model for that kind of pixel-level positioning, so this presentation layer stays a single
 * focus-traversable column instead.
 */
object TvColors {
    val background = Color(0xFFF7F8FA)
    val surface = Color(0xFFFFFFFF)
    val surfaceVariant = Color(0xFFEFF1F5)

    val accent = Color(0xFF2B6BEA)
    val onAccent = Color.White

    val focusRing = Color(0xFF1A1A1A)

    val textPrimary = Color(0xFF171717)
    val textSecondary = Color(0xFF6B7280)

    val error = Color(0xFFD93025)
    val success = Color(0xFF1E9E5A)

    val divider = Color(0xFFD9DDE5)
}


/** Accent color the mobile CMS configured for this form/dashboard, falling back to [TvColors.accent]. */
fun accentOrDefault(hex: String?): Color {
    if (hex.isNullOrBlank()) return TvColors.accent
    return try {
        var value = hex.trim().removePrefix("#")
        if (value.length == 3) value = value.map { "$it$it" }.joinToString("")
        val colorLong = when (value.length) {
            6 -> 0xFF000000 or value.toLong(16)
            8 -> value.toLong(16)
            else -> return TvColors.accent
        }
        Color(colorLong)
    } catch (e: Exception) {
        TvColors.accent
    }
}

/**
 * CMS footer/legal copy is HTML (same field the mobile SDK renders through [HtmlText] with a
 * WebView-free Android TextView). TV doesn't need clickable-link fidelity for this trailing copy,
 * so it's shown as plain text with tags stripped instead of pulling in an AndroidView.
 */
fun stripHtmlTv(html: String?): String = html.orEmpty().replace(Regex("<[^>]*>"), "").trim()

fun looksLikeHtml(s: String?): Boolean {
    if (s == null) return false
    val lower = s.lowercase()
    return listOf("<p>", "</p>", "<br>", "</br>", "<h1>", "</h1>", "<h2>", "</h2>", "<a ", "</a>")
        .any { lower.contains(it) }
}
