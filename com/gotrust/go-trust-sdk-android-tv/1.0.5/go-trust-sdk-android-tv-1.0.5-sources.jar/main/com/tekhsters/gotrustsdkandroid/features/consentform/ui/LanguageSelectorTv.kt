package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.core.ui.TvTabRow
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.ui.focusModifier
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors

/**
 * D-pad-navigable language picker — replaces the mobile SDK's touch dropdown (`LanguageSelector.kt`)
 * with a focusable row of pills, matching Android TV's convention for a small, bounded choice set.
 */
@Composable
fun LanguageSelectorTv(
    languages: List<Language>,
    selectedCode: String,
    onChanged: (String) -> Unit,
    modifier: Modifier = Modifier,
    bgColor: String? = null,
    borderRadius: String? = null,
    borderShape: String? = null,
    textcolor: String? = null,
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedLanguage = languages.firstOrNull { it.code == selectedCode }

    if (languages.isNotEmpty()) {
        val interactionSource = remember { MutableInteractionSource() }
        val isFocused by interactionSource.collectIsFocusedAsState()


        fun parseColorOrNull(value: String?): Color? =
            value?.takeIf { it.isNotBlank() }?.let {
                runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull()
            }

        val resolvedBackgroundColor: Color = parseColorOrNull(bgColor) ?: Color.White
        val resolvedTextColor: Color = parseColorOrNull(textcolor) ?: TvColors.textPrimary

        val resolvedCornerRadius = borderRadius
            ?.takeIf { it.isNotBlank() }
            ?.toFloatOrNull()
            ?.dp
            ?: 8.dp

        // "shape" lets the caller pick a shape type (e.g. "circle", "rounded", "square");
        // defaults to the original RoundedCornerShape(8.dp) behavior.
        val resolvedShape = when (borderShape?.lowercase()?.trim()) {
            "circle", "pill" -> RoundedCornerShape(50)
            "square", "rectangle" -> RoundedCornerShape(0.dp)
            "rounded", null, "" -> RoundedCornerShape(resolvedCornerRadius)
            else -> RoundedCornerShape(resolvedCornerRadius)
        }

        Box(modifier = modifier) {
            Row(
                modifier = Modifier
                    .clip(resolvedShape)
                    .background(
                        if (isFocused) TvColors.surfaceVariant else resolvedBackgroundColor,
                        resolvedShape
                    )
                    .then(focusModifier(isFocused, resolvedShape))
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = { expanded = true }
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Select Language",
                    tint = resolvedTextColor,
                    modifier = Modifier.size(20.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                TvText(
                    text = selectedLanguage?.name ?: selectedLanguage?.code ?: "",
                    color = resolvedTextColor,
                    fontSize = 14.sp
                )
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(Color.White)
            ) {
                languages.forEach { lang ->
                    val isSelected = lang.code == selectedCode
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = lang.name ?: lang.code ?: "",
                                color = Color.Black,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        trailingIcon = {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = Color.Black
                                )
                            }
                        },
                        onClick = {
                            lang.code?.let(onChanged)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}