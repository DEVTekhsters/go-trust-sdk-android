package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import android.graphics.Typeface
import android.text.style.StyleSpan
import android.text.style.URLSpan
import android.text.style.UnderlineSpan
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.text.HtmlCompat
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import com.tekhsters.gotrustsdkandroid.core.utils.Utils

/**
 * HTML -> AnnotatedString for TV. Handles entities (&amp; &nbsp;), line breaks (<p>, <br>, lists),
 * bold, italic, underline and links (links are only styled: a D-pad can't click them).
 */
fun htmlToAnnotatedTv(
    html: String?,
    color: Color,
    weight: FontWeight? = null,
    linkColor: Color = Color(0xFF64B5F6)
): AnnotatedString {
    if (html.isNullOrBlank()) return AnnotatedString("")

    val spanned = HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_COMPACT)
    // same-length replacements so span positions stay valid
    val text = spanned.toString().replace('\u00A0', ' ').replace('\uFFFC', ' ')

    val builder = AnnotatedString.Builder(text)
    builder.addStyle(SpanStyle(color = color, fontWeight = weight), 0, text.length)

    spanned.getSpans(0, spanned.length, Any::class.java).forEach { span ->
        val s = spanned.getSpanStart(span).coerceIn(0, text.length)
        val e = spanned.getSpanEnd(span).coerceIn(0, text.length)
        if (s >= e) return@forEach
        when (span) {
            is StyleSpan -> when (span.style) {
                Typeface.BOLD -> builder.addStyle(SpanStyle(fontWeight = FontWeight.Bold), s, e)
                Typeface.ITALIC -> builder.addStyle(SpanStyle(fontStyle = FontStyle.Italic), s, e)
                Typeface.BOLD_ITALIC -> builder.addStyle(
                    SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic), s, e
                )
            }
            is UnderlineSpan -> builder.addStyle(SpanStyle(textDecoration = TextDecoration.Underline), s, e)
            is URLSpan -> builder.addStyle(
                SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), s, e
            )
        }
    }

    // trim leading/trailing blank lines (HtmlCompat adds "\n" after paragraphs)
    val start = text.indexOfFirst { !it.isWhitespace() }
    if (start == -1) return AnnotatedString("")
    val end = text.indexOfLast { !it.isWhitespace() } + 1
    return builder.toAnnotatedString().subSequence(start, end)
}

@Composable
fun ConsentHtmlContentTv(
    html: String,
    modifier: Modifier = Modifier,
    headerBgColor : String? = null,
    headerTextColor : String? = null,
    textColor: Color = TvColors.textSecondary,
    fontSize: Float = 12f
) {
    // No table: just render the formatted text
    if (!html.contains("<table", ignoreCase = true)) {
        val text = remember(html, textColor) { htmlToAnnotatedTv(html, textColor) }
        if (text.isNotEmpty()) TvText(text = text, fontSize = fontSize.sp, modifier = modifier)
        return
    }

    val blocks = remember(html) { parseHtmlBlocks(html) }
    Column(modifier = modifier.fillMaxWidth()) {
        blocks.forEach { block ->
            when (block) {
                is HtmlBlock.Content -> {
                    val text = remember(block.html, textColor) { htmlToAnnotatedTv(block.html, textColor) }
                    if (text.isNotEmpty()) TvText(text = text, fontSize = fontSize.sp)
                }
                is HtmlBlock.Table -> HtmlTableTv(block, headerBgColor,headerTextColor, textColor, fontSize)
            }
        }
    }
}

@Composable
fun HtmlTableTv(
    table: HtmlBlock.Table,
    headerBgColor : String? = null,
    headerTextColor : String? = null,
    bodyTextColor: Color,
    fontSize: Float,
    modifier: Modifier = Modifier
) {
    val cols = table.columnCount
    if (cols == 0) return

    val headerBg = Utils.hexToColor(headerBgColor ?: "#EEEEEE")
    val headerText = Utils.hexToColor(headerTextColor ?: "#000000")
    val borderColor = Color(0xFF9E9E9E)

    Column(
        modifier = modifier
            .padding(vertical = 8.dp)
            .fillMaxWidth()
            .border(1.dp, borderColor)
    ) {
        table.headerRows.forEach { row ->
            HtmlTableRowTv(row, cols, true, headerBg, headerText, bodyTextColor, borderColor, fontSize)
        }
        table.bodyRows.forEach { row ->
            HtmlTableRowTv(row, cols, false, headerBg, headerText, bodyTextColor, borderColor, fontSize)
        }
    }
}

@Composable
private fun HtmlTableRowTv(
    cells: List<String>,
    cols: Int,
    isHeader: Boolean,
    headerBg: Color,
    headerText: Color,
    bodyText: Color,
    borderColor: Color,
    fontSize: Float
) {
    Row(modifier = Modifier.height(IntrinsicSize.Min)) {
        repeat(cols) { i ->
            val cellHtml = cells.getOrNull(i) ?: ""
            val cellText = remember(cellHtml, isHeader, headerText, bodyText) {
                htmlToAnnotatedTv(
                    cellHtml,
                    color = if (isHeader) headerText else bodyText,
                    weight = if (isHeader) FontWeight.Bold else null
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .border(0.5.dp, borderColor)
                    .background(if (isHeader) headerBg else Color.Transparent)
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                TvText(text = cellText, fontSize = fontSize.sp)
            }
        }
    }
}