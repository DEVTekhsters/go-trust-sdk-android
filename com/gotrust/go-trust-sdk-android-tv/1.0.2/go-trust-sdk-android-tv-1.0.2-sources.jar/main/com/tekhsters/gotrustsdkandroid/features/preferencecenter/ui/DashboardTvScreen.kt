package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentPurposeConfiguration
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.UcmConsentBucket
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.UcmPreferenceCategory
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterViewModel
import com.tekhsters.gotrustsdkandroid.core.ui.TvErrorScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvSavingOverlay
import com.tekhsters.gotrustsdkandroid.core.ui.TvSuccessDialog
import com.tekhsters.gotrustsdkandroid.core.ui.TvButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvCheckbox
import com.tekhsters.gotrustsdkandroid.core.ui.TvFocusableCard
import com.tekhsters.gotrustsdkandroid.core.ui.TvSwitch
import com.tekhsters.gotrustsdkandroid.core.ui.TvTabRow
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.ui.dpadScrollable
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.LanguageSelectorTv
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import com.tekhsters.gotrustsdkandroid.core.utils.accentOrDefault
import com.tekhsters.gotrustsdkandroid.core.utils.stripHtmlTv as stripHtml

@Composable
fun DashboardTvScreen(viewModel: PreferenceCenterViewModel, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val revision = viewModel.dashboardRevision.value
    val data = viewModel.dashboardData
    val languages by viewModel.languages.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()

    val cfg = data?.preferenceCenterConfiguration
    val consentConfig = cfg?.consentPurposeConfiguration

    if (cfg == null) {
        TvErrorScreen(
            message = "Unable to load preference center",
            onRetry = { viewModel.reloadDashboard() },
            onClose = onClose,
            modifier = modifier,
        )
        return
    }

    data class TabDef(val title: String, val content: @Composable () -> Unit)

    val tabs = buildList {
        add(TabDef(cfg.privacyNoticeHeading ?: "Privacy Notice") {
            PrivacyNoticeTvTab(data.privacyNote.orEmpty().map { it.title to it.content })
        })
        if (cfg.showConsent == true) {
            add(TabDef(cfg.preferenceCenterHeading ?: "Consent Preferences") {
                ConsentPreferencesTvTab(viewModel, consentConfig)
            })
        }
        if (cfg.showDSR == true) {
            add(TabDef(cfg.dsrCenterHeading ?: "DSR") { DsrTvTab(data.dsr?.dsrContent) })
        }
        if (cfg.showConsentFlow == true) {
            add(TabDef(cfg.consentFlowHeading ?: "Consent Flow") { ConsentFlowTvTab(viewModel) })
        }
        add(TabDef(cfg.auditLogsHeading ?: "Audit Logs") {
            AuditLogsTvTab(viewModel = viewModel, dataPrincipalId = viewModel.getDataPrincipalId())
        })
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    if (selectedTab >= tabs.size) selectedTab = 0

    val resetTabSignal = viewModel.resetToFirstTabSignal.value
    LaunchedEffect(resetTabSignal) { if (resetTabSignal > 0) selectedTab = 0 }

    val accent = accentOrDefault(consentConfig?.form?.colorScheme)

    Column(modifier = modifier.fillMaxSize().background(TvColors.background)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                TvText(data.basicInfo?.title ?: "Privacy Preferences", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                if (!data.basicInfo?.description.isNullOrEmpty()) {
                    Box(Modifier.size(4.dp))
                    TvText(data.basicInfo?.description ?: "", color = TvColors.textSecondary, fontSize = 13.sp)
                }
            }
            if (consentConfig?.form?.showLanguage == true && languages.isNotEmpty()) {
                LanguageSelectorTv(languages, lang, onChanged = { viewModel.onLanguageChanged(it) })
                Box(Modifier.size(16.dp))
            }
            TvButton("Close", onClick = onClose, primary = false)
        }

        TvTabRow(
            titles = tabs.map { it.title },
            selectedIndex = selectedTab,
            onSelected = { selectedTab = it },
            accent = accent,
            modifier = Modifier.padding(horizontal = 32.dp),
        )

        Box(Modifier.size(16.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            tabs[selectedTab].content()
        }
    }

    if (viewModel.savingOverlayVisible.value) TvSavingOverlay()

    val successMessage = viewModel.saveSuccessMessage.value
    if (successMessage != null) {
        TvSuccessDialog(message = successMessage, onDismiss = { viewModel.dismissSaveSuccessDialog() }, accentColor = accent)
    }
}

@Composable
private fun PrivacyNoticeTvTab(notes: List<Pair<String?, String?>>) {
    val listState = rememberLazyListState()
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().dpadScrollable(listState),
        contentPadding = PaddingValues(horizontal = 32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        items(notes) { (title, content) ->
            Column {
                TvText(title ?: "", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.size(6.dp))
                TvText(stripHtml(content), color = TvColors.textSecondary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun DsrTvTab(content: String?) {
    val listState = rememberLazyListState()
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().dpadScrollable(listState),
        contentPadding = PaddingValues(horizontal = 32.dp),
    ) {
        item { TvText(stripHtml(content), color = TvColors.textSecondary, fontSize = 14.sp) }
    }
}

/** TV counterpart of mobile's `ConsentInputControl` — same checkbox/toggle switch on CMS config. */
@Composable
private fun TvConsentInputControl(
    checked: Boolean,
    useToggle: Boolean,
    accent: androidx.compose.ui.graphics.Color,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit,
) {
    if (useToggle) {
        TvSwitch(checked = checked, onCheckedChange = onCheckedChange, accent = accent, enabled = enabled)
    } else {
        TvCheckbox(checked = checked, onCheckedChange = onCheckedChange, accent = accent, enabled = enabled)
    }
}

@Composable
private fun ConsentPreferencesTvTab(
    viewModel: PreferenceCenterViewModel,
    consentConfig: ConsentPurposeConfiguration?,
) {
    val isBusy by viewModel.isBusy.collectAsState()
    val accent = accentOrDefault(consentConfig?.form?.colorScheme)
    val section = consentConfig?.consentCollectionSection
    val categories = viewModel.getOrderedCategories(viewModel.allCategories()).filter { it.ucmPreferenceVisible != false }
    val enableCategoryLevel = section?.enableCategoryLevelConsent == true

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 32.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (section?.showCheckAllCheckbox == true) {
            item {
                val useToggle = (section.consentInputType ?: "checkbox").lowercase() == "toggle"
                val inputOnRight = (section.consentInputPosition ?: "left").lowercase() == "right"
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!inputOnRight) {
                        TvConsentInputControl(
                            checked = viewModel.multiSelectConsentValue.value,
                            useToggle = useToggle,
                            accent = accent,
                            onCheckedChange = { viewModel.toggleAllConsents(it) },
                        )
                        Box(Modifier.size(10.dp))
                    }
                    TvText(section.allCheckboxText ?: "Select All", fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    if (inputOnRight) {
                        Box(Modifier.size(10.dp))
                        TvConsentInputControl(
                            checked = viewModel.multiSelectConsentValue.value,
                            useToggle = useToggle,
                            accent = accent,
                            onCheckedChange = { viewModel.toggleAllConsents(it) },
                        )
                    }
                }
            }
        }

        if (enableCategoryLevel) {
            items(categories) { category -> CategoryTvCard(viewModel, category, consentConfig, accent) }
        } else {
            items(categories) { category ->
                Column {
                    viewModel.getOrderedPurposes(category).filter { it.ucmPreferenceVisible != false }.forEach { purpose ->
                        purpose.consentBucket.orEmpty().filter { it.ucmPreferenceVisible != false }.forEach { bucket ->
                            ConsentBucketTvRow(viewModel, bucket, section, accent)
                        }
                    }
                }
            }
        }

        item {
            Box(Modifier.size(12.dp))
            TvButton(
                if (isBusy) "Saving…" else (consentConfig?.submitButton?.text ?: "Save Preferences"),
                enabled = !isBusy,
                onClick = { viewModel.onSavePreferencesClicked() },
                accent = accent,
            )
            Box(Modifier.size(20.dp))
        }
    }
}

@Composable
private fun CategoryTvCard(
    viewModel: PreferenceCenterViewModel,
    category: UcmPreferenceCategory,
    consentConfig: ConsentPurposeConfiguration?,
    accent: androidx.compose.ui.graphics.Color,
) {
    viewModel.dashboardRevision.value
    var expanded by remember { mutableStateOf(true) }
    val purposes = viewModel.getOrderedPurposes(category).filter { it.ucmPreferenceVisible != false }
    val buckets = purposes.flatMap { it.consentBucket.orEmpty() }.filter { it.ucmPreferenceVisible != false }
    if (buckets.isEmpty()) return
    val section = consentConfig?.consentCollectionSection

    // Mirrors mobile's DashboardScreen.CategoryCard exactly: unlike the consent-form's
    // category-level control (opt-out of check-all), the dashboard's is opt-in — shown only once
    // the CMS explicitly turns check-all *on*.
    val showControl = section?.showConsentInput != false && section?.showCategoryConsentInput != false && section?.showCheckAllCheckbox == true
    val useToggle = (section?.consentInputType ?: "checkbox").lowercase() == "toggle"
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"

    TvFocusableCard(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                if (showControl && !inputOnRight) {
                    TvConsentInputControl(
                        checked = viewModel.getCategoryConsentValue(category),
                        useToggle = useToggle,
                        accent = accent,
                        enabled = !viewModel.isCategoryConsentControlDisabled(category),
                        onCheckedChange = { viewModel.applyCategoryConsent(category, it) },
                    )
                    Box(Modifier.size(10.dp))
                }
                TvText(category.processingPurposeCategoryName ?: "", fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (showControl && inputOnRight) {
                    Box(Modifier.size(10.dp))
                    TvConsentInputControl(
                        checked = viewModel.getCategoryConsentValue(category),
                        useToggle = useToggle,
                        accent = accent,
                        enabled = !viewModel.isCategoryConsentControlDisabled(category),
                        onCheckedChange = { viewModel.applyCategoryConsent(category, it) },
                    )
                    Box(Modifier.size(8.dp))
                }
                TvText(if (expanded) "▲" else "▼", color = TvColors.textSecondary)
            }
            if (expanded) {
                Box(Modifier.size(8.dp))
                buckets.forEach { bucket -> ConsentBucketTvRow(viewModel, bucket, section, accent) }
            }
        }
    }
}

@Composable
private fun ConsentBucketTvRow(
    viewModel: PreferenceCenterViewModel,
    bucket: UcmConsentBucket,
    section: com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentCollectionSection?,
    accent: androidx.compose.ui.graphics.Color,
) {
    viewModel.dashboardRevision.value
    val ct = bucket.ctCpMapBucket.orEmpty().firstOrNull()
    val checked = ct?.consentStatus == true
    // compulsory_consent can be true on any entry of ct_cp_map_bucket (one per
    // pii label/process/vendor), not just the first
    val isCompulsory = bucket.ctCpMapBucket.orEmpty().any { it.compulsoryConsent == true }
    val useToggle = (section?.consentInputType ?: "checkbox").lowercase() == "toggle"
    val showIndividualInput = section?.showConsentInput != false && section?.showIndividualChecks != false
    val showDescription = section?.showDescription ?: true
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"

    @Composable
    fun BucketInputControl() {
        TvConsentInputControl(
            checked = checked,
            useToggle = useToggle,
            accent = accent,
            onCheckedChange = { viewModel.toggleBucketConsent(bucket, it) },
        )
    }

    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        if (showIndividualInput && !inputOnRight) {
            BucketInputControl()
            Box(Modifier.size(10.dp))
        }
        Column(Modifier.weight(1f)) {
            TvText(
                text = if (isCompulsory) {
                    buildAnnotatedString {
                        append(bucket.consentPurposeName ?: "")
                        withStyle(SpanStyle(color = TvColors.error)) { append(" *") }
                    }
                } else {
                    buildAnnotatedString { append(bucket.consentPurposeName ?: "") }
                },
                fontSize = 14.sp,
            )
            if (showDescription && !bucket.consentPurposeDescription.isNullOrEmpty()) {
                TvText(stripHtml(bucket.consentPurposeDescription), color = TvColors.textSecondary, fontSize = 12.sp)
            }
        }
        if (showIndividualInput && inputOnRight) {
            Box(Modifier.size(10.dp))
            BucketInputControl()
        }
    }
}
