package com.tekhsters.gotrustsdkandroid.core.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors

/**
 * D-pad-operable on-screen numeric keypad — the widget the PRD calls for in place of a touch
 * keyboard for phone-number and OTP-digit entry (§8.3). The mobile SDK's phone/OTP flow itself
 * (backend calls, validation) is untouched; this only supplies the input surface.
 */
@Composable
fun TvNumericKeyboard(
    onDigit: (Char) -> Unit,
    onBackspace: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
    doneLabel: String = "Done",
    doneEnabled: Boolean = true,
) {
    val rows = listOf(
        listOf('1', '2', '3'),
        listOf('4', '5', '6'),
        listOf('7', '8', '9'),
    )
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { digit -> KeyButton(digit.toString()) { onDigit(digit) } }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KeyButton("⌫") { onBackspace() }
            KeyButton("0") { onDigit('0') }
            KeyButton(doneLabel, wide = true, accent = true, enabled = doneEnabled) { onDone() }
        }
    }
}

@Composable
private fun KeyButton(
    label: String,
    wide: Boolean = false,
    small: Boolean = false,
    accent: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val shape = RoundedCornerShape(10.dp)
    val bg = when {
        !enabled -> TvColors.surfaceVariant
        accent -> TvColors.accent
        else -> TvColors.surface
    }
    Box(
        modifier = Modifier
            .size(width = if (wide) 96.dp else if (small) 44.dp else 56.dp, height = 48.dp)
            .clip(shape)
            .background(bg, shape)
            .border(if (isFocused) 3.dp else 1.dp, if (isFocused) TvColors.focusRing else TvColors.divider, shape)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        TvText(
            label,
            color = if (accent) TvColors.onAccent else TvColors.textPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

/**
 * D-pad-operable full on-screen keyboard (letters, digits, space) for free-text PII fields (name,
 * address, email, ...) on the TV consent form and preference-center login, mirroring the standard
 * Android TV/Leanback keyboard pattern the PRD calls for.
 */
@Composable
fun TvQwertyKeyboard(
    onChar: (String) -> Unit,
    onBackspace: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
    doneLabel: String = "Done",
    doneEnabled: Boolean = true,
) {
    val rows = listOf(
        "1234567890".map { it.toString() },
        "qwertyuiop".map { it.toString() },
        "asdfghjkl".map { it.toString() },
        "zxcvbnm".map { it.toString() },
    )
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { ch -> KeyButton(ch, small = true) { onChar(ch) } }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton("space", wide = true) { onChar(" ") }
            KeyButton("⌫") { onBackspace() }
            KeyButton(doneLabel, wide = true, accent = true, enabled = doneEnabled) { onDone() }
        }
    }
}

/**
 * A labeled text field whose only way to type is the on-screen keyboard: focusing then pressing
 * Select docks [TvNumericKeyboard] or [TvQwertyKeyboard] beneath it. One component covers every
 * text-entry need on the TV consent form and login screen (PII fields, phone numbers) so the
 * open/close and edit behaviour is consistent everywhere it appears.
 */
@Composable
fun TvTextEntryField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    prefix: String? = null,
    numeric: Boolean = false,
    mandatory: Boolean = false,
    isInvalid: Boolean = false,
    errorText: String = "This field is required",
    maxLength: Int? = null,
    enabled: Boolean = true,
) {
    var expanded by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    fun append(s: String) {
        if (maxLength == null || value.length < maxLength) onValueChange(value + s)
    }

    fun backspace() {
        if (value.isNotEmpty()) onValueChange(value.dropLast(1))
    }

    Column(modifier = modifier) {
        Row {
            TvText(label, color = TvColors.textSecondary, fontSize = 13.sp)
            if (mandatory) TvText(" *", color = TvColors.error, fontSize = 13.sp)
        }
        Box(Modifier.size(6.dp))
        Box(
            modifier = Modifier
                .clickable(
                    enabled = enabled,
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = { expanded = !expanded },
                ),
        ) {
            TvValueDisplay(
                value = value,
                prefix = prefix,
                placeholder = "Select to type",
                isFocused = enabled && (isFocused || expanded),
                enabled = enabled,
            )
        }
        if (isInvalid) {
            Box(Modifier.size(4.dp))
            TvText(errorText, color = TvColors.error, fontSize = 12.sp)
        }
        if (expanded) {
            Box(Modifier.size(10.dp))
            if (numeric) {
                TvNumericKeyboard(
                    onDigit = { append(it.toString()) },
                    onBackspace = { backspace() },
                    onDone = { expanded = false },
                )
            } else {
                TvQwertyKeyboard(
                    onChar = { append(it) },
                    onBackspace = { backspace() },
                    onDone = { expanded = false },
                )
            }
        }
    }
}

/** Read-only display of the value being typed via [TvNumericKeyboard], with a fixed prefix (e.g. "+91"). */
@Composable
fun TvValueDisplay(
    value: String,
    modifier: Modifier = Modifier,
    prefix: String? = null,
    placeholder: String = "",
    isFocused: Boolean = false,
    mask: Boolean = false,
    enabled: Boolean = true,
) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(if (enabled) TvColors.surface else TvColors.surfaceVariant, shape)
            .border(if (isFocused) 3.dp else 1.dp, if (isFocused) TvColors.focusRing else TvColors.divider, shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (!prefix.isNullOrEmpty()) {
            TvText(prefix, color = TvColors.textSecondary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.size(8.dp))
        }
        val shown = if (mask) "•".repeat(value.length) else value
        TvText(
            shown.ifEmpty { placeholder },
            color = if (!enabled) TvColors.textSecondary else if (value.isEmpty()) TvColors.textSecondary else TvColors.textPrimary,
            fontSize = 18.sp,
        )
    }
}
