package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.parsePxToDp
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterViewModel
import com.tekhsters.gotrustsdkandroid.core.ui.TvErrorScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.ui.TvTextEntryField
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.LanguageSelectorTv
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import com.tekhsters.gotrustsdkandroid.core.utils.accentOrDefault

/**
 * TV counterpart of the mobile SDK's `LoginScreen`: same subject-identity fields, same
 * `submitLogin()`/backend flow, entered here through [TvTextEntryField]'s docked on-screen
 * keyboard instead of a touch keyboard.
 */
@Composable
fun LoginTvScreen(viewModel: PreferenceCenterViewModel, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val config by viewModel.loginConfig.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()

    val cfg = config?.configuration
    val userInfoCfg = cfg?.userInputConfiguration

    if (cfg == null || userInfoCfg == null) {
        TvErrorScreen(
            message = "Unable to load preference center",
            onRetry = { viewModel.loadLoginConfig() },
            onClose = onClose,
            modifier = modifier,
        )
        return
    }

    val accent = accentOrDefault(userInfoCfg.submitButton?.backgroundColor ?: userInfoCfg.submitButton?.color)
    val submitTextColor = userInfoCfg.submitButton?.textColor?.let { accentOrDefault(it) }
    val submitShape = RoundedCornerShape((userInfoCfg.submitButton?.borderRadius ?: 10.0).dp)
    val shouldShowLogo = (cfg.showLogo ?: true) && (userInfoCfg.logo?.showLogo ?: true) && !userInfoCfg.logo?.logoUrl.isNullOrEmpty()

    Column(modifier = modifier.fillMaxSize().background(TvColors.background)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (shouldShowLogo) {
                AsyncImage(
                    model = userInfoCfg.logo?.logoUrl,
                    contentDescription = "Logo",
                    modifier = Modifier.height(parsePxToDp(userInfoCfg.logo?.height, fallback = 40f)).padding(end = 16.dp),
                )
            }
            Column(Modifier.weight(1f)) {
                TvText(userInfoCfg.heading?.text?.ifEmpty { null } ?: "Sign in", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                if (!userInfoCfg.description?.text.isNullOrEmpty()) {
                    Box(Modifier.size(4.dp))
                    TvText(userInfoCfg.description?.text ?: "", color = TvColors.textSecondary, fontSize = 14.sp)
                }
            }
            if (cfg.consentPurposeConfiguration?.form?.showLanguage == true && languages.isNotEmpty()) {
                LanguageSelectorTv(languages, lang, onChanged = { viewModel.onLanguageChanged(it) })
                Box(Modifier.size(16.dp))
            }
            TvButton("Close", onClick = onClose, primary = false)
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(config?.subjectIdentityTypes.orEmpty()) { si ->
                val id = si.id ?: return@items
                val isPhone = PhoneIdentity.isPhoneLabel(si.name)
                val editing = viewModel.isEditingSubjectIdentity(id)
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.fillMaxWidth()) {
                    TvTextEntryField(
                        label = si.name ?: "Identity",
                        value = viewModel.subjectIdentityInputs[id] ?: "",
                        onValueChange = { viewModel.onSubjectIdentityChanged(id, it) },
                        prefix = if (isPhone) PhoneIdentity.COUNTRY_CODE else null,
                        numeric = isPhone,
                        mandatory = true,
                        maxLength = if (isPhone) 10 else null,
                        enabled = editing,
                        modifier = Modifier.weight(1f),
                    )
                    Box(Modifier.size(12.dp))
                    // Every identity gets its own toggle, mirroring the mobile Login screen — with
                    // more than one identity configured, a single shared toggle would read as
                    // though only the first field could be changed.
                    TvButton(
                        if (editing) "Done" else "Edit",
                        onClick = { viewModel.toggleEditingSubjectIdentity(id) },
                        primary = false,
                    )
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(32.dp), horizontalArrangement = Arrangement.End) {
            TvButton(
                if (isBusy) "Please wait…" else (userInfoCfg.submitButton?.text ?: "Login"),
                enabled = !isBusy,
                onClick = { viewModel.submitLogin() },
                accent = accent,
                shape = submitShape,
                textColor = submitTextColor,
            )
        }
    }
}
