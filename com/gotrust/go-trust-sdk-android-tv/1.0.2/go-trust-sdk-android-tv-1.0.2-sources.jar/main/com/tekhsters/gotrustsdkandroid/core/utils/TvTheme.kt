package com.tekhsters.gotrustsdkandroid.core.utils

import androidx.compose.ui.graphics.Color

/**
 * Fixed, dark-first TV palette (Android TV design guidelines favour dark surfaces for 10-foot
 * viewing) that every screen's base background/surface/text colors come from, regardless of CMS
 * config — a full per-field light/dark palette swap the way the mobile SDK does doesn't fit a
 * fixed 10-foot dark theme. CMS-driven color *does* still flow through on top of that base, the
 * same way it does on mobile: accent color, action-button colors/borders, and badge colors all
 * read the CMS config through [accentOrDefault]. What's intentionally not replicated is per-field
 * *layout* config (`section_alignments`, `spacing`) — a D-pad-only remote has no pointer/hover
 * model for that kind of pixel-level positioning, so this presentation layer stays a single
 * focus-traversable column instead.
 */
object TvColors {
    val background = Color(0xFF0B0E14)
    val surface = Color(0xFF1B1F2A)
    val surfaceVariant = Color(0xFF262B38)
    val accent = Color(0xFF4C8DFF)
    val onAccent = Color.White
    val focusRing = Color(0xFFFFFFFF)
    val textPrimary = Color(0xFFF5F6FA)
    val textSecondary = Color(0xFFA7ADBB)
    val error = Color(0xFFFF6B6B)
    val success = Color(0xFF4CD787)
    val divider = Color(0xFF343A48)
}

/** Accent color the mobile CMS configured for this form/dashboard, falling back to [TvColors.accent]. */
fun accentOrDefault(hex: String?): Color {
    if (hex.isNullOrBlank()) return TvColors.accent
    return try {
        var value = hex.trim().removePrefix("#")
        if (value.length == 3) value = value.map { "$it$it" }.joinToString("")
        val colorLong = when (value.length) {
            6 -> 0xFF000000 or value.toLong(16)
            8 -> value.toLong(16)
            else -> return TvColors.accent
        }
        Color(colorLong)
    } catch (e: Exception) {
        TvColors.accent
    }
}

/**
 * CMS footer/legal copy is HTML (same field the mobile SDK renders through [HtmlText] with a
 * WebView-free Android TextView). TV doesn't need clickable-link fidelity for this trailing copy,
 * so it's shown as plain text with tags stripped instead of pulling in an AndroidView.
 */
fun stripHtmlTv(html: String?): String = html.orEmpty().replace(Regex("<[^>]*>"), "").trim()
