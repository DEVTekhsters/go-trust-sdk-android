package com.tekhsters.gotrustsdkandroid

import android.app.Activity
import android.content.Intent
import com.tekhsters.gotrustsdkandroid.core.callbacks.ConsentFormCallbacks
import com.tekhsters.gotrustsdkandroid.core.callbacks.GoTrustSdkCallbacks
import com.tekhsters.gotrustsdkandroid.core.callbacks.PreferenceCenterCallbacks
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ADDITIONAL_PARAMS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_BASE_URL
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_CONSENT_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_CUSTOMER_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ENABLE_CAPTCHA
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_LANGUAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_SUBJECT_VALUES
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_PF_TOKEN
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_PREFERENCE_FORM_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SHOW_CROSS_BUTTON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SOURCE_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_TOKEN
import com.tekhsters.gotrustsdkandroid.features.consentform.services.ApiService
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.GoTrustSdkTvActivity
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterTvActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Public entry point of the Android TV SDK. Method-for-method mirror of `GoTrustSdk` (mobile) —
 * same config classes, same callback contracts, same [ConsentCheckResult] semantics — so an
 * integrator who knows the mobile SDK can guess this one correctly. Only the two Activities behind
 * it differ: they render a D-pad-navigable, TV-native presentation layer instead of touch Material 3,
 * over the exact same network/business logic (`ApiService`, `ConsentFormViewModel`,
 * `PreferenceCenterViewModel`) reused unchanged from the `goTrustSdkAndroid` module.
 */
object GoTrustSdkTv {

    /** Opens the TV consent form. See `GoTrustSdk.showConsentForm` for how [callbacks] is scoped. */
    fun showConsentForm(
        activity: Activity,
        config: ConsentFormConfig,
        callbacks: ConsentFormCallbacks? = null,
    ) {
        GoTrustSdkCallbacks.consentForm = callbacks
        GoTrustSdkCallbacks.fallback = config.fallback
        activity.startActivity(consentFormIntent(activity, config))
    }

    /**
     * Asks the backend whether the subject in [config] has already consented for this source,
     * without showing any UI. Identical semantics and implementation to `GoTrustSdk.checkConsent` —
     * this is pure network/business logic and is not reinterpreted for TV.
     */
    suspend fun checkConsent(config: ConsentFormConfig): ConsentCheckResult {
        ApiService.instance.setBaseUrl(config.baseUrl)
        ApiService.instance.setFallback(config.fallback)
        val response = ApiService.instance.checkConsentStatus(
            sourceId = config.sourceId ?: "",
            subjectIdentityValues = config.subjectIdentityValues,
            token = config.token,
        ) ?: return ConsentCheckResult.Failed("Consent check could not be completed")

        return if (response.result?.data?.userFound == true) {
            ConsentCheckResult.AlreadyGiven
        } else {
            ConsentCheckResult.Required
        }
    }

    /** Runs [checkConsent] and opens the TV consent form only if it is actually needed. */
    fun showConsentFormIfNeeded(
        activity: Activity,
        config: ConsentFormConfig,
        callbacks: ConsentFormCallbacks? = null,
        showOnCheckFailure: Boolean = true,
        onResult: ((ConsentCheckResult) -> Unit)? = null,
    ) {
        CoroutineScope(Dispatchers.Main.immediate).launch {
            val result = checkConsent(config)
            if (activity.isFinishing || activity.isDestroyed) return@launch

            onResult?.invoke(result)

            val show = when (result) {
                is ConsentCheckResult.Required -> true
                is ConsentCheckResult.AlreadyGiven -> false
                is ConsentCheckResult.Failed -> showOnCheckFailure
            }
            if (show) showConsentForm(activity, config, callbacks)
        }
    }

    /** Opens the TV preference center. See [showConsentForm] for how [callbacks] is scoped. */
    fun showPreferenceCenter(
        activity: Activity,
        config: PreferenceCenterConfig,
        callbacks: PreferenceCenterCallbacks? = null,
    ) {
        GoTrustSdkCallbacks.preferenceCenter = callbacks
        activity.startActivity(preferenceCenterIntent(activity, config))
    }

    private fun consentFormIntent(activity: Activity, config: ConsentFormConfig) =
        Intent(activity, GoTrustSdkTvActivity::class.java).apply {
            putExtra(EXTRA_BASE_URL, config.baseUrl)
            putExtra(EXTRA_SOURCE_ID, config.sourceId)
            putExtra(EXTRA_INITIAL_SUBJECT_VALUES, HashMap(config.subjectIdentityValues))
            putExtra(EXTRA_ADDITIONAL_PARAMS, HashMap(config.additionalParams))
            putExtra(EXTRA_SHOW_CROSS_BUTTON, config.showCrossButton)
            putExtra(EXTRA_INITIAL_LANGUAGE, config.initialLanguage)
            putExtra(EXTRA_ENABLE_CAPTCHA, config.enableCaptcha)
            config.token?.let { putExtra(EXTRA_TOKEN, it) }
        }

    private fun preferenceCenterIntent(activity: Activity, config: PreferenceCenterConfig) =
        Intent(activity, PreferenceCenterTvActivity::class.java).apply {
            putExtra(EXTRA_BASE_URL, config.baseUrl)
            config.pfToken?.let { putExtra(EXTRA_PF_TOKEN, it) }
            config.token?.let { putExtra(EXTRA_TOKEN, it) }
            putExtra(EXTRA_CONSENT_ID, config.consentId)
            config.customerId?.let { putExtra(EXTRA_CUSTOMER_ID, it) }
            config.preferenceFormId?.let { putExtra(EXTRA_PREFERENCE_FORM_ID, it) }
            putExtra(EXTRA_INITIAL_SUBJECT_VALUES, HashMap(config.initialSubjectValues))
            putExtra(EXTRA_ADDITIONAL_PARAMS, HashMap(config.additionalParams))
            putExtra(EXTRA_INITIAL_LANGUAGE, config.initialLanguage)
            putExtra(EXTRA_ENABLE_CAPTCHA, config.enableCaptcha)
        }
}
