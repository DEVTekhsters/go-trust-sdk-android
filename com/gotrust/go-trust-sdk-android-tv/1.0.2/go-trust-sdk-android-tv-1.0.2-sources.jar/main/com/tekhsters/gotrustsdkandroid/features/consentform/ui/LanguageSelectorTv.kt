package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language
import com.tekhsters.gotrustsdkandroid.core.ui.TvTabRow

/**
 * D-pad-navigable language picker — replaces the mobile SDK's touch dropdown (`LanguageSelector.kt`)
 * with a focusable row of pills, matching Android TV's convention for a small, bounded choice set.
 */
@Composable
fun LanguageSelectorTv(
    languages: List<Language>,
    selectedCode: String,
    onChanged: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (languages.isEmpty()) return
    val selectedIndex = languages.indexOfFirst { it.code == selectedCode }.coerceAtLeast(0)
    Row(modifier = modifier.horizontalScroll(rememberScrollState())) {
        TvTabRow(
            titles = languages.map { it.name ?: it.code ?: "" },
            selectedIndex = selectedIndex,
            onSelected = { index -> languages.getOrNull(index)?.code?.let(onChanged) },
        )
    }
}
