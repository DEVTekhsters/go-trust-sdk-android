package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.GsonBuilder
import com.google.gson.JsonParser
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentTransaction
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterViewModel
import com.tekhsters.gotrustsdkandroid.core.ui.TvLoadingScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvFocusableCard
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors

/**
 * TV counterpart of the mobile SDK's `AuditLogsTab`. Its "view payload" affordance is a
 * `ModalBottomSheet`, a touch sheet pattern with no D-pad equivalent; here selecting a card
 * expands it in place instead, keeping list position obvious and never requiring a pointer.
 */
@Composable
fun AuditLogsTvTab(viewModel: PreferenceCenterViewModel, dataPrincipalId: Int, modifier: Modifier = Modifier) {
    var items by remember { mutableStateOf(listOf<ConsentTransaction>()) }
    var page by remember { mutableIntStateOf(1) }
    var loadingFirst by remember { mutableStateOf(true) }
    var hasMore by remember { mutableStateOf(true) }
    var loadingMore by remember { mutableStateOf(false) }

    suspend fun loadFirstPage() {
        loadingFirst = true
        page = 1
        hasMore = true
        val result = viewModel.fetchConsentAuditLogs(dataPrincipalId, 1)
        if (result != null) {
            items = result.items
            if (result.items.isEmpty()) hasMore = false
        }
        loadingFirst = false
    }

    suspend fun loadNextPage() {
        if (!hasMore || loadingMore) return
        loadingMore = true
        val next = page + 1
        val result = viewModel.fetchConsentAuditLogs(dataPrincipalId, next)
        if (result != null) {
            page = next
            items = items + result.items
            if (result.items.isEmpty()) hasMore = false
        }
        loadingMore = false
    }

    LaunchedEffect(Unit) { loadFirstPage() }
    val coroutineScope = rememberCoroutineScope()

    when {
        loadingFirst -> TvLoadingScreen(modifier)
        items.isEmpty() -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            TvText("No data", color = TvColors.textSecondary)
        }
        else -> LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(items) { tx -> AuditLogCard(tx) }
            item {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    when {
                        loadingMore -> TvText("Loading more…", color = TvColors.textSecondary, fontSize = 12.sp)
                        !hasMore -> TvText("No more records", color = TvColors.textSecondary, fontSize = 12.sp)
                        else -> {
                            // Simple "load more" affordance in place of infinite scroll's proximity
                            // trigger — reliable and obvious to reach with a D-pad.
                            com.tekhsters.gotrustsdkandroid.core.ui.TvButton(
                                "Load more",
                                primary = false,
                                onClick = { coroutineScope.launch { loadNextPage() } },
                            )
                        }
                    }
                }
                Box(Modifier.size(24.dp))
            }
        }
    }
}

@Composable
private fun AuditLogCard(tx: ConsentTransaction) {
    var expanded by remember { mutableStateOf(false) }
    var showRaw by remember { mutableStateOf(false) }

    TvFocusableCard(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    TvText(tx.subjectIdentity.ifEmpty { "-" }, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    TvText(
                        "${tx.collectionTemplateName} · ${tx.consentSource} · ${tx.entityName}",
                        color = TvColors.textSecondary,
                        fontSize = 12.sp,
                    )
                }
                StatusPill(tx.aggregatedConsentStatus)
            }
            if (expanded) {
                Box(Modifier.size(10.dp))
                tx.metaInfo.forEach { meta ->
                    Column(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusPill(meta.consentStatus)
                            Box(Modifier.size(8.dp))
                            TvText(meta.consentPurposeName.ifEmpty { "-" }, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        AuditMetaRow("PII Label", meta.piiLabelName)
                        AuditMetaRow("Template", meta.collectionTemplateName)
                        AuditMetaRow("Reviewed Privacy Notice", if (meta.reviewedPrivacyNotice) "Yes" else "No")
                        AuditMetaRow("Expires", meta.consentExpiration ?: "-")
                        AuditMetaRow("Consented At", tx.consentedAt)
                        AuditMetaRow("Privacy Notice", meta.privacyNoteName)
                        AuditMetaRow("Vendor", meta.vendorName ?: "-")
                        AuditMetaRow("Language", meta.language)
                        AuditMetaRow("Process", meta.processingPurposeName)
                        AuditMetaRow("Frequency", meta.frequency ?: "-")
                        Box(Modifier.size(10.dp))
                    }
                }
                com.tekhsters.gotrustsdkandroid.core.ui.TvButton(
                    if (showRaw) "Hide raw payload" else "View raw payload",
                    primary = false,
                    onClick = { showRaw = !showRaw },
                )
                if (showRaw) {
                    Box(Modifier.size(10.dp))
                    val pretty = remember(tx) {
                        GsonBuilder().setPrettyPrinting().create().toJson(JsonParser.parseString(tx.rawJson.toString()))
                    }
                    TvText(pretty, color = TvColors.textSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun AuditMetaRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        TvText(label, color = TvColors.textSecondary, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(0.4f))
        TvText(value.ifEmpty { "-" }, fontSize = 12.sp)
    }
}

@Composable
private fun StatusPill(status: String) {
    val color = when (status.lowercase().trim()) {
        "granted" -> TvColors.success
        "declined", "withdrawn" -> TvColors.error
        else -> TvColors.textSecondary
    }
    TvText(status.ifEmpty { "-" }.uppercase(), color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
}
