package com.tekhsters.gotrustsdkandroid.core.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import kotlinx.coroutines.launch

/**
 * Every focusable control in this module is built from plain Compose Foundation
 * (`clickable`/`focusable`) rather than a component library: D-pad Up/Down/Left/Right traversal
 * and Enter/DPAD_CENTER activation are handled by Compose's own focus and input systems with no
 * extra wiring, and the focus *look* (scale + ring) is the one thing every control here shares.
 */

@Composable
fun TvText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = TvColors.textPrimary,
    fontSize: androidx.compose.ui.unit.TextUnit = 16.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    textAlign: androidx.compose.ui.text.style.TextAlign = androidx.compose.ui.text.style.TextAlign.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
) {
    val style = remember(color, fontSize, fontWeight, textAlign) {
        TextStyle.Default.copy(color = color, fontSize = fontSize, fontWeight = fontWeight, textAlign = textAlign)
    }
    BasicText(
        text = text,
        modifier = modifier,
        style = style,
        maxLines = maxLines,
    )
}

/**
 * [AnnotatedString] variant so per-span styling (e.g. a red compulsory "*") wraps inline with
 * the rest of the text instead of being laid out as a sibling that can overflow off-screen.
 */
@Composable
fun TvText(
    text: AnnotatedString,
    modifier: Modifier = Modifier,
    color: Color = TvColors.textPrimary,
    fontSize: androidx.compose.ui.unit.TextUnit = 16.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    textAlign: androidx.compose.ui.text.style.TextAlign = androidx.compose.ui.text.style.TextAlign.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
) {
    val style = remember(color, fontSize, fontWeight, textAlign) {
        TextStyle.Default.copy(color = color, fontSize = fontSize, fontWeight = fontWeight, textAlign = textAlign)
    }
    BasicText(
        text = text,
        modifier = modifier,
        style = style,
        maxLines = maxLines,
    )
}

/** Shared focus chrome: a brighter border and a subtle lift, applied uniformly across controls. */
@Composable
private fun focusModifier(isFocused: Boolean, shape: Shape): Modifier =
    if (isFocused) {
        Modifier.border(3.dp, TvColors.focusRing, shape)
    } else {
        Modifier.border(1.dp, TvColors.divider, shape)
    }

@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    primary: Boolean = true,
    accent: Color = TvColors.accent,
    shape: Shape = RoundedCornerShape(10.dp),
    textColor: Color? = null,
    borderColor: Color? = null,
    borderWidth: androidx.compose.ui.unit.Dp = 1.dp,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val bg = when {
        !enabled -> TvColors.surfaceVariant
        primary -> accent
        else -> if (isFocused) TvColors.surfaceVariant else Color.Transparent
    }
    val resolvedTextColor = textColor ?: when {
        !enabled -> TvColors.textSecondary
        primary -> TvColors.onAccent
        else -> TvColors.textPrimary
    }
    Box(
        modifier = modifier
            .clip(shape)
            .background(bg, shape)
            .then(if (borderColor != null) Modifier.border(if (isFocused) borderWidth * 2 else borderWidth, borderColor, shape) else Modifier)
            .then(if (borderColor == null && !primary) focusModifier(isFocused, shape) else Modifier)
            .then(if (borderColor == null && primary && isFocused) Modifier.border(3.dp, TvColors.focusRing, shape) else Modifier)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            )
            .padding(horizontal = 24.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        TvText(text, color = resolvedTextColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TvSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = TvColors.accent,
    enabled: Boolean = true,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val trackShape = RoundedCornerShape(50)
    Box(
        modifier = modifier
            .size(width = 52.dp, height = 30.dp)
            .clip(trackShape)
            .background(if (checked) accent else TvColors.surfaceVariant, trackShape)
            .then(focusModifier(isFocused, trackShape))
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = { onCheckedChange(!checked) },
            )
            .padding(3.dp),
        contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.White, CircleShape),
        )
    }
}

@Composable
fun TvCheckbox(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = TvColors.accent,
    enabled: Boolean = true,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier = modifier
            .size(26.dp)
            .clip(shape)
            .background(if (checked) accent else Color.Transparent, shape)
            .then(focusModifier(isFocused, shape))
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = { onCheckedChange(!checked) },
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (checked) TvText("✓", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

/** A focusable row/card used for list items (dashboard categories, audit log entries, ...). */
@Composable
fun TvFocusableCard(
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(if (isFocused) TvColors.surfaceVariant else TvColors.surface, shape)
            .then(focusModifier(isFocused, shape))
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            )
            .padding(contentPadding),
    ) {
        content()
    }
}

/** A row of focusable pill tabs, used for the preference-center's Dashboard/Consent Flow/Audit Logs tabs. */
@Composable
fun TvTabRow(
    titles: List<String>,
    selectedIndex: Int,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = TvColors.accent,
) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        titles.forEachIndexed { index, title ->
            val selected = index == selectedIndex
            val interactionSource = remember { MutableInteractionSource() }
            val isFocused by interactionSource.collectIsFocusedAsState()
            val shape = RoundedCornerShape(20.dp)
            Box(
                modifier = Modifier
                    .clip(shape)
                    .background(if (selected) accent else TvColors.surface, shape)
                    .then(focusModifier(isFocused, shape))
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = { onSelected(index) },
                    )
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            ) {
                TvText(
                    title,
                    color = if (selected) TvColors.onAccent else TvColors.textPrimary,
                    fontSize = 14.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                )
            }
        }
    }
}

/**
 * D-pad Up/Down only scrolls a [LazyColumn] by moving focus between focusable children — a list
 * made entirely of plain [TvText] (privacy notice body copy, legal text, etc.) has nothing for
 * focus to land on, so the remote cannot scroll it at all. This intercepts Up/Down directly and
 * drives [listState] itself, the same fix the Flutter TV privacy notice screen already applies
 * (`_contentFocusNode.onKeyEvent` animating its ScrollController) — ported here as the general
 * Compose-native mechanism rather than any of that screen's UI. Events are only consumed while
 * there's somewhere left to scroll, so focus can still leave the list (e.g. to header/footer
 * buttons) once an edge is reached.
 */
@Composable
fun Modifier.dpadScrollable(listState: LazyListState, step: Dp = 140.dp, autoFocus: Boolean = true): Modifier {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val stepPx = remember(step, density) { with(density) { step.toPx() } }
    val focusRequester = remember { FocusRequester() }

    if (autoFocus) {
        LaunchedEffect(Unit) { focusRequester.requestFocus() }
    }

    return this
        .focusRequester(focusRequester)
        .focusable()
        .onKeyEvent { event ->
            if (event.type != KeyEventType.KeyDown) return@onKeyEvent false
            when (event.key) {
                Key.DirectionDown -> {
                    if (!listState.canScrollForward) return@onKeyEvent false
                    scope.launch { listState.animateScrollBy(stepPx) }
                    true
                }
                Key.DirectionUp -> {
                    if (!listState.canScrollBackward) return@onKeyEvent false
                    scope.launch { listState.animateScrollBy(-stepPx) }
                    true
                }
                else -> false
            }
        }
}
