package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.tekhsters.gotrustsdkandroid.core.callbacks.GoTrustSdkCallbacks
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ADDITIONAL_PARAMS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_BASE_URL
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_DATA_JSON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ERROR_MESSAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ERROR_STATUS_CODE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_LANGUAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_MESSAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SHOW_CROSS_BUTTON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SOURCE_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_STATUS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_STATUS_CODE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_TOKEN
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_VIA_LOGIN
import com.tekhsters.gotrustsdkandroid.core.utils.LanguagePreferences
import com.tekhsters.gotrustsdkandroid.core.utils.readCaptchaFlag
import com.tekhsters.gotrustsdkandroid.core.utils.readInitialSubjectValues
import com.tekhsters.gotrustsdkandroid.features.consentform.models.GsonProvider
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.ConsentFormUiState
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.ConsentFormViewModel
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.ConsentSubmitError
import com.tekhsters.gotrustsdkandroid.core.ui.TV_SNACKBAR_DURATION_MS
import com.tekhsters.gotrustsdkandroid.core.ui.TvBlockingDialog
import com.tekhsters.gotrustsdkandroid.core.ui.TvErrorScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvLoadingScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvSavingOverlay
import com.tekhsters.gotrustsdkandroid.core.ui.TvSnackbar
import com.tekhsters.gotrustsdkandroid.core.ui.TvSuccessDialog
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import com.tekhsters.gotrustsdkandroid.core.utils.accentOrDefault
import kotlinx.coroutines.delay

private const val CLOSED_BY_USER_MESSAGE = "Consent form closed by user"

/**
 * TV counterpart of the mobile SDK's `GoTrustSdkActivity`: identical lifecycle, extras, and
 * result/callback contract, driven by the same [ConsentFormViewModel] (reused unchanged) — only
 * the composables it renders are TV-native instead of touch Material 3.
 */
internal class GoTrustSdkTvActivity : ComponentActivity() {

    private val viewModel: ConsentFormViewModel by viewModels()
    private var lastSubmitError: ConsentSubmitError? = null
    private var viaLogin: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        LanguagePreferences.init(this)

        val baseUrl = intent.getStringExtra(EXTRA_BASE_URL) ?: ""
        val sourceId = intent.getStringExtra(EXTRA_SOURCE_ID) ?: ""
        val subjectIdentityValues = intent.readInitialSubjectValues()
        val showCrossButton = intent.getBooleanExtra(EXTRA_SHOW_CROSS_BUTTON, true)
        val initialLanguage = intent.getStringExtra(EXTRA_INITIAL_LANGUAGE) ?: "en"
        val enableCaptcha = intent.readCaptchaFlag()
        val token = intent.getStringExtra(EXTRA_TOKEN)
        viaLogin = intent.getBooleanExtra(EXTRA_VIA_LOGIN, false)
        @Suppress("UNCHECKED_CAST")
        val additionalParams = intent.getSerializableExtra(EXTRA_ADDITIONAL_PARAMS) as? Map<String, Any> ?: emptyMap()

        viewModel.init(
            baseUrl = baseUrl,
            sourceId = sourceId,
            subjectIdentityValues = subjectIdentityValues,
            additionalParams = additionalParams,
            initialLanguage = initialLanguage,
            enableCaptcha = enableCaptcha,
            fallback = if (viaLogin) null else GoTrustSdkCallbacks.fallback,
            token = token,
        )

        setContent {
            Box(Modifier.fillMaxSize().background(TvColors.background)) {
                val state by viewModel.uiState.collectAsState()
                val isSubmitting by viewModel.isSubmitting.collectAsState()
                val submitSuccess by viewModel.submitSuccess.collectAsState()
                val submitError by viewModel.submitError.collectAsState()
                val consentFormData by viewModel.consentForm.collectAsState()
                val snackbarMessage by viewModel.snackbarMessage.collectAsState()

                LaunchedEffect(snackbarMessage) {
                    snackbarMessage?.let {
                        delay(TV_SNACKBAR_DURATION_MS)
                        viewModel.consumeSnackbar()
                    }
                }

                LaunchedEffect(submitError) {
                    submitError?.let { error ->
                        lastSubmitError = error
                        hostCallbacks()?.onError?.invoke(error.statusCode, error.message)
                        viewModel.consumeSubmitError()
                    }
                }

                BackHandler {
                    if (!isSubmitting && submitSuccess == null) {
                        closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                    }
                }

                when (val s = state) {
                    is ConsentFormUiState.Loading -> TvLoadingScreen()
                    is ConsentFormUiState.Success -> ConsentFormTvScreen(
                        viewModel = viewModel,
                        onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                        showCrossButton = showCrossButton,
                    )
                    is ConsentFormUiState.PrivacyNoticeGating -> {
                        val form by viewModel.consentForm.collectAsState()
                        val languages by viewModel.languages.collectAsState()
                        val selectedLang by viewModel.selectedLanguage.collectAsState()
                        val privacyData by viewModel.privacyData.collectAsState()
                        val privacyLoading by viewModel.isLoadingPrivacyNotice.collectAsState()

                        PrivacyNoticeTvScreen(
                            languages = languages,
                            selectedLanguage = selectedLang,
                            onLanguageChanged = { viewModel.onLanguageChanged(it) },
                            privacyData = privacyData,
                            formConfig = form?.formConfiguration,
                            onAgree = { lang, id, version -> viewModel.onPrivacyNoticeAgreed(lang, id, version) },
                            onClose = {
                                if (s.isPreConsentGate) {
                                    closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                                } else {
                                    viewModel.closePrivacyNotice()
                                }
                            },
                            showCrossButton = showCrossButton,
                            isLoading = privacyLoading,
                        )
                    }
                    is ConsentFormUiState.DigiLockerVerification -> DigiLockerTvWebView(
                        url = s.url,
                        onSuccess = { code, otpState -> viewModel.onDigiLockerSuccess(code, otpState) },
                    )
                    is ConsentFormUiState.Error -> TvErrorScreen(
                        message = s.message,
                        onRetry = { viewModel.loadAll() },
                        onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                    )
                    is ConsentFormUiState.MinorVerificationFailed -> TvBlockingDialog(
                        title = "Verification Failed",
                        message = s.message,
                        actionLabel = "Close",
                        onAction = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                    )
                }

                if (isSubmitting) TvSavingOverlay(message = "Submitting consent…")

                val success = submitSuccess
                if (success != null) {
                    val finish = {
                        closeWithResult(
                            status = "success",
                            statusCode = success.statusCode,
                            message = success.message,
                            dataJson = GsonProvider.gson.toJson(success.data),
                            successData = success.data,
                        )
                    }
                    LaunchedEffect(success) {
                        delay(3000)
                        finish()
                    }
                    TvSuccessDialog(
                        message = success.message,
                        onDismiss = finish,
                        accentColor = accentOrDefault(consentFormData?.formConfiguration?.form?.colorScheme),
                    )
                }

                snackbarMessage?.let { TvSnackbar(it) }
            }
        }
    }

    private fun closeWithResult(
        status: String,
        statusCode: Int? = null,
        message: String? = null,
        dataJson: String? = null,
        successData: List<Map<String, Any?>>? = null,
    ) {
        val resultIntent = Intent().apply {
            putExtra(EXTRA_STATUS, status)
            statusCode?.let { putExtra(EXTRA_STATUS_CODE, it) }
            message?.let { putExtra(EXTRA_MESSAGE, it) }
            dataJson?.let { putExtra(EXTRA_DATA_JSON, it) }
            if (status != "success") {
                lastSubmitError?.let { error ->
                    error.statusCode?.let { putExtra(EXTRA_ERROR_STATUS_CODE, it) }
                    error.message?.let { putExtra(EXTRA_ERROR_MESSAGE, it) }
                }
            }
        }
        setResult(if (status == "success") Activity.RESULT_OK else Activity.RESULT_CANCELED, resultIntent)

        val callbacks = hostCallbacks()
        if (status == "success") {
            callbacks?.onSuccess?.invoke(statusCode, message, successData.orEmpty())
        } else {
            callbacks?.onClose?.invoke(message)
        }
        if (!viaLogin) GoTrustSdkCallbacks.clearConsentForm()

        finish()
    }

    private fun hostCallbacks() = if (viaLogin) null else GoTrustSdkCallbacks.consentForm
}
