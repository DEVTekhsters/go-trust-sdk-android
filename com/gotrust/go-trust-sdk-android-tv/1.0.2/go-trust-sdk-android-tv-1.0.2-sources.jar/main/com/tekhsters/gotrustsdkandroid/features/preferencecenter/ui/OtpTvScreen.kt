package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.parsePxToDp
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterViewModel
import com.tekhsters.gotrustsdkandroid.core.ui.TvErrorScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvNumericKeyboard
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.ui.TvValueDisplay
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.LanguageSelectorTv
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import com.tekhsters.gotrustsdkandroid.core.utils.accentOrDefault
import kotlinx.coroutines.delay

/**
 * TV counterpart of the mobile SDK's `OtpScreen`: same 6-digit verify/resend/countdown flow
 * against the same backend calls, typed with the shared [TvNumericKeyboard] instead of six
 * separate touch-focused boxes.
 */
@Composable
fun OtpTvScreen(viewModel: PreferenceCenterViewModel, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val config by viewModel.loginConfig.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()
    val isResendBusy by viewModel.isResendBusy.collectAsState()

    val cfg = config?.configuration
    val verifyCfg = cfg?.verifyInputConfiguration

    if (cfg == null || verifyCfg == null) {
        TvErrorScreen(
            message = "Unable to open OTP page",
            onRetry = { viewModel.loadLoginConfig() },
            onClose = onClose,
            modifier = modifier,
        )
        return
    }

    val accent = accentOrDefault(verifyCfg.submitButton?.backgroundColor ?: verifyCfg.submitButton?.color)
    val submitTextColor = accentOrDefault(verifyCfg.submitButton?.textColor ?: "#ffffff")
    val submitShape = RoundedCornerShape((verifyCfg.borderRadius?.toDoubleOrNull() ?: 12.0).dp)
    val resendTextColor = verifyCfg.secondaryButton?.textColor?.let { accentOrDefault(it) }
    val shouldShowLogo = !verifyCfg.logo?.logoUrl.isNullOrEmpty()
    var otp by remember { mutableStateOf("") }

    LaunchedEffect(viewModel.otpResendEnabled.value) {
        if (viewModel.otpResendEnabled.value) return@LaunchedEffect
        while (viewModel.otpRemainingSeconds.intValue > 0) {
            delay(1000)
            viewModel.otpRemainingSeconds.intValue -= 1
        }
        viewModel.otpResendEnabled.value = true
    }

    fun tryVerify() {
        if (otp.length == 6) viewModel.verifyOtp(otp)
    }

    val identity = viewModel.subjectIdentityInputs.keys.joinToString(", ") { viewModel.subjectIdentityPayloadValue(it) }

    Column(
        modifier = modifier.fillMaxSize().background(TvColors.background).padding(32.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (shouldShowLogo) {
                AsyncImage(
                    model = verifyCfg.logo?.logoUrl,
                    contentDescription = "Logo",
                    modifier = Modifier.height(parsePxToDp(verifyCfg.logo?.height, fallback = 32f)).padding(end = 16.dp),
                )
            }
            Column(Modifier.weight(1f)) {
                TvText(verifyCfg.heading?.text?.ifEmpty { null } ?: "Verify OTP", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.size(4.dp))
                TvText(
                    "${verifyCfg.description?.beforeEmail ?: "Code sent to"} $identity ${verifyCfg.description?.afterEmail ?: ""}",
                    color = TvColors.textSecondary,
                    fontSize = 14.sp,
                )
            }
            if (cfg.consentPurposeConfiguration?.form?.showLanguage == true && languages.isNotEmpty()) {
                LanguageSelectorTv(languages, lang, onChanged = { viewModel.onLanguageChanged(it) })
                Box(Modifier.size(16.dp))
            }
            TvButton("Close", onClick = onClose, primary = false)
        }

        Box(Modifier.size(28.dp))

        TvValueDisplay(
            value = otp,
            placeholder = "Enter 6-digit code",
            isFocused = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Box(Modifier.size(20.dp))

        TvNumericKeyboard(
            onDigit = { if (otp.length < 6) otp += it },
            onBackspace = { if (otp.isNotEmpty()) otp = otp.dropLast(1) },
            onDone = { tryVerify() },
            doneLabel = if (isBusy) "Verifying…" else (verifyCfg.submitButton?.text ?: "Verify"),
            doneEnabled = !isBusy && otp.length == 6,
        )

        Box(Modifier.weight(1f))

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            TvButton(
                if (isBusy) "Verifying…" else (verifyCfg.submitButton?.text ?: "Verify"),
                enabled = !isBusy && otp.length == 6,
                onClick = { tryVerify() },
                accent = accent,
                shape = submitShape,
                textColor = submitTextColor,
            )
            if (viewModel.otpResendEnabled.value) {
                TvButton(
                    if (isResendBusy) "Resending…" else (verifyCfg.secondaryButton?.text ?: "Resend Code"),
                    enabled = !isResendBusy,
                    primary = false,
                    onClick = { viewModel.resendOtp() },
                    shape = submitShape,
                    textColor = resendTextColor,
                )
            } else {
                val m = viewModel.otpRemainingSeconds.intValue / 60
                val s = viewModel.otpRemainingSeconds.intValue % 60
                TvText("Resend Code in $m:${s.toString().padStart(2, '0')}", color = TvColors.textSecondary, fontSize = 14.sp)
            }
        }
    }
}
