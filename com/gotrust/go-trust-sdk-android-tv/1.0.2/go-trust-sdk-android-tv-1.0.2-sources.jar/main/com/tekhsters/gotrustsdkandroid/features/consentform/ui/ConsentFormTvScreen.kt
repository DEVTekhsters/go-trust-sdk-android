package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.core.utils.getButtonShape
import com.tekhsters.gotrustsdkandroid.core.utils.getFontWeight
import com.tekhsters.gotrustsdkandroid.core.utils.stripHtmlTv
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.ConsentFormViewModel
import com.tekhsters.gotrustsdkandroid.core.ui.TvButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvCheckbox
import com.tekhsters.gotrustsdkandroid.core.ui.TvFocusableCard
import com.tekhsters.gotrustsdkandroid.core.ui.TvSwitch
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.ui.TvTextEntryField
import com.tekhsters.gotrustsdkandroid.core.ui.dpadScrollable
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import com.tekhsters.gotrustsdkandroid.core.utils.accentOrDefault

/**
 * TV counterpart of the mobile SDK's `ConsentFormScreen`: same [ConsentFormViewModel], same CMS
 * config surface (dynamic action buttons, category/purpose ordering, badges, check-all, minor-form
 * PII grouping, consent input type/position) — [getOrderedCategories]/[getOrderedPurposes]/
 * [shouldShowDynamicButtons] are the exact functions mobile's `ConsentFormScreen.kt` uses, reused
 * unchanged so both surfaces order/branch identically. Only per-field alignment/spacing config
 * (`section_alignments`, `spacing`) is intentionally not replicated — a D-pad-only remote has no
 * pointer/hover model for that kind of pixel-level layout, so this presentation layer stays a
 * single focus-traversable column instead.
 */
@Composable
fun ConsentFormTvScreen(
    viewModel: ConsentFormViewModel,
    onClose: () -> Unit,
    showCrossButton: Boolean,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val form by viewModel.consentForm.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val checkAllStatus by viewModel.checkAllStatus.collectAsState()
    val invalidPiiKeys by viewModel.invalidPiiKeys.collectAsState()
    val hasPartialSelection by viewModel.hasPartialSelection.collectAsState()
    val piiValues = viewModel.piiValues
    viewModel.consentRevision.collectAsState().value // subscribe to in-place consentStatus mutations
    val isSubmitting by viewModel.isSubmitting.collectAsState()

    val fc = form?.formConfiguration
    val bi = form?.basicInfo
    val section = fc?.consentCollectionSection
    val accent = accentOrDefault(fc?.form?.colorScheme)
    val isMinorForm = !form?.piiList?.consentActorPiiList.isNullOrEmpty()

    val dataPrincipalPii = form?.piiList?.dataPrincipalPiiList.orEmpty()
    val consentActorPii = form?.piiList?.consentActorPiiList.orEmpty()
    val compulsoryPiiIds = remember(form) { viewModel.getCompulsoryPiiIds() }

    val categories = getOrderedCategories(
        (form?.categoryList?.dataPrincipalCategoryList.orEmpty() + form?.categoryList?.consentActorCategoryList.orEmpty())
            .filter { it.visible != false },
        fc,
    )
    val enableCategoryLevel = section?.enableCategoryLevelConsent == true
    val useDynamicButtons = shouldShowDynamicButtons(fc)
    val listState = rememberLazyListState()

    Column(modifier = modifier.fillMaxSize().background(TvColors.background)) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            fc?.form?.logo?.let { logo ->
                if (logo.showLogo == true && !logo.logoUrl.isNullOrEmpty()) {
                    AsyncImage(
                        model = logo.logoUrl,
                        contentDescription = "Logo",
                        modifier = Modifier.height(parsePxToDp(logo.height, fallback = 40f)).padding(end = 16.dp),
                    )
                }
            }
            Column(Modifier.weight(1f)) {
                TvText(fc?.form?.heading?.text?.ifEmpty { null } ?: (bi?.title ?: "Consent"), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                if (!bi?.description.isNullOrEmpty()) {
                    Box(Modifier.size(4.dp))
                    TvText(bi?.description ?: "", color = TvColors.textSecondary, fontSize = 14.sp)
                }
            }
            if (fc?.form?.showLanguage == true && languages.isNotEmpty()) {
                LanguageSelectorTv(
                    languages = languages,
                    selectedCode = selectedLanguage,
                    onChanged = { viewModel.onLanguageChanged(it) },
                )
                Box(Modifier.size(16.dp))
            }
            if (showCrossButton) {
                TvButton("Close", onClick = onClose, primary = false)
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().dpadScrollable(listState),
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            fc?.form?.illustrationImage?.let { img ->
                if (img.showIllustrationImage == true && !img.illustrationImageUrl.isNullOrEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            AsyncImage(
                                model = img.illustrationImageUrl,
                                contentDescription = "Illustration",
                                modifier = Modifier.fillMaxWidth(0.6f).height(parsePxToDp(img.height, fallback = 200f)),
                                contentScale = ContentScale.Fit,
                            )
                        }
                    }
                }
            }

            if (!fc?.form?.description?.text.isNullOrEmpty()) {
                item {
                    TvText(
                        fc?.form?.description?.text ?: "",
                        fontSize = 16.sp,
                        fontWeight = getFontWeight(fc?.form?.description?.fontWeight),
                    )
                }
            }
            if (!fc?.piiSection?.description?.text.isNullOrEmpty()) {
                item { TvText(fc?.piiSection?.description?.text ?: "", color = TvColors.textSecondary, fontSize = 14.sp) }
            }

            if (fc?.piiSection?.showPiiSection == true) {
                if (dataPrincipalPii.isNotEmpty()) {
                    val heading = if (isMinorForm) fc?.piiSection?.dataPrincipalHeading?.text else null
                    if (!heading.isNullOrEmpty()) item { TvText(heading, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                    items(dataPrincipalPii) { pii ->
                        PiiFieldTv(pii, piiValues, invalidPiiKeys, compulsoryPiiIds, onValueChange = { key, value -> viewModel.onPiiValueChanged(key, value) })
                    }
                }
                if (consentActorPii.isNotEmpty()) {
                    val heading = if (isMinorForm) fc?.piiSection?.consentActorHeading?.text else null
                    if (!heading.isNullOrEmpty()) item { TvText(heading, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                    items(consentActorPii) { pii ->
                        PiiFieldTv(pii, piiValues, invalidPiiKeys, compulsoryPiiIds, onValueChange = { key, value -> viewModel.onPiiValueChanged(key, value) })
                    }
                }
            }

            if (!bi?.preferenceInputHeading.isNullOrEmpty()) {
                item { TvText(bi?.preferenceInputHeading ?: "", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }

            if (section?.showCheckAllCheckbox == true) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ConsentInputControlTv(
                            inputType = section.consentInputType,
                            checked = checkAllStatus,
                            accent = accent,
                            onCheckedChange = { viewModel.toggleCheckAll(it) },
                        )
                        Box(Modifier.size(8.dp))
                        TvText(section.allCheckboxText ?: "Check All", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (categories.isEmpty()) {
                item { TvText("No categories available", color = TvColors.textSecondary, fontSize = 13.sp) }
            } else if (enableCategoryLevel) {
                items(categories) { category ->
                    ConsentCategoryTvCard(category, viewModel, fc, section, accent)
                }
            } else {
                categories.forEach { category ->
                    getOrderedPurposes(category, fc).forEach { purpose ->
                        if (purpose.visible != false) {
                            purpose.buckets.orEmpty().filter { it.visible != false }.forEach { bucket ->
                                item { ConsentBucketTvRow(bucket, viewModel, fc, section, accent) }
                            }
                        }
                    }
                }
            }

            if (!fc?.formFooter?.description?.text.isNullOrEmpty()) {
                item {
                    TvText(
                        stripHtmlTv(fc?.formFooter?.description?.text),
                        color = TvColors.textSecondary,
                        fontSize = 13.sp,
                    )
                }
            }

            // Mirrors mobile's ConsentFormScreen: the Privacy Notice link sits inside the scroll
            // content only in the dynamic-action-buttons layout — the single-Submit layout keeps
            // it as a button beside Submit in the footer instead.
            if (useDynamicButtons && fc?.form?.showPrivacyPolicyUrl != false) {
                item {
                    TvButton(
                        fc?.form?.privacyPolicyUrlText ?: "Privacy Notice",
                        onClick = { viewModel.showPrivacyNotice() },
                        primary = false,
                    )
                }
            }

            item { Box(Modifier.size(8.dp)) }
        }

        // Footer actions
        if (useDynamicButtons) {
            val actionButtons = fc?.actionButtons.orEmpty().filter { it.enabled != false }
            val visibleButtons = actionButtons.filter { action -> action.id?.lowercase() != "secondary" || hasPartialSelection }
            val vertical = (fc?.buttonOrientation ?: "horizontal").lowercase() == "vertical"
            if (vertical) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    visibleButtons.forEach { action ->
                        TvDynamicActionButton(action, accent, isSubmitting, viewModel, context, Modifier.fillMaxWidth())
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    visibleButtons.forEach { action ->
                        TvDynamicActionButton(action, accent, isSubmitting, viewModel, context, Modifier.weight(1f))
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (fc?.form?.showPrivacyPolicyUrl != false) {
                    TvButton(
                        fc?.form?.privacyPolicyUrlText ?: "Privacy Policy",
                        onClick = { viewModel.showPrivacyNotice() },
                        primary = false,
                        modifier = Modifier.weight(1f),
                    )
                }
                TvButton(
                    if (isSubmitting) "Submitting…" else (fc?.submitButton?.text ?: "Submit"),
                    onClick = { viewModel.submit(context) },
                    enabled = !isSubmitting,
                    accent = accent,
                    shape = getButtonShape(fc?.submitButton?.shape, fc?.submitButton?.borderRadius),
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun ConsentInputControlTv(
    inputType: String?,
    checked: Boolean,
    accent: Color,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit,
) {
    if ((inputType ?: "checkbox").lowercase() == "toggle") {
        TvSwitch(checked = checked, onCheckedChange = onCheckedChange, accent = accent, enabled = enabled)
    } else {
        TvCheckbox(checked = checked, onCheckedChange = onCheckedChange, accent = accent, enabled = enabled)
    }
}

@Composable
private fun PiiFieldTv(
    pii: ConsentFormResponse.PiiLabel,
    piiValues: MutableMap<String, String>,
    invalidPiiKeys: Set<String>,
    compulsoryPiiIds: Set<Any>,
    onValueChange: (key: String, value: String) -> Unit,
) {
    val key = "${pii.principalContext ?: ""}_${pii.id}"
    val isPhone = PhoneIdentity.isPhoneLabel(pii.name, pii.regEx)
    val isMandatory = pii.isMandatory || (pii.id != null && compulsoryPiiIds.contains(pii.id!!))
    TvTextEntryField(
        label = pii.name ?: "Field",
        value = piiValues[key] ?: "",
        onValueChange = { onValueChange(key, it) },
        prefix = if (isPhone) PhoneIdentity.COUNTRY_CODE else null,
        numeric = isPhone,
        mandatory = isMandatory,
        isInvalid = key in invalidPiiKeys,
        maxLength = if (isPhone) 10 else null,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun ConsentCategoryTvCard(
    category: ConsentFormResponse.Category,
    viewModel: ConsentFormViewModel,
    fc: ConsentFormResponse.FormConfiguration?,
    section: ConsentFormResponse.ConsentCollectionSection?,
    accent: Color,
) {
    var expanded by remember { mutableStateOf(false) }
    val isSelected = viewModel.isCategorySelected(category)

    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"
    val showCategoryControl = section?.showConsentInput != false &&
        section?.showCategoryConsentInput != false &&
        section?.showCheckAllCheckbox != true

    TvFocusableCard(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                if (showCategoryControl && !inputOnRight) {
                    ConsentInputControlTv(
                        inputType = section?.consentInputType,
                        checked = isSelected,
                        accent = accent,
                        onCheckedChange = { viewModel.toggleCategoryConsent(category, it) },
                    )
                    Box(Modifier.size(12.dp))
                }
                TvText(category.processingPurposeCategoryName ?: "", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (showCategoryControl && inputOnRight) {
                    Box(Modifier.size(12.dp))
                    ConsentInputControlTv(
                        inputType = section?.consentInputType,
                        checked = isSelected,
                        accent = accent,
                        onCheckedChange = { viewModel.toggleCategoryConsent(category, it) },
                    )
                }
                Box(Modifier.size(8.dp))
                TvText(if (expanded) "▲" else "▼", color = TvColors.textSecondary)
            }
            if (expanded) {
                Box(Modifier.size(10.dp))
                getOrderedPurposes(category, fc).forEach { purpose ->
                    if (purpose.visible != false) {
                        purpose.buckets.orEmpty().filter { it.visible != false }.forEach { bucket ->
                            ConsentBucketTvRow(bucket, viewModel, fc, section, accent)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ConsentBucketTvRow(
    bucket: ConsentFormResponse.ConsentBucket,
    viewModel: ConsentFormViewModel,
    fc: ConsentFormResponse.FormConfiguration?,
    section: ConsentFormResponse.ConsentCollectionSection?,
    accent: Color,
) {
    val ct = bucket.ctcpList?.firstOrNull() ?: return
    val checked = ct.consentStatus == true
    val isCompulsory = bucket.ctcpList.orEmpty().any { it.compulsoryConsent == true }

    val showIndividualInput = section?.showConsentInput != false && section?.showIndividualChecks != false
    val inputOnRight = (section?.consentInputPosition ?: "left").lowercase() == "right"

    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (showIndividualInput && !inputOnRight) {
            ConsentInputControlTv(
                inputType = section?.consentInputType,
                checked = checked,
                accent = accent,
                onCheckedChange = {
                    ct.consentStatus = it
                    viewModel.syncCheckAllStatus()
                },
            )
            Box(Modifier.size(12.dp))
        }
        Column(Modifier.weight(1f)) {
            TvText(
                text = if (isCompulsory) {
                    buildAnnotatedString {
                        append(bucket.consentPurposeName ?: "")
                        withStyle(SpanStyle(color = TvColors.error)) { append(" *") }
                    }
                } else {
                    buildAnnotatedString { append(bucket.consentPurposeName ?: "") }
                },
                fontSize = 14.sp,
            )
            val description = bucket.consentPurposeDescription
            if (!description.isNullOrEmpty()) {
                TvText(description, color = TvColors.textSecondary, fontSize = 12.sp)
            }

            if (fc?.piiSection?.showBadges == true && !bucket.piiLabels.isNullOrEmpty()) {
                Box(Modifier.size(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TvText("PII: ", color = TvColors.textSecondary, fontSize = 11.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        bucket.piiLabels.orEmpty().forEach { label -> TvBadge(label, accent) }
                    }
                }
            }
            if (!bucket.processes.isNullOrEmpty()) {
                Box(Modifier.size(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TvText("Process: ", color = TvColors.textSecondary, fontSize = 11.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        bucket.processes.orEmpty().forEach { process -> TvBadge(process, accent) }
                    }
                }
            }
        }
        if (showIndividualInput && inputOnRight) {
            Box(Modifier.size(12.dp))
            ConsentInputControlTv(
                inputType = section?.consentInputType,
                checked = checked,
                accent = accent,
                onCheckedChange = {
                    ct.consentStatus = it
                    viewModel.syncCheckAllStatus()
                },
            )
        }
    }
}

@Composable
private fun TvBadge(text: String, accent: Color) {
    Box(
        modifier = Modifier
            .background(accent, RoundedCornerShape(50)),
    ) {
        TvText(text, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }
}

@Composable
private fun TvDynamicActionButton(
    action: ConsentFormResponse.ActionButton,
    fallbackAccent: Color,
    isSubmitting: Boolean,
    viewModel: ConsentFormViewModel,
    context: Context,
    modifier: Modifier,
) {
    val onClick: () -> Unit = when (action.id?.lowercase()) {
        "primary" -> { { viewModel.acceptAllAndSubmit(context) } }
        "tertiary" -> { { viewModel.acceptRequiredAndSubmit(context) } }
        else -> { { viewModel.submit(context) } }
    }
    TvButton(
        text = action.text ?: action.id ?: "Submit",
        onClick = onClick,
        enabled = !isSubmitting,
        modifier = modifier,
        accent = action.color?.let { accentOrDefault(it) } ?: fallbackAccent,
        textColor = accentOrDefault(action.textColor ?: "#FFFFFF"),
        shape = getButtonShape(action.shape, action.borderRadius),
        borderColor = action.borderColor?.let { accentOrDefault(it) },
        borderWidth = parsePxToDp(action.borderWidth, fallback = 1f),
    )
}
