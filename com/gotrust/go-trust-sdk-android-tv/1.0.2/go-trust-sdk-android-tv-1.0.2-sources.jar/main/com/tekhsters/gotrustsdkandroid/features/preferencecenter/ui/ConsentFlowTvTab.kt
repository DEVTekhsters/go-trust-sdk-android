package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.models.ConsentRecord
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterViewModel
import com.tekhsters.gotrustsdkandroid.core.ui.TvLoadingScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvFocusableCard
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors

/**
 * TV counterpart of the mobile SDK's `ConsentFlowTab`. That screen relies on pinch-to-zoom/pan
 * (`detectTransformGestures`) to navigate a node graph — a touch-only interaction a D-pad-only
 * remote cannot perform at all — so this is not a styling port but a genuine rebuild: each consent
 * record becomes one D-pad-focusable card listing the same fields the graph's nodes carried.
 */
@Composable
fun ConsentFlowTvTab(viewModel: PreferenceCenterViewModel, modifier: Modifier = Modifier) {
    var loading by remember { mutableStateOf(true) }
    var records by remember { mutableStateOf<List<ConsentRecord>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        loading = true
        try {
            records = viewModel.getConsentFlow()
        } catch (e: Exception) {
            error = e.message
        } finally {
            loading = false
        }
    }

    when {
        loading -> TvLoadingScreen(modifier)
        error != null -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            TvText("Error: $error", color = TvColors.error)
        }
        records.isEmpty() -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            TvText("No data", color = TvColors.textSecondary)
        }
        else -> LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(records) { record -> ConsentFlowRecordCard(record) }
        }
    }
}

@Composable
private fun ConsentFlowRecordCard(record: ConsentRecord) {
    TvFocusableCard(onClick = null, modifier = Modifier.fillMaxWidth()) {
        Column {
            TvText(record.piiName.ifEmpty { "Consent record" }, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.size(8.dp))
            FlowField("Source", record.source)
            FlowField("Collection Template", record.collectionTemplate)
            FlowField("Subject Identity", record.subjectIdentity)
            FlowField("Unified Person", record.unifiedPerson)
            FlowField("Processing Activities", record.processingActivities)
            FlowField("Consent Preferences", record.consentPreferences)
            FlowField("Consent Status", record.consentStatus)
            FlowField("Consented At", record.consentedAt)
            FlowField("Language", record.language)
            FlowField("Expired Consent", record.expiredConsent)
            FlowField("Data Retention Expired", record.dataRetentionExpired)
            FlowField("Latest Consent", record.latestConsent)
        }
    }
}

@Composable
private fun FlowField(label: String, value: String) {
    androidx.compose.foundation.layout.Row(modifier = Modifier.fillMaxWidth()) {
        TvText(label, color = TvColors.textSecondary, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(0.45f))
        TvText(value.ifEmpty { "-" }, fontSize = 12.sp)
    }
}
