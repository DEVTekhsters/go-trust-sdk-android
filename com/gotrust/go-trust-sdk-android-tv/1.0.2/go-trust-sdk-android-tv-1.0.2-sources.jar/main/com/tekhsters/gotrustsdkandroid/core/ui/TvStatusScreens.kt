package com.tekhsters.gotrustsdkandroid.core.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.core.ui.TvButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import kotlinx.coroutines.delay

/** Simple rotating-arc spinner — no external icon/animation library needed for one visual. */
@Composable
fun TvSpinner(modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 48.dp) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(16)
            angle = (angle + 8f) % 360f
        }
    }
    Box(
        modifier = modifier
            .size(size)
            .rotate(angle)
            .background(Color.Transparent),
    ) {
        Box(
            Modifier
                .size(size)
                .background(Color.Transparent),
        )
        androidx.compose.foundation.Canvas(Modifier.size(size)) {
            drawArc(
                color = TvColors.accent,
                startAngle = 0f,
                sweepAngle = 270f,
                useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5.dp.toPx()),
            )
        }
    }
}

@Composable
fun TvLoadingScreen(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(TvColors.background), contentAlignment = Alignment.Center) {
        TvSpinner()
    }
}

@Composable
fun TvErrorScreen(
    message: String,
    onRetry: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxSize().background(TvColors.background), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            TvText(
                "Something went wrong",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Box(Modifier.size(12.dp))
            TvText(
                message,
                color = TvColors.textSecondary,
                fontSize = 16.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 48.dp),
            )
            Box(Modifier.size(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                TvButton("Retry", onClick = onRetry, primary = true)
                TvButton("Close", onClick = onClose, primary = false)
            }
        }
    }
}

@Composable
fun TvSavingOverlay(message: String = "Saving…", modifier: Modifier = Modifier) {
    Box(
        modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.72f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            TvSpinner()
            Box(Modifier.size(12.dp))
            TvText(message, fontSize = 16.sp)
        }
    }
}

@Composable
fun TvSuccessDialog(
    message: String,
    onDismiss: () -> Unit,
    accentColor: Color = TvColors.success,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.72f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .background(TvColors.surface, RoundedCornerShape(16.dp))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.size(56.dp).background(accentColor, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                TvText("✓", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.size(16.dp))
            TvText(
                message,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Box(Modifier.size(20.dp))
            TvButton("Done", onClick = onDismiss, primary = true, accent = accentColor)
        }
    }
}

/**
 * TV counterpart of mobile's Material 3 [androidx.compose.material3.SnackbarHost] — a
 * bottom-anchored transient banner for the ViewModel's one-shot `snackbarMessage` (validation
 * errors, OTP/save failures, "Code resent", etc.). Mirrors `SnackbarHostState.showSnackbar`'s
 * default ~4s "Short" duration; the caller consumes the message from its own `LaunchedEffect`
 * after that delay, same as the mobile activities do.
 */
@Composable
fun BoxScope.TvSnackbar(message: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .align(Alignment.BottomCenter)
            .padding(24.dp)
            .background(TvColors.surfaceVariant, RoundedCornerShape(10.dp))
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        TvText(message, fontSize = 15.sp)
    }
}

const val TV_SNACKBAR_DURATION_MS = 4000L

/** Full-screen modal for a hard-stop message (minor verification failure, etc.) with one action. */
@Composable
fun TvBlockingDialog(
    title: String,
    message: String,
    actionLabel: String,
    onAction: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.8f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .background(TvColors.surface, RoundedCornerShape(16.dp))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            TvText(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.size(12.dp))
            TvText(
                message,
                color = TvColors.textSecondary,
                fontSize = 15.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Box(Modifier.size(24.dp))
            TvButton(actionLabel, onClick = onAction, primary = true)
        }
    }
}
