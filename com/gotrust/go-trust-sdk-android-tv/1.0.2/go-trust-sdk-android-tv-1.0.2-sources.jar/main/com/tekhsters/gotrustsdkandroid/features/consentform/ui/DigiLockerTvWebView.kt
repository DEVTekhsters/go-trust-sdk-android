package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.tekhsters.gotrustsdkandroid.core.ui.TvSpinner
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors

/**
 * TV counterpart of the mobile SDK's `DigiLockerWebView`: identical URL-loading and
 * `code`/`state` callback-URL detection (same DigiLocker backend flow, same WebView), styled for a
 * dark TV surface. D-pad navigation *inside* the WebView's own HTML (links, form fields) and the
 * system on-screen keyboard for any credential entry are handled by the platform WebView itself on
 * Android TV, the same as any other TV app hosting a WebView — nothing extra to wire up here.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun DigiLockerTvWebView(
    url: String,
    onSuccess: (code: String, state: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var isLoading by remember { mutableStateOf(true) }

    Box(modifier = modifier.fillMaxSize().background(TvColors.background)) {
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    isFocusable = true
                    isFocusableInTouchMode = true
                    settings.javaScriptEnabled = true
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            isLoading = false
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?,
                        ): Boolean {
                            val uri = request?.url ?: return false
                            val urlString = uri.toString()
                            if (urlString.contains("code=") && urlString.contains("state=")) {
                                val code = uri.getQueryParameter("code")
                                val state = uri.getQueryParameter("state")
                                if (code != null && state != null) {
                                    onSuccess(code, state)
                                    return true
                                }
                            }
                            return false
                        }
                    }
                    loadUrl(url)
                    requestFocus()
                }
            },
            modifier = Modifier.fillMaxSize(),
        )

        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { TvSpinner() }
        }
    }
}
