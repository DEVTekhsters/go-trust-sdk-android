package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import kotlinx.coroutines.delay
import com.tekhsters.gotrustsdkandroid.core.callbacks.GoTrustSdkCallbacks
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ADDITIONAL_PARAMS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_BASE_URL
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_CONSENT_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_CUSTOMER_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_DATA_JSON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_ENABLE_CAPTCHA
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_LANGUAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_INITIAL_SUBJECT_VALUES
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_MESSAGE
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_PF_TOKEN
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_PREFERENCE_FORM_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SAVED
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SHOW_CROSS_BUTTON
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_SOURCE_ID
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_STATUS
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_TOKEN
import com.tekhsters.gotrustsdkandroid.core.utils.EXTRA_VIA_LOGIN
import com.tekhsters.gotrustsdkandroid.core.utils.LanguagePreferences
import com.tekhsters.gotrustsdkandroid.core.utils.readCaptchaFlag
import com.tekhsters.gotrustsdkandroid.core.utils.readInitialSubjectValues
import com.tekhsters.gotrustsdkandroid.features.consentform.models.GsonProvider
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterUiState
import com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui.PreferenceCenterViewModel
import com.tekhsters.gotrustsdkandroid.core.ui.TV_SNACKBAR_DURATION_MS
import com.tekhsters.gotrustsdkandroid.core.ui.TvBlockingDialog
import com.tekhsters.gotrustsdkandroid.core.ui.TvErrorScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvLoadingScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvSnackbar
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.DigiLockerTvWebView
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.GoTrustSdkTvActivity
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors

private const val CLOSED_BY_USER_MESSAGE = "Preference center closed by user"

/**
 * TV counterpart of the mobile SDK's `PreferenceCenterActivity`: identical lifecycle, extras, and
 * result/callback contract, driven by the same [PreferenceCenterViewModel] (reused unchanged) —
 * only the composables it renders are TV-native. The consent-form hand-off (when a subject isn't
 * found yet) launches the TV consent form activity, not the mobile one.
 */
internal class PreferenceCenterTvActivity : ComponentActivity() {

    private val viewModel: PreferenceCenterViewModel by viewModels()

    // Consent-form-on-login-failure flow is disabled — see PreferenceCenterViewModel.submitLogin().
    // Commented out rather than removed so it can be restored if needed.
    // private val consentFormLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
    //     if (result.resultCode == Activity.RESULT_OK) {
    //         viewModel.onConsentFormSubmitted()
    //     } else {
    //         viewModel.onConsentFormDismissed()
    //     }
    // }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        LanguagePreferences.init(this)

        val baseUrl = intent.getStringExtra(EXTRA_BASE_URL) ?: ""
        val customerId = intent.getStringExtra(EXTRA_CUSTOMER_ID)
        val preferenceFormId = intent.getStringExtra(EXTRA_PREFERENCE_FORM_ID)
        val pfToken = intent.getStringExtra(EXTRA_PF_TOKEN) ?: ""
        val consentId = intent.getStringExtra(EXTRA_CONSENT_ID) ?: ""
        val initialSubjectValues = intent.readInitialSubjectValues()
        @Suppress("UNCHECKED_CAST")
        val additionalParams = intent.getSerializableExtra(EXTRA_ADDITIONAL_PARAMS) as? Map<String, Any> ?: emptyMap()
        val initialLanguage = intent.getStringExtra(EXTRA_INITIAL_LANGUAGE) ?: "en"
        val enableCaptcha = intent.readCaptchaFlag()
        val token = intent.getStringExtra(EXTRA_TOKEN)

        viewModel.init(
            baseUrl = baseUrl,
            customerId = customerId,
            preferenceFormId = preferenceFormId,
            pfToken = pfToken,
            consentId = consentId,
            initialSubjectValues = initialSubjectValues,
            additionalParams = additionalParams,
            initialLanguage = initialLanguage,
            enableCaptcha = enableCaptcha,
            token = token,
        )

        setContent {
            Box(Modifier.fillMaxSize().background(TvColors.background)) {
                val state by viewModel.uiState.collectAsState()
                // val consentFormRequest by viewModel.consentFormLaunchRequest.collectAsState()
                val saveSuccessEvent by viewModel.saveSuccessEvent.collectAsState()
                val saveErrorEvent by viewModel.saveErrorEvent.collectAsState()
                val snackbarMessage by viewModel.snackbarMessage.collectAsState()

                LaunchedEffect(snackbarMessage) {
                    snackbarMessage?.let {
                        delay(TV_SNACKBAR_DURATION_MS)
                        viewModel.consumeSnackbar()
                    }
                }

                LaunchedEffect(saveSuccessEvent) {
                    saveSuccessEvent?.let { event ->
                        GoTrustSdkCallbacks.preferenceCenter?.onSuccess?.invoke(event.message, event.data)
                        viewModel.consumeSaveSuccessEvent()
                    }
                }

                LaunchedEffect(saveErrorEvent) {
                    saveErrorEvent?.let { message ->
                        GoTrustSdkCallbacks.preferenceCenter?.onError?.invoke(message)
                        viewModel.consumeSaveErrorEvent()
                    }
                }

                // LaunchedEffect(consentFormRequest) {
                //     val req = consentFormRequest ?: return@LaunchedEffect
                //     viewModel.consumeConsentFormLaunchRequest()
                //     val intent = Intent(this@PreferenceCenterTvActivity, GoTrustSdkTvActivity::class.java).apply {
                //         putExtra(EXTRA_BASE_URL, req.baseUrl)
                //         putExtra(EXTRA_SOURCE_ID, req.sourceId)
                //         putExtra(EXTRA_INITIAL_SUBJECT_VALUES, HashMap(req.initialSubjectValues))
                //         putExtra(EXTRA_SHOW_CROSS_BUTTON, true)
                //         putExtra(EXTRA_INITIAL_LANGUAGE, req.initialLanguage)
                //         putExtra(EXTRA_ENABLE_CAPTCHA, req.enableCaptcha)
                //         putExtra(EXTRA_VIA_LOGIN, true)
                //         putExtra(EXTRA_ADDITIONAL_PARAMS, HashMap(req.additionalParams))
                //     }
                //     consentFormLauncher.launch(intent)
                // }

                BackHandler {
                    closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE)
                }

                when (val s = state) {
                    is PreferenceCenterUiState.Loading -> TvLoadingScreen()
                    is PreferenceCenterUiState.Login -> LoginTvScreen(
                        viewModel = viewModel,
                        onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                    )
                    is PreferenceCenterUiState.Otp -> OtpTvScreen(
                        viewModel = viewModel,
                        onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                    )
                    is PreferenceCenterUiState.Dashboard -> DashboardTvScreen(
                        viewModel = viewModel,
                        onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                    )
                    is PreferenceCenterUiState.DigiLockerVerification -> DigiLockerTvWebView(
                        url = s.url,
                        onSuccess = { code, otpState -> viewModel.onDigiLockerSuccess(code, otpState) },
                    )
                    is PreferenceCenterUiState.MinorVerificationFailed -> TvBlockingDialog(
                        title = "Verification Failed",
                        message = s.message,
                        actionLabel = "Close",
                        onAction = { viewModel.backToDashboardFromMinorFailure() },
                    )
                    is PreferenceCenterUiState.ConsentNotGiven -> TvBlockingDialog(
                        title = "Consent Required",
                        message = "Consent has not been given yet. Please provide your consent to continue.",
                        actionLabel = "Close",
                        onAction = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                    )
                    is PreferenceCenterUiState.Error -> TvErrorScreen(
                        message = s.message,
                        onRetry = { viewModel.loadLoginConfig() },
                        onClose = { closeWithResult(status = "closed", message = CLOSED_BY_USER_MESSAGE) },
                    )
                }

                snackbarMessage?.let { TvSnackbar(it) }
            }
        }
    }

    private fun closeWithResult(status: String, message: String? = null, dataJson: String? = null) {
        val saved = viewModel.savedAtLeastOnce
        val effectiveStatus = if (saved) "success" else status
        val resultIntent = Intent().apply {
            putExtra(EXTRA_STATUS, effectiveStatus)
            putExtra(EXTRA_SAVED, saved)
            message?.let { putExtra(EXTRA_MESSAGE, it) }
            val payloadJson = dataJson ?: if (saved) GsonProvider.gson.toJson(viewModel.lastSavedResult) else null
            payloadJson?.let { putExtra(EXTRA_DATA_JSON, it) }
        }
        setResult(if (saved) Activity.RESULT_OK else Activity.RESULT_CANCELED, resultIntent)

        GoTrustSdkCallbacks.preferenceCenter?.onClose?.invoke(message)
        GoTrustSdkCallbacks.clearPreferenceCenter()

        finish()
    }
}
