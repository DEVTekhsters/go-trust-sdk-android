package com.tekhsters.gotrustsdkandroid.features.consentform.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.features.consentform.models.ConsentFormResponse
import com.tekhsters.gotrustsdkandroid.features.consentform.models.Language
import com.tekhsters.gotrustsdkandroid.features.consentform.models.PrivacyNoticeResponse
import com.tekhsters.gotrustsdkandroid.core.ui.TvLoadingScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.ui.dpadScrollable
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors

/**
 * TV-paginated (scroll-then-agree) reading pattern for long legal text, per the PRD's 10-foot
 * legibility guidance — Agree only unlocks once the notice has been scrolled to the end, same gate
 * behavior as the mobile screen it replaces.
 */
@Composable
fun PrivacyNoticeTvScreen(
    languages: List<Language>,
    selectedLanguage: String,
    onLanguageChanged: (String) -> Unit,
    privacyData: List<PrivacyNoticeResponse.PrivacyData>,
    formConfig: ConsentFormResponse.FormConfiguration?,
    onAgree: (language: String, id: Int, version: Double) -> Unit,
    onClose: () -> Unit,
    showCrossButton: Boolean = true,
    isLoading: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()
    var agreeEnabled by remember(privacyData) { mutableStateOf(false) }

    // React to every layout pass (not just canScrollForward flips) so content that already
    // fits the viewport - no scroll ever happens - still unlocks Agree, and re-layouts from
    // language changes or resizes are picked up too.
    LaunchedEffect(listState) {
        snapshotFlow { listState.layoutInfo }
            .collect { info ->
                if (info.totalItemsCount > 0 && !listState.canScrollForward) {
                    agreeEnabled = true
                }
            }
    }

    Column(modifier = modifier.fillMaxSize().background(TvColors.background)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TvText(
                formConfig?.form?.privacyPolicyUrlText ?: "Privacy Notice",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            if (formConfig?.form?.showLanguage == true && languages.isNotEmpty()) {
                LanguageSelectorTv(languages, selectedLanguage, onLanguageChanged)
                Box(Modifier.size(16.dp))
            }
            if (showCrossButton) TvButton("Close", onClick = onClose, primary = false)
        }

        if (isLoading && privacyData.isEmpty()) {
            TvLoadingScreen(Modifier.weight(1f))
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().dpadScrollable(listState),
                contentPadding = PaddingValues(horizontal = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                items(privacyData) { notice ->
                    Column {
                        TvText(notice.name ?: "", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Box(Modifier.size(8.dp))
                        notice.content.orEmpty().forEach { section ->
                            val title = section.title
                            if (!title.isNullOrEmpty()) {
                                TvText(title, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Box(Modifier.size(4.dp))
                            }
                            TvText(
                                section.content.orEmpty().replace(Regex("<[^>]*>"), ""),
                                color = TvColors.textSecondary,
                                fontSize = 14.sp,
                            )
                            Box(Modifier.size(12.dp))
                        }
                    }
                }
                item { Box(Modifier.size(8.dp)) }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            if (!agreeEnabled) {
                TvText(
                    "Scroll to the end to continue",
                    color = TvColors.textSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f),
                )
            } else {
                Box(Modifier.weight(1f))
            }
            TvButton(
                "Agree & Continue",
                enabled = agreeEnabled,
                onClick = {
                    val latest = privacyData.firstOrNull() ?: return@TvButton
                    val id = latest.id ?: return@TvButton
                    val version = latest.version ?: 1.0
                    onAgree(selectedLanguage, id, version)
                },
            )
        }
    }
}
