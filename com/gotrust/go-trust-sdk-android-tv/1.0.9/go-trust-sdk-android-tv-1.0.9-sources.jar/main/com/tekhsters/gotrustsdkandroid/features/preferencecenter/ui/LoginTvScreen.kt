package com.tekhsters.gotrustsdkandroid.features.preferencecenter.ui

import com.tekhsters.gotrustsdkandroid.core.utils.GoTrustLogger
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tekhsters.gotrustsdkandroid.core.ui.TvShowImage
import com.tekhsters.gotrustsdkandroid.core.utils.PhoneIdentity
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.parsePxToDp
import com.tekhsters.gotrustsdkandroid.core.ui.TvErrorScreen
import com.tekhsters.gotrustsdkandroid.core.ui.TvButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvIconButton
import com.tekhsters.gotrustsdkandroid.core.ui.TvText
import com.tekhsters.gotrustsdkandroid.core.ui.TvTextEntryField
import com.tekhsters.gotrustsdkandroid.features.consentform.ui.LanguageSelectorTv
import com.tekhsters.gotrustsdkandroid.core.utils.TvColors
import com.tekhsters.gotrustsdkandroid.core.utils.accentOrDefault
import java.util.Calendar

/**
 * TV counterpart of the mobile SDK's `LoginScreen`: same subject-identity fields, same
 * `submitLogin()`/backend flow, entered here through [TvTextEntryField]'s docked on-screen
 * keyboard instead of a touch keyboard.
 */
@Composable
fun LoginTvScreen(viewModel: PreferenceCenterViewModel, onClose: () -> Unit, onErrorClose: () -> Unit, modifier: Modifier = Modifier) {
    val config by viewModel.loginConfig.collectAsState()
    val languages by viewModel.languages.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()
    val cfg = config?.configuration
    val userInfoCfg = cfg?.userInputConfiguration

    if (cfg == null || userInfoCfg == null) {
        TvErrorScreen(
            message = PREFERENCE_CENTER_LOAD_ERROR_MESSAGE,
            onRetry = { viewModel.loadLoginConfig() },
            onClose = onErrorClose,
            modifier = modifier,
        )
        return
    }

    val accent = accentOrDefault(userInfoCfg.submitButton?.backgroundColor ?: userInfoCfg.submitButton?.color)
    val submitTextColor = userInfoCfg.submitButton?.textColor?.let { accentOrDefault(it) }
    val submitShape = RoundedCornerShape((userInfoCfg.submitButton?.borderRadius ?: 10.0).dp)
    val shouldShowLogo = (cfg.showLogo ?: true) && (userInfoCfg.logo?.showLogo ?: true) && !userInfoCfg.logo?.logoUrl.isNullOrEmpty()
    val headerLayout = userInfoCfg?.headerLayout
    val submitHeight = userInfoCfg.submitButton?.height ?: 56.0
    val submitWidth = userInfoCfg.submitButton?.width ?: 200.0

    val iconObjectKey = userInfoCfg.logo?.logoUrl
//    var imageUrl by remember(iconObjectKey) {
//        mutableStateOf<String?>(null)
//    }
//
//    LaunchedEffect(iconObjectKey) {
//        if (iconObjectKey != null) {
//            imageUrl = viewModel.getImageUrl(iconObjectKey)
//        }
//    }

    Column(modifier = modifier.fillMaxSize().background(TvColors.background)) {
        DynamicHeaderAppBar(
            closeIconPosition = headerLayout?.closeIconPosition,
            logoPosition = headerLayout?.logoPosition,
            dropdownPosition = headerLayout?.dropdownPosition,
            backgroundColor =  "#F7F8FA",
            onClose = onClose,
            modifier = Modifier.padding(horizontal = 32.dp, vertical = 20.dp),
            logo = if (!viewModel.headerLogo.isNullOrEmpty() || shouldShowLogo) {
                {
                    TvShowImage(
                        iconObjectKey = viewModel.headerLogo ?: iconObjectKey,
                        iconWidth = userInfoCfg.logo?.width ?: "140",
                        iconHeight = userInfoCfg.logo?.height ?: "48",
                        getImageUrl = viewModel::getImageUrl
                    )
                }
            } else null,
            dropdown = if (cfg.consentPurposeConfiguration?.form?.showLanguage == true && languages.isNotEmpty()) {
                {
                    LanguageSelectorTv(languages, lang, onChanged = { viewModel.onLanguageChanged(it) })
                }
            } else null,
        )

        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp)) {
            TvText(userInfoCfg.heading?.text?.ifEmpty { null } ?: "Sign in", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            if (!userInfoCfg.description?.text.isNullOrEmpty()) {
                GoTrustLogger.d("user","${userInfoCfg.heading?.text}")
                Box(Modifier.size(4.dp))
                TvText(userInfoCfg.description?.text ?: "", color = TvColors.textPrimary, fontSize = 14.sp)
            }
        }
        Box(Modifier.size(16.dp))

        val context = androidx.compose.ui.platform.LocalContext.current

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(config?.subjectIdentityTypes.orEmpty()) { si ->
                val id = si.id ?: return@items
                val isPhone = PhoneIdentity.isPhoneLabel(si.name)
                val editing = viewModel.isEditingSubjectIdentity(id)
                val isDob = si.name?.trim()?.equals("Date of Birth", ignoreCase = true) == true || si.name?.trim()?.equals("dob", ignoreCase = true) == true

                val showDatePicker = {
                    val cal = java.util.Calendar.getInstance()
                    val currentValue = viewModel.subjectIdentityInputs[id]
                    if (!currentValue.isNullOrBlank()) {
                        try {
                            val parts = currentValue.split("/", "-")
                            if (parts.size == 3) {
                                if (parts[0].length == 4) {
                                    cal.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt())
                                } else {
                                    cal.set(parts[2].toInt(), parts[1].toInt() - 1, parts[0].toInt())
                                }
                            }
                        } catch (_: Exception) {}
                    }
                    val dialog = android.app.DatePickerDialog(
                        context,
                        { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                            val formattedDate = String.format(java.util.Locale.US, "%02d/%02d/%04d", selectedDayOfMonth, selectedMonth + 1, selectedYear)
                            viewModel.onSubjectIdentityChanged(id, formattedDate)
                        },
                        cal.get(java.util.Calendar.YEAR),
                        cal.get(java.util.Calendar.MONTH),
                        cal.get(java.util.Calendar.DAY_OF_MONTH)
                    )
                    val minCal = Calendar.getInstance()
                    minCal.add(Calendar.YEAR, -125)
                    dialog.datePicker.minDate = minCal.timeInMillis
                    dialog.datePicker.maxDate = System.currentTimeMillis()
                    dialog.show()
                }

                Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth()) {
                    TvTextEntryField(
                        label = si.name ?: "Identity",
                        value = viewModel.subjectIdentityInputs[id] ?: "",
                        onValueChange = { if (!isDob) viewModel.onSubjectIdentityChanged(id, it) },
                        prefix = if (isPhone) PhoneIdentity.COUNTRY_CODE else null,
                        numeric = isPhone,
                        mandatory = true,
                        maxLength = if (isPhone) 10 else null,
                        enabled = editing,
                        isClickable = if (isDob) editing else false,
                        placeholder = if (isDob) "Select Date" else "Select to type",
                        onClickOverride = if (isDob) showDatePicker else null,
                        trailingIcon = if (isDob) {
                            {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = "Select Date",
                                    tint = TvColors.textSecondary
                                )
                            }
                        } else null,
                        isKeyboardExpanded = if (isDob) false else editing,
                        onKeyboardExpandedChange = { expanded ->
                            if (!expanded && editing && !isDob) {
                                viewModel.toggleEditingSubjectIdentity(id)
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                    Box(Modifier.size(12.dp))

                    TvIconButton(
                        modifier = modifier.padding(top = 23.dp),
                        onClick = {
//
                                viewModel.toggleEditingSubjectIdentity(id)
//
                        },
                        enabled = true
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = if (isDob) "Select Date" else (if (editing) "Done editing" else "Edit"),
                            tint = TvColors.textPrimary
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(32.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TvButton(
                text = if (isBusy) "Please wait…" else (userInfoCfg.submitButton?.text ?: "Login"),
                modifier = Modifier.height(submitHeight.dp).width(submitWidth.dp),
                enabled = !isBusy,
                onClick = { viewModel.submitLogin() },
                accent = accent,
                shape = submitShape,
                textColor = submitTextColor,
            )
        }
    }
}